#!/usr/bin/env node
var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/paths.ts
var paths_exports = {};
__export(paths_exports, {
  PRIVATE_DIR: () => PRIVATE_DIR,
  PRIVATE_FILE: () => PRIVATE_FILE,
  coachDbPath: () => coachDbPath,
  ensurePrivateDir: () => ensurePrivateDir,
  ensureRosterHome: () => ensureRosterHome,
  homeDir: () => homeDir,
  receiptPath: () => receiptPath,
  rosterConfigPath: () => rosterConfigPath,
  rosterHome: () => rosterHome
});
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
function homeDir() {
  return process.env.ROSTER_TEST_HOME ?? os.homedir();
}
function rosterHome() {
  return process.env.ROSTER_HOME ?? path.join(homeDir(), ".roster");
}
function ensurePrivateDir(dir) {
  fs.mkdirSync(dir, { recursive: true, mode: PRIVATE_DIR });
  try {
    const current = fs.statSync(dir).mode & 511;
    if ((current & 63) !== 0) fs.chmodSync(dir, current & 448);
  } catch {
  }
  return dir;
}
function ensureRosterHome() {
  return ensurePrivateDir(rosterHome());
}
function rosterConfigPath() {
  return path.join(rosterHome(), "roster.json");
}
function receiptPath() {
  return path.join(rosterHome(), "receipt.json");
}
function coachDbPath() {
  return path.join(rosterHome(), "coach.db");
}
var PRIVATE_FILE, PRIVATE_DIR;
var init_paths = __esm({
  "src/paths.ts"() {
    "use strict";
    PRIVATE_FILE = 384;
    PRIVATE_DIR = 448;
  }
});

// ../coach/dist/db.js
import fs2 from "node:fs";
import Database from "better-sqlite3";
function ensureOwnerOnlyDbFile(file) {
  if (file === ":memory:" || file === "")
    return;
  try {
    fs2.closeSync(fs2.openSync(file, "a", 384));
    const current = fs2.statSync(file).mode & 511;
    if ((current & 63) !== 0)
      fs2.chmodSync(file, current & 448);
  } catch {
  }
}
function openCoachDb(path17) {
  ensureOwnerOnlyDbFile(path17);
  const db = new Database(path17);
  db.pragma("journal_mode = WAL");
  db.pragma("foreign_keys = ON");
  db.pragma("busy_timeout = 5000");
  migrate(db);
  return db;
}
function migrate(db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT NOT NULL);

    CREATE TABLE IF NOT EXISTS capability(
      id TEXT PRIMARY KEY,
      kind TEXT NOT NULL CHECK(kind IN ('tool','skill')),
      source TEXT NOT NULL,
      name TEXT NOT NULL,
      description TEXT NOT NULL DEFAULT '',
      input_schema TEXT,
      output_schema TEXT,
      body TEXT,
      path TEXT,
      def_hash TEXT NOT NULL,
      quarantined INTEGER NOT NULL DEFAULT 0,
      first_seen INTEGER NOT NULL,
      last_seen INTEGER NOT NULL
    );

    -- The "name" column carries "<source> <tool>" so a user searching "memory"
    -- or a server's own name finds its tools even when descriptions never say
    -- the word (empty-draft bug in default lexical mode).
    CREATE VIRTUAL TABLE IF NOT EXISTS capability_fts USING fts5(id UNINDEXED, name, description, body);

    CREATE TABLE IF NOT EXISTS suggestion(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ts INTEGER NOT NULL,
      session TEXT NOT NULL,
      failed_capability TEXT NOT NULL,
      suggested_capability TEXT NOT NULL,
      taken INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS outcome(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ts INTEGER NOT NULL,
      session TEXT NOT NULL,
      source TEXT NOT NULL,
      capability TEXT NOT NULL,
      need_hash TEXT,
      args_hash TEXT,
      intent_cat TEXT,
      class TEXT NOT NULL,
      latency_ms INTEGER NOT NULL,
      soft_fail INTEGER NOT NULL DEFAULT 0,
      substituted INTEGER NOT NULL DEFAULT 0,
      explored INTEGER NOT NULL DEFAULT 0,
      spec_ver TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_outcome_session ON outcome(session, id);
    CREATE INDEX IF NOT EXISTS idx_outcome_capability ON outcome(capability, ts);

    CREATE TABLE IF NOT EXISTS rating(
      capability TEXT NOT NULL,
      category TEXT NOT NULL,
      n INTEGER NOT NULL,
      successes INTEGER NOT NULL,
      wilson_lb REAL NOT NULL,
      p50_ms INTEGER,
      p95_ms INTEGER,
      updated_at INTEGER NOT NULL,
      PRIMARY KEY(capability, category)
    );

    CREATE TABLE IF NOT EXISTS drift_event(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ts INTEGER NOT NULL,
      capability TEXT NOT NULL,
      old_hash TEXT NOT NULL,
      new_hash TEXT NOT NULL
    );

    -- Tombstone for pruned capabilities: carries the last-seen definition hash
    -- (and quarantine state) forward so a tool that is REMOVED and later
    -- RE-ADDED with a changed definition still raises a drift event instead of
    -- slipping back in as "new" (drift-evasion via remove/re-add).
    CREATE TABLE IF NOT EXISTS removed_capability(
      id TEXT PRIMARY KEY,
      def_hash TEXT NOT NULL,
      quarantined INTEGER NOT NULL DEFAULT 0,
      last_drift_ts INTEGER,
      removed_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS vec(
      capability TEXT PRIMARY KEY,
      dims INTEGER NOT NULL,
      base BLOB NOT NULL,
      adj BLOB,
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS need_vec(
      need_hash TEXT PRIMARY KEY,
      dims INTEGER NOT NULL,
      vec BLOB NOT NULL,
      ts INTEGER NOT NULL
    );
  `);
  db.prepare("INSERT OR IGNORE INTO meta(key, value) VALUES('schema_version', ?)").run(SCHEMA_VERSION);
  addColumnIfMissing(db, "capability", "title", "TEXT");
  addColumnIfMissing(db, "capability", "annotations", "TEXT");
  addColumnIfMissing(db, "capability", "execution", "TEXT");
}
function addColumnIfMissing(db, table, column, decl) {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all();
  if (cols.some((c) => c.name === column))
    return;
  db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${decl}`);
}
var SCHEMA_VERSION;
var init_db = __esm({
  "../coach/dist/db.js"() {
    "use strict";
    SCHEMA_VERSION = "1";
  }
});

// ../coach/dist/classifier.js
function classifyOutcome(e) {
  if (e.transportError)
    return "hard_fail:transport";
  if (e.protocolError)
    return "hard_fail:protocol";
  if (e.timedOut)
    return "tool_fail:timeout";
  if (e.inputValidationError)
    return "tool_fail:schema";
  if (e.isError)
    return `tool_fail:${classifyToolFailKind(e.errorText ?? "")}`;
  if (e.outputSchemaViolation)
    return "schema_drift_suspect";
  return "success";
}
function classifyToolFailKind(errorText) {
  const normalized = errorText.toLowerCase();
  const redacted = normalized.replace(/'[^']*'|"[^"]*"/g, " ");
  const wholeMessage = normalized.trim();
  const quote = wholeMessage.at(0);
  const isQuote = quote === "'" || quote === '"';
  const interior = isQuote ? wholeMessage.slice(1, -1) : "";
  const unwrappedWholeMessage = wholeMessage.length >= 2 && isQuote && wholeMessage.at(-1) === quote && !hasUnescapedQuote(interior, quote) ? interior : "";
  const fallback = isBoundedFilenameLiteral(unwrappedWholeMessage) && !hasHighConfidenceFilenamePrefix(unwrappedWholeMessage) ? "" : stripPathLiteralTokens(unwrappedWholeMessage);
  const t = redacted.trim() || fallback;
  if (/time.?out|timed out|deadline|etimedout/.test(t))
    return "timeout";
  if (/quota|rate.?limit|too many requests|\b429\b|tokens?\s+per\b|per\s+(minute|min|second|sec|hour|day)\b/.test(t)) {
    return "quota";
  }
  if (/internal (server )?error|\b50[023]\b|panic|crashed|segfault/.test(t))
    return "internal";
  if (/schema|invalid (argument|param|input|request)|validation|required (field|property|parameter)|must be of type|invalid\b[\w\s'"()-]{0,40}\b(format|argument|parameter|value|type|field|property)\b/.test(t)) {
    return "schema";
  }
  if (/unauthori[sz]ed|forbidden|permission denied|access denied|credential|api.?key|signature|(?:^|[^a-z])auth|\b40[13]\b|(?:invalid|expired|revoked|missing|bad)[^.;]{0,40}\btoken\b|\btoken\b[^.;]{0,40}(?:invalid|expired|revoked)/.test(t)) {
    return "auth";
  }
  return "other";
}
function hasUnescapedQuote(text, quote) {
  let precedingBackslashes = 0;
  for (const character of text) {
    if (character === "\\") {
      precedingBackslashes += 1;
      continue;
    }
    if (character === quote && precedingBackslashes % 2 === 0)
      return true;
    precedingBackslashes = 0;
  }
  return false;
}
function stripPathLiteralTokens(text) {
  return text.split(/\s+/).filter((token) => !isPathUriOrFilenameToken(token)).join(" ");
}
function isPathUriOrFilenameToken(token) {
  return /[\\/]/.test(token) || /^[a-z][a-z0-9+.-]{0,31}:(?:\/\/)?[^\s]{1,512}$/.test(token) || isBoundedFilenameLiteral(token);
}
function isBoundedFilenameLiteral(text) {
  return !/[\\/]/.test(text) && /^[a-z0-9][a-z0-9 ._-]{0,127}\.[a-z0-9_-]{1,16}$/.test(text);
}
function hasHighConfidenceFilenamePrefix(text) {
  const finalSpace = text.lastIndexOf(" ");
  if (finalSpace <= 0)
    return false;
  const prefix = text.slice(0, finalSpace).trim();
  return /time.?out|timed out|deadline|etimedout|quota|rate.?limit|too many requests|\b429\b|tokens?\s+per\b|per\s+(minute|min|second|sec|hour|day)\b|internal (server )?error|\b50[023]\b|panic|crashed|segfault|schema|invalid (argument|param|input|request)|validation|required (field|property|parameter)|must be of type|invalid\b[\w\s'"()-]{0,40}\b(format|argument|parameter|value|type|field|property)\b|\b40[13]\b|unauthori[sz]ed|forbidden|permission denied|access denied|(?:invalid|expired)\b[^.;]{0,40}\btoken\b|\btoken\b[^.;]{0,40}(?:invalid|expired)|authentication failure/.test(prefix);
}
function isAttributable(cls) {
  if (cls === "tool_fail:schema")
    return false;
  return cls === "success" || cls.startsWith("hard_fail:") || cls.startsWith("tool_fail:") || cls === "schema_drift_suspect";
}
var init_classifier = __esm({
  "../coach/dist/classifier.js"() {
    "use strict";
  }
});

// ../coach/dist/oats.js
function normalize(v) {
  let norm = 0;
  for (const x of v)
    norm += x * x;
  norm = Math.sqrt(norm);
  if (norm === 0)
    return new Float32Array(v.length);
  const out = new Float32Array(v.length);
  for (let i = 0; i < v.length; i++)
    out[i] = v[i] / norm;
  return out;
}
function cosine(a, b) {
  if (a.length !== b.length)
    throw new RangeError("dimension mismatch");
  let dot = 0;
  let na = 0;
  let nb = 0;
  for (let i = 0; i < a.length; i++) {
    const x = a[i];
    const y = b[i];
    dot += x * y;
    na += x * x;
    nb += y * y;
  }
  if (na === 0 || nb === 0)
    return 0;
  return dot / (Math.sqrt(na) * Math.sqrt(nb));
}
function meanVec(vs) {
  if (vs.length === 0)
    throw new RangeError("meanVec of empty set");
  const dims = vs[0].length;
  const out = new Float32Array(dims);
  for (const v of vs) {
    if (v.length !== dims)
      throw new RangeError("dimension mismatch");
    for (let i = 0; i < dims; i++)
      out[i] = out[i] + v[i];
  }
  for (let i = 0; i < dims; i++)
    out[i] = out[i] / vs.length;
  return out;
}
function oatsAdjust(base, positives, negatives, opts = {}) {
  const { alpha = 0.3, beta = 0.1, iterations = 3, minPositives = 4 } = opts;
  if (positives.length < minPositives) {
    return { vec: normalize(base), applied: false };
  }
  const posCentroid = meanVec(positives);
  const negCentroid = negatives.length > 0 ? meanVec(negatives) : null;
  let e = normalize(base);
  for (let iter = 0; iter < iterations; iter++) {
    const next = new Float32Array(e.length);
    for (let i = 0; i < e.length; i++) {
      let x = (1 - alpha) * e[i] + alpha * posCentroid[i];
      if (negCentroid)
        x -= beta * negCentroid[i];
      next[i] = x;
    }
    e = normalize(next);
  }
  return { vec: e, applied: true };
}
var init_oats = __esm({
  "../coach/dist/oats.js"() {
    "use strict";
  }
});

// ../shared/dist/types.js
var init_types = __esm({
  "../shared/dist/types.js"() {
    "use strict";
  }
});

// ../shared/dist/namespacing.js
import { createHash } from "node:crypto";
function sanitizeSegment(raw) {
  const cleaned = raw.replace(INVALID, "-").replace(/-{2,}/g, "-").replace(/^-|-$/g, "");
  return cleaned.length > 0 ? cleaned : "x";
}
function sanitizeSource(raw) {
  const s = sanitizeSegment(raw).replace(/_{2,}/g, "_").replace(/^_+|_+$/g, "");
  return s.length > 0 ? s : "x";
}
function sha256PublicName(raw) {
  return createHash("sha256").update(raw, "utf8").digest("hex");
}
function stableSegment(raw) {
  const safe = sanitizeSegment(raw);
  return raw === safe && !GENERATED_SUFFIX.test(raw) ? safe : `${safe}-${sha256PublicName(raw).slice(0, 10)}`;
}
function stableBackendName(raw) {
  const segment = stableSegment(raw);
  const source = sanitizeSource(segment);
  const name = segment === source && source !== "skill-server" ? segment : `${source}-${sha256PublicName(raw).slice(0, 10)}`;
  return name === "skill" ? "skill-server" : name;
}
function stableNamespacedId(source, rawName) {
  return `${sanitizeSource(source)}${NAMESPACE_SEP}${stableSegment(rawName)}`;
}
function parseNamespacedId(id) {
  const idx = id.indexOf(NAMESPACE_SEP);
  if (idx <= 0 || idx >= id.length - NAMESPACE_SEP.length)
    return null;
  return { source: id.slice(0, idx), name: id.slice(idx + NAMESPACE_SEP.length) };
}
var INVALID, GENERATED_SUFFIX, NAMESPACE_SEP;
var init_namespacing = __esm({
  "../shared/dist/namespacing.js"() {
    "use strict";
    INVALID = /[^a-zA-Z0-9_-]+/g;
    GENERATED_SUFFIX = /-[a-f0-9]{10}$/;
    NAMESPACE_SEP = "__";
  }
});

// ../shared/dist/stats.js
function wilsonLowerBound(successes, n, z = 1.96) {
  if (n <= 0)
    return 0;
  if (successes < 0 || successes > n)
    throw new RangeError("successes must be within [0, n]");
  const phat = successes / n;
  const z2 = z * z;
  const denom = 1 + z2 / n;
  const centre = phat + z2 / (2 * n);
  const spread = z * Math.sqrt(phat * (1 - phat) / n + z2 / (4 * n * n));
  return Math.max(0, (centre - spread) / denom);
}
function percentile(sortedAscending, p) {
  if (sortedAscending.length === 0)
    return null;
  const idx = Math.min(sortedAscending.length - 1, Math.max(0, Math.ceil(p / 100 * sortedAscending.length) - 1));
  return sortedAscending[idx] ?? null;
}
var init_stats = __esm({
  "../shared/dist/stats.js"() {
    "use strict";
  }
});

// ../shared/dist/tokens.js
function estimateTokensFromChars(chars) {
  return chars <= 0 ? 0 : Math.ceil(chars / 4);
}
var init_tokens = __esm({
  "../shared/dist/tokens.js"() {
    "use strict";
  }
});

// ../shared/dist/index.js
var init_dist = __esm({
  "../shared/dist/index.js"() {
    "use strict";
    init_types();
    init_namespacing();
    init_stats();
    init_tokens();
  }
});

// ../coach/dist/util.js
import { createHash as createHash2 } from "node:crypto";
function sha256Hex(input) {
  const hash = createHash2("sha256");
  if (typeof input === "string")
    hash.update(input, "utf8");
  else
    hash.update(input);
  return hash.digest("hex");
}
function stableStringify(value) {
  return JSON.stringify(sortValue(value));
}
function sortValue(value) {
  if (Array.isArray(value))
    return value.map(sortValue);
  if (value !== null && typeof value === "object") {
    const out = {};
    for (const key of Object.keys(value).sort()) {
      out[key] = sortValue(value[key]);
    }
    return out;
  }
  return value;
}
function hashArgs(args) {
  return sha256Hex(stableStringify(args ?? null));
}
function hashNeed(need) {
  return sha256Hex(need.trim().toLowerCase());
}
function vecToBlob(vec) {
  return Buffer.from(vec.buffer, vec.byteOffset, vec.byteLength);
}
function blobToVec(blob, dims) {
  if (!Number.isInteger(dims) || dims <= 0) {
    throw new RangeError(`vector dimensions must be a positive integer, got ${dims}`);
  }
  if (blob.byteLength !== dims * 4) {
    throw new RangeError(`vector blob is ${blob.byteLength}B but dims=${dims} expects ${dims * 4}B`);
  }
  const copy = Buffer.from(blob);
  const vec = new Float32Array(copy.buffer, copy.byteOffset, dims);
  for (const value of vec) {
    if (!Number.isFinite(value)) {
      throw new RangeError("vector contains a non-finite value");
    }
  }
  return vec;
}
var init_util = __esm({
  "../coach/dist/util.js"() {
    "use strict";
  }
});

// ../coach/dist/store.js
function lexTokens(text) {
  const spaced = text.replace(/([a-z0-9])([A-Z])/g, "$1 $2").replace(/([A-Za-z])([0-9])/g, "$1 $2");
  return spaced.toLowerCase().match(/[a-z0-9]{2,}/g) ?? [];
}
function ftsNameText(source, name) {
  return `${source} ${name} ${lexTokens(name).join(" ")}`;
}
function canonicalJson(value) {
  if (value === void 0)
    return "null";
  if (value === null || typeof value !== "object")
    return JSON.stringify(value) ?? "null";
  if (Array.isArray(value))
    return `[${value.map(canonicalJson).join(",")}]`;
  const entries = Object.entries(value).filter(([, v]) => v !== void 0).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0);
  return `{${entries.map(([k, v]) => `${JSON.stringify(k)}:${canonicalJson(v)}`).join(",")}}`;
}
function defHash(entry) {
  return sha256Hex(canonicalJson({
    v: DEF_HASH_VERSION,
    name: entry.name,
    description: entry.description,
    title: entry.title ?? null,
    annotations: entry.annotations ?? null,
    inputSchema: entry.inputSchema ?? null,
    outputSchema: entry.outputSchema ?? null,
    execution: entry.execution ?? null,
    body: entry.body ?? null
  }));
}
function buildParams(entry, hash, now) {
  return {
    id: entry.id,
    kind: entry.kind,
    source: entry.source,
    name: entry.name,
    description: entry.description,
    title: entry.title ?? null,
    annotations: entry.annotations ? JSON.stringify(entry.annotations) : null,
    execution: entry.execution ? JSON.stringify(entry.execution) : null,
    input_schema: entry.inputSchema ? JSON.stringify(entry.inputSchema) : null,
    output_schema: entry.outputSchema ? JSON.stringify(entry.outputSchema) : null,
    body: entry.body ?? null,
    path: entry.path ?? null,
    def_hash: hash,
    now
  };
}
function parseJsonColumn(value) {
  if (value === null)
    return void 0;
  try {
    const parsed = JSON.parse(value);
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : void 0;
  } catch {
    return void 0;
  }
}
function rowToEntry(row) {
  return {
    id: row.id,
    kind: row.kind,
    source: row.source,
    name: row.name,
    description: row.description,
    title: row.title ?? void 0,
    annotations: parseJsonColumn(row.annotations),
    execution: parseJsonColumn(row.execution),
    inputSchema: parseJsonColumn(row.input_schema),
    outputSchema: parseJsonColumn(row.output_schema),
    body: row.body ?? void 0,
    path: row.path ?? void 0
  };
}
var SOFT_FAIL_LOOKBACK, QUARANTINE_DWELL_MS, HYBRID_LEX_WEIGHT, HYBRID_COS_WEIGHT, MIN_INFORMATIVE_COS_SPAN, LEX_SCORE_FLOOR, STOPWORDS, DEF_HASH_VERSION, DEF_HASH_VERSION_KEY, CoachStore;
var init_store = __esm({
  "../coach/dist/store.js"() {
    "use strict";
    init_dist();
    init_classifier();
    init_oats();
    init_util();
    SOFT_FAIL_LOOKBACK = 3;
    QUARANTINE_DWELL_MS = 24 * 3600 * 1e3;
    HYBRID_LEX_WEIGHT = 0.15;
    HYBRID_COS_WEIGHT = 0.85;
    MIN_INFORMATIVE_COS_SPAN = 0.15;
    LEX_SCORE_FLOOR = 0.05;
    STOPWORDS = /* @__PURE__ */ new Set([
      "the",
      "a",
      "an",
      "and",
      "or",
      "of",
      "to",
      "in",
      "on",
      "for",
      "is",
      "are",
      "be",
      "my",
      "that",
      "this",
      "it",
      "its",
      "with",
      "as",
      "at",
      "by",
      "from",
      "into",
      "do",
      "does",
      "me",
      "we",
      "us",
      "your",
      "you",
      "i",
      "so",
      "if",
      "then"
    ]);
    DEF_HASH_VERSION = "2";
    DEF_HASH_VERSION_KEY = "def_hash_version";
    CoachStore = class {
      db;
      // Initialized in the constructor BODY: with ES2022 class fields, field
      // initializers run before parameter-property assignment — `this.db` would
      // still be undefined here.
      activeCapabilityStmt;
      constructor(db) {
        this.db = db;
        this.activeCapabilityStmt = this.db.prepare(`SELECT id, kind, source, name, description, title, annotations, execution, input_schema, output_schema, body, path, quarantined
       FROM capability WHERE id = ? AND quarantined = 0`);
      }
      /** Close the underlying database handle. Idempotent — a second call is a
       *  no-op — so it is safe to call from a shutdown path that may fire more than
       *  once (stdin EOF racing SIGTERM). */
      close() {
        if (this.db.open)
          this.db.close();
      }
      // ── maintenance (the nightly job) ─────────────────────────────────────────
      getMeta(key) {
        const row = this.db.prepare("SELECT value FROM meta WHERE key = ?").get(key);
        return row?.value ?? null;
      }
      setMeta(key, value) {
        this.db.prepare("INSERT INTO meta(key, value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(key, value);
      }
      /**
       * The nightly job, run opportunistically at serve boot: recompute ratings
       * from logged outcomes and refine tool vectors (OATS). Debounced by
       * `intervalMs` so frequent client restarts don't thrash. Returns what ran.
       * This is what makes the README's "learns from outcomes" true at runtime.
       */
      runMaintenanceIfDue(intervalMs = 20 * 3600 * 1e3, now = Date.now()) {
        const last = Number(this.getMeta("last_maintenance") ?? 0);
        if (now - last < intervalMs)
          return { ran: false };
        this.recomputeRatings("all", now);
        const oats = this.runOats(now);
        this.setMeta("last_maintenance", String(now));
        return { ran: true, oats };
      }
      // ── capabilities ────────────────────────────────────────────────────────
      upsertCapabilities(entries, now = Date.now()) {
        const result = { added: [], changed: [], driftEvents: 0 };
        const getExisting = this.db.prepare("SELECT id, def_hash FROM capability WHERE id = ?");
        const insert = this.db.prepare(`
      INSERT INTO capability(id, kind, source, name, description, title, annotations, execution,
        input_schema, output_schema, body, path, def_hash, quarantined, first_seen, last_seen)
      VALUES(@id, @kind, @source, @name, @description, @title, @annotations, @execution,
        @input_schema, @output_schema, @body, @path, @def_hash, 0, @now, @now)
    `);
        const update = this.db.prepare(`
      UPDATE capability SET kind=@kind, source=@source, name=@name, description=@description,
        title=@title, annotations=@annotations, execution=@execution,
        input_schema=@input_schema, output_schema=@output_schema, body=@body, path=@path,
        def_hash=@def_hash, quarantined=@quarantined, last_seen=@now
      WHERE id=@id
    `);
        const touch = this.db.prepare("UPDATE capability SET last_seen=? WHERE id=?");
        const rebaseline = this.db.prepare(`
      UPDATE capability SET kind=@kind, source=@source, name=@name, description=@description,
        title=@title, annotations=@annotations, execution=@execution,
        input_schema=@input_schema, output_schema=@output_schema, body=@body, path=@path,
        def_hash=@def_hash, last_seen=@now
      WHERE id=@id
    `);
        const drift = this.db.prepare("INSERT INTO drift_event(ts, capability, old_hash, new_hash) VALUES(?,?,?,?)");
        const ftsDelete = this.db.prepare("DELETE FROM capability_fts WHERE id = ?");
        const ftsInsert = this.db.prepare("INSERT INTO capability_fts(id, name, description, body) VALUES(?,?,?,?)");
        const vecDelete = this.db.prepare("DELETE FROM vec WHERE capability = ?");
        const getTombstone = this.db.prepare("SELECT def_hash, quarantined, last_drift_ts FROM removed_capability WHERE id = ?");
        const deleteTombstone = this.db.prepare("DELETE FROM removed_capability WHERE id = ?");
        const setQuarantined = this.db.prepare("UPDATE capability SET quarantined = 1 WHERE id = ?");
        const run = this.db.transaction(() => {
          if (this.getMeta(DEF_HASH_VERSION_KEY) !== DEF_HASH_VERSION) {
            this.db.prepare("UPDATE capability SET def_hash = ''").run();
            this.db.prepare("UPDATE removed_capability SET def_hash = ''").run();
            this.setMeta(DEF_HASH_VERSION_KEY, DEF_HASH_VERSION);
          }
          for (const entry of entries) {
            const hash = defHash(entry);
            const row = getExisting.get(entry.id);
            if (row && row.def_hash === "") {
              rebaseline.run(buildParams(entry, hash, now));
              ftsDelete.run(entry.id);
              ftsInsert.run(entry.id, ftsNameText(entry.source, entry.name), entry.description, entry.body ?? "");
              continue;
            }
            const params = buildParams(entry, hash, now);
            if (!row) {
              insert.run(params);
              ftsInsert.run(entry.id, ftsNameText(entry.source, entry.name), entry.description, entry.body ?? "");
              const tomb = getTombstone.get(entry.id);
              if (tomb) {
                deleteTombstone.run(entry.id);
                if (tomb.def_hash !== "" && tomb.def_hash !== hash) {
                  drift.run(now, entry.id, tomb.def_hash, hash);
                  setQuarantined.run(entry.id);
                  result.changed.push(entry.id);
                  result.driftEvents += 1;
                } else {
                  if (tomb.quarantined === 1 && tomb.last_drift_ts !== null && now - tomb.last_drift_ts < QUARANTINE_DWELL_MS) {
                    setQuarantined.run(entry.id);
                  }
                  result.added.push(entry.id);
                }
              } else {
                result.added.push(entry.id);
              }
            } else if (row.def_hash !== hash) {
              drift.run(now, entry.id, row.def_hash, hash);
              update.run({ ...params, quarantined: 1 });
              ftsDelete.run(entry.id);
              ftsInsert.run(entry.id, ftsNameText(entry.source, entry.name), entry.description, entry.body ?? "");
              vecDelete.run(entry.id);
              result.changed.push(entry.id);
              result.driftEvents += 1;
            } else {
              const lastDrift = this.db.prepare("SELECT ts FROM drift_event WHERE capability = ? ORDER BY id DESC LIMIT 1").get(entry.id);
              const dwellOver = !lastDrift || now - lastDrift.ts >= QUARANTINE_DWELL_MS;
              if (dwellOver) {
                this.db.prepare("UPDATE capability SET quarantined = 0, last_seen = ? WHERE id = ?").run(now, entry.id);
              } else {
                touch.run(now, entry.id);
              }
            }
          }
        });
        run.immediate();
        return result;
      }
      /**
       * Model-switch guard: OATS-adjusted vectors and cached need vectors are only
       * meaningful in the embedding space they were computed in. When the active
       * model changes (RAM boundary crossed, DB moved between machines), stale
       * `adj` blobs would otherwise be read at the new dims — silently poisoning
       * exactly the best-learned tools. Call before any backfill.
       */
      ensureEmbeddingModel(modelId) {
        const prev = this.getMeta("embedding_model");
        if (prev === modelId)
          return { switched: false };
        const run = this.db.transaction(() => {
          if (prev !== null) {
            this.db.prepare("DELETE FROM vec").run();
            this.db.prepare("DELETE FROM need_vec").run();
          }
          this.setMeta("embedding_model", modelId);
        });
        run.immediate();
        return { switched: prev !== null };
      }
      listCapabilities(opts = {}) {
        const rows = this.db.prepare(`SELECT id, kind, source, name, description, title, annotations, execution, input_schema, output_schema, body, path, quarantined
         FROM capability
         WHERE (@includeQuarantined = 1 OR quarantined = 0)
           AND (@kind IS NULL OR kind = @kind)
         ORDER BY id`).all({
          includeQuarantined: opts.includeQuarantined ? 1 : 0,
          kind: opts.kind ?? null
        });
        return rows.map(rowToEntry);
      }
      getCapability(id) {
        const row = this.db.prepare(`SELECT id, kind, source, name, description, title, annotations, execution, input_schema, output_schema, body, path, quarantined
         FROM capability WHERE id = ?`).get(id);
        return row ? rowToEntry(row) : null;
      }
      /** Draft-path lookup: quarantined capabilities never enter a roster. */
      activeCapability(id) {
        const row = this.activeCapabilityStmt.get(id);
        return row ? rowToEntry(row) : null;
      }
      /**
       * Remove capabilities that no longer exist upstream (server removed, skill
       * deleted). Vectors and FTS rows go with them; outcome history is kept.
       */
      pruneMissing(presentIds, protectedSources = /* @__PURE__ */ new Set(), opts = {}) {
        const now = opts.now ?? Date.now();
        const selectAll = this.db.prepare("SELECT id, source, last_seen, def_hash, quarantined FROM capability");
        let gone = [];
        const keepSince = opts.keepSeenSince ?? Number.POSITIVE_INFINITY;
        const deSuffix = (source) => source.replace(/-\d+$/, "");
        const run = this.db.transaction(() => {
          const all = selectAll.all();
          gone = all.filter((r) => !presentIds.has(r.id) && !protectedSources.has(r.source) && !protectedSources.has(deSuffix(r.source)) && r.last_seen < keepSince);
          const delCap = this.db.prepare("DELETE FROM capability WHERE id = ?");
          const delFts = this.db.prepare("DELETE FROM capability_fts WHERE id = ?");
          const delVec = this.db.prepare("DELETE FROM vec WHERE capability = ?");
          const lastDriftStmt = this.db.prepare("SELECT ts FROM drift_event WHERE capability = ? ORDER BY id DESC LIMIT 1");
          const tombstone = this.db.prepare(`INSERT OR REPLACE INTO removed_capability(id, def_hash, quarantined, last_drift_ts, removed_at)
         VALUES(?,?,?,?,?)`);
          for (const r of gone) {
            const ld = lastDriftStmt.get(r.id);
            tombstone.run(r.id, r.def_hash, r.quarantined, ld?.ts ?? null, now);
            delCap.run(r.id);
            delFts.run(r.id);
            delVec.run(r.id);
          }
        });
        run.immediate();
        return gone.map((r) => r.id);
      }
      /** Sixth Man field data: every suggestion is logged; `taken` flips when the agent follows it. */
      recordSuggestion(session, failed, suggested, now = Date.now()) {
        this.db.prepare("INSERT INTO suggestion(ts, session, failed_capability, suggested_capability) VALUES(?,?,?,?)").run(now, session, failed, suggested);
      }
      markSuggestionTaken(session, capability) {
        this.db.prepare(`UPDATE suggestion SET taken = 1 WHERE id = (
           SELECT id FROM suggestion WHERE session = ? AND suggested_capability = ? AND taken = 0
           ORDER BY id DESC LIMIT 1)`).run(session, capability);
      }
      clearQuarantine(id) {
        this.db.prepare("UPDATE capability SET quarantined = 0 WHERE id = ?").run(id);
      }
      driftEvents() {
        return this.db.prepare("SELECT ts, capability, old_hash, new_hash FROM drift_event ORDER BY id DESC").all().map((r) => ({ ts: r.ts, capability: r.capability, oldHash: r.old_hash, newHash: r.new_hash }));
      }
      // ── outcomes ────────────────────────────────────────────────────────────
      recordOutcome(input) {
        const ts = input.ts ?? Date.now();
        const run = this.db.transaction(() => {
          const insert = this.db.prepare(`
        INSERT INTO outcome(ts, session, source, capability, need_hash, args_hash, intent_cat,
          class, latency_ms, soft_fail, substituted, explored, spec_ver)
        VALUES(@ts, @session, @source, @capability, @need_hash, @args_hash, @intent_cat,
          @class, @latency_ms, 0, @substituted, @explored, @spec_ver)
      `);
          const info = insert.run({
            ts,
            session: input.session,
            source: input.source,
            capability: input.capability,
            need_hash: input.needHash ?? null,
            args_hash: input.argsHash ?? null,
            intent_cat: input.intentCategory ?? null,
            class: input.outcomeClass,
            latency_ms: Math.max(0, Math.round(input.latencyMs)),
            substituted: input.substituted ? 1 : 0,
            explored: input.explored ? 1 : 0,
            spec_ver: input.specVersion ?? null
          });
          const id = Number(info.lastInsertRowid);
          this.markSoftFailIfRetry(id, input);
          this.markSuggestionTaken(input.session, input.capability);
          return id;
        });
        return run.immediate();
      }
      /**
       * Handoff §6.2 rule 4 (amended 2026-07-07 after the deep-review audit): a
       * re-call of the same capability with *different* args marks the PRIOR attempt
       * soft_fail — BUT only when that prior attempt did NOT succeed. The original
       * rule marked any prior call, which conflated the "retried because the result
       * was unusable" signal with the DOMINANT agent pattern of iterating one tool
       * over different inputs (read 5 files, list 5 dirs). Empirically that discarded
       * ~4 of 5 legitimate successes and starved OATS's positive corpus. A genuine
       * success is never retroactively downgraded; a prior FAILURE followed by an
       * adjusted-args retry is still excluded (MCP-Atlas fairness: don't blame the
       * tool for what may be the caller's first bad args). Distinguishing iteration
       * from dissatisfaction on two successes needs an end-of-task signal we don't
       * yet have (§6.2 item 5); until then, a success counts as a success.
       */
      markSoftFailIfRetry(currentId, input) {
        if (!input.argsHash)
          return;
        const recent = this.db.prepare(`SELECT id, capability, args_hash, class FROM outcome
         WHERE session = ? AND id < ? ORDER BY id DESC LIMIT ?`).all(input.session, currentId, SOFT_FAIL_LOOKBACK);
        const prior = recent.find((r) => r.capability === input.capability && r.args_hash !== null && r.args_hash !== input.argsHash && r.class !== "success");
        if (prior) {
          this.db.prepare("UPDATE outcome SET soft_fail = 1 WHERE id = ?").run(prior.id);
        }
      }
      // ── ratings ─────────────────────────────────────────────────────────────
      /**
       * Ratings use only attributable, non-explored, non-soft-fail rows (§6.2).
       * Percentile latencies come from successful calls: they describe how the
       * capability performs when it works.
       */
      recomputeRatings(category = "all", now = Date.now()) {
        const rows = category === "all" ? this.db.prepare(`SELECT capability, class, latency_ms FROM outcome
             WHERE explored = 0 AND soft_fail = 0`).all() : this.db.prepare(`SELECT capability, class, latency_ms FROM outcome
             WHERE explored = 0 AND soft_fail = 0 AND intent_cat = ?`).all(category);
        const byCap = /* @__PURE__ */ new Map();
        for (const row of rows) {
          if (!isAttributable(row.class))
            continue;
          let agg = byCap.get(row.capability);
          if (!agg) {
            agg = { n: 0, successes: 0, latencies: [] };
            byCap.set(row.capability, agg);
          }
          agg.n += 1;
          if (row.class === "success") {
            agg.successes += 1;
            agg.latencies.push(row.latency_ms);
          }
        }
        const upsert = this.db.prepare(`
      INSERT INTO rating(capability, category, n, successes, wilson_lb, p50_ms, p95_ms, updated_at)
      VALUES(@capability, @category, @n, @successes, @wilson_lb, @p50, @p95, @now)
      ON CONFLICT(capability, category) DO UPDATE SET
        n=@n, successes=@successes, wilson_lb=@wilson_lb, p50_ms=@p50, p95_ms=@p95, updated_at=@now
    `);
        const existing = this.db.prepare("SELECT capability FROM rating WHERE category = ?").all(category);
        const deleteRating = this.db.prepare("DELETE FROM rating WHERE capability = ? AND category = ?");
        const run = this.db.transaction(() => {
          for (const { capability } of existing) {
            if (!byCap.has(capability))
              deleteRating.run(capability, category);
          }
          for (const [capability, agg] of byCap) {
            const sorted = [...agg.latencies].sort((a, b) => a - b);
            upsert.run({
              capability,
              category,
              n: agg.n,
              successes: agg.successes,
              wilson_lb: wilsonLowerBound(agg.successes, agg.n),
              p50: percentile(sorted, 50),
              p95: percentile(sorted, 95),
              now
            });
          }
        });
        run();
      }
      getRating(capability, category = "all") {
        const row = this.db.prepare("SELECT n, successes, wilson_lb, p50_ms, p95_ms FROM rating WHERE capability=? AND category=?").get(capability, category);
        if (!row)
          return null;
        return {
          n: row.n,
          successes: row.successes,
          wilsonLb: row.wilson_lb,
          p50Ms: row.p50_ms,
          p95Ms: row.p95_ms
        };
      }
      // ── retrieval ladder ────────────────────────────────────────────────────
      /** Rung 1: FTS5/BM25 — instant, zero-download. */
      lexicalSearch(need, k = 30, eligibleIds) {
        const all = [...new Set(lexTokens(need))];
        const content = all.filter((t) => !STOPWORDS.has(t));
        const tokens = content.length > 0 ? content : all;
        if (tokens.length === 0)
          return [];
        const match = tokens.map((t) => `"${t}"`).join(" OR ");
        try {
          const rows = this.db.prepare(`SELECT id, bm25(capability_fts) AS rank FROM capability_fts
           WHERE capability_fts MATCH @match
             AND (@eligible IS NULL OR id IN (SELECT value FROM json_each(@eligible)))
           ORDER BY rank LIMIT @limit`).all({ match, limit: k, eligible: eligibleIds ? JSON.stringify([...eligibleIds]) : null });
          if (rows.length === 0)
            return [];
          const ranks = rows.map((r) => r.rank);
          const best = Math.min(...ranks);
          const worst = Math.max(...ranks);
          const span = worst - best;
          return rows.map((r) => ({
            id: r.id,
            lexScore: span === 0 ? 1 : LEX_SCORE_FLOOR + (1 - LEX_SCORE_FLOOR) * ((worst - r.rank) / span)
          }));
        } catch {
          return [];
        }
      }
      /**
       * Rung 2 fusion: 0.15·lexical + 0.85·cosine when a need vector is available.
       * Quarantined capabilities never enter a roster.
       */
      draftCandidates(need, k, needVec, eligibleIds) {
        const lexical = this.lexicalSearch(need, Math.max(30, k * 6), eligibleIds);
        const lexById = new Map(lexical.map((l) => [l.id, l.lexScore]));
        const vecs = needVec ? this.loadVecs() : /* @__PURE__ */ new Map();
        const candidateIds = new Set(lexById.keys());
        if (needVec)
          for (const id of vecs.keys())
            candidateIds.add(id);
        const gathered = [];
        for (const id of candidateIds) {
          if (eligibleIds && !eligibleIds.has(id))
            continue;
          const entry = this.activeCapability(id);
          if (!entry)
            continue;
          const lexScore = lexById.get(id) ?? null;
          let cosScore = null;
          if (needVec) {
            const v = vecs.get(id);
            if (v && v.length === needVec.length)
              cosScore = cosine(needVec, v);
          }
          gathered.push({ entry, lexScore, cosScore });
        }
        const cosVals = gathered.map((g) => g.cosScore).filter((c) => c !== null);
        const cosMin = cosVals.length > 0 ? Math.min(...cosVals) : 0;
        const cosSpan = cosVals.length > 0 ? Math.max(...cosVals) - cosMin : 0;
        const denseInformative = cosVals.length > 1 && cosSpan >= MIN_INFORMATIVE_COS_SPAN;
        const out = [];
        for (const g of gathered) {
          let score;
          if (needVec && denseInformative && g.cosScore !== null) {
            const cosNorm = (g.cosScore - cosMin) / cosSpan;
            score = HYBRID_LEX_WEIGHT * (g.lexScore ?? 0) + HYBRID_COS_WEIGHT * cosNorm;
          } else {
            score = g.lexScore ?? 0;
          }
          if (score > 0)
            out.push({ entry: g.entry, score, lexScore: g.lexScore, cosScore: g.cosScore });
        }
        out.sort((a, b) => b.score - a.score);
        if (out.length >= k)
          return out.slice(0, k);
        const have = new Set(out.map((c) => c.entry.id));
        for (const entry of this.ratedFallback(k - out.length, have, eligibleIds)) {
          out.push({ entry, score: 0, lexScore: null, cosScore: null });
        }
        return out.slice(0, k);
      }
      ratedFallback(limit, exclude, eligibleIds) {
        const rows = this.db.prepare(`SELECT c.id FROM capability c
         LEFT JOIN rating r ON r.capability = c.id AND r.category = 'all'
         WHERE c.quarantined = 0
           AND (@eligible IS NULL OR c.id IN (SELECT value FROM json_each(@eligible)))
         ORDER BY COALESCE(r.wilson_lb, 0) DESC, c.last_seen DESC
         LIMIT @limit`).all({ limit: Math.max(limit + exclude.size, limit), eligible: eligibleIds ? JSON.stringify([...eligibleIds]) : null });
        const out = [];
        for (const row of rows) {
          if (exclude.has(row.id))
            continue;
          const entry = this.activeCapability(row.id);
          if (entry)
            out.push(entry);
          if (out.length >= limit)
            break;
        }
        return out;
      }
      // ── vectors & OATS ──────────────────────────────────────────────────────
      storeBaseVec(capability, vec, now = Date.now(), expected) {
        if (vec.length === 0 || vec.some((value) => !Number.isFinite(value)))
          return false;
        const normalized = normalize(vec);
        const result = this.db.prepare(`INSERT INTO vec(capability, dims, base, adj, updated_at)
         SELECT @capability, @dims, @base, NULL, @updatedAt
         WHERE @guarded = 0 OR (
           EXISTS (
             SELECT 1 FROM capability
             WHERE id = @capability AND def_hash = @expectedDefHash
           )
           AND EXISTS (
             SELECT 1 FROM meta
             WHERE key = 'embedding_model' AND value = @expectedModelId
           )
         )
         ON CONFLICT(capability) DO UPDATE SET
           -- a dims change means a different embedding space: the old adj is
           -- meaningless there and must not survive the base rewrite
           adj = CASE WHEN vec.dims != excluded.dims THEN NULL ELSE vec.adj END,
           dims = excluded.dims, base = excluded.base, updated_at = excluded.updated_at`).run({
          capability,
          dims: normalized.length,
          base: vecToBlob(normalized),
          updatedAt: now,
          guarded: expected ? 1 : 0,
          expectedDefHash: expected?.defHash ?? null,
          expectedModelId: expected?.modelId ?? null
        });
        return result.changes === 1;
      }
      storeNeedVec(needHash, vec, now = Date.now()) {
        if (vec.length === 0 || vec.some((value) => !Number.isFinite(value)))
          return;
        const normalized = normalize(vec);
        this.db.prepare(`INSERT INTO need_vec(need_hash, dims, vec, ts) VALUES(?,?,?,?)
         ON CONFLICT(need_hash) DO UPDATE SET dims=excluded.dims, vec=excluded.vec, ts=excluded.ts`).run(needHash, normalized.length, vecToBlob(normalized), now);
      }
      /** Ids that already have a stored vector (same model, post model-switch guard) —
       *  lets warm boots skip re-embedding what's already there instead of re-doing
       *  the whole roster every serve process (audit D4). */
      vecCapabilityIds() {
        const rows = this.validVecRows();
        return new Set(rows.map((r) => r.capability));
      }
      /** adj if present, else base — the vector drafts actually use. */
      loadVecs() {
        const rows = this.validVecRows();
        const map = /* @__PURE__ */ new Map();
        for (const row of rows) {
          map.set(row.capability, blobToVec(row.adj ?? row.base, row.dims));
        }
        return map;
      }
      /**
       * Validate and repair stored base/adjustment vectors under one writer lock.
       * A corrupt base makes the row backfill-eligible; a corrupt derived
       * adjustment is losslessly cleared so routing falls back to the valid base.
       */
      validVecRows() {
        const read = this.db.prepare("SELECT capability, dims, base, adj, updated_at FROM vec");
        const deleteBase = this.db.prepare("DELETE FROM vec WHERE capability = ?");
        const clearAdj = this.db.prepare("UPDATE vec SET adj = NULL WHERE capability = ?");
        const repair = this.db.transaction(() => {
          const rows = read.all();
          const valid = [];
          for (const row of rows) {
            try {
              blobToVec(row.base, row.dims);
            } catch {
              deleteBase.run(row.capability);
              continue;
            }
            if (row.adj !== null) {
              try {
                blobToVec(row.adj, row.dims);
              } catch {
                clearAdj.run(row.capability);
                row.adj = null;
              }
            }
            valid.push(row);
          }
          return valid;
        });
        return repair.immediate();
      }
      /**
       * Nightly OATS (§6.2). Positives: need vectors where the capability succeeded.
       * Negatives: need vectors where it was called and failed attributably — a
       * conservative superset of the paper's "ranked #1 but failed" (we know these
       * needs actually reached the tool). Window 90 days, cap 500 per side.
       */
      runOats(now = Date.now()) {
        const since = now - 90 * 24 * 3600 * 1e3;
        const caps = this.validVecRows();
        const needVecStmt = this.db.prepare("SELECT dims, vec FROM need_vec WHERE need_hash = ?");
        const deleteNeedVecStmt = this.db.prepare("DELETE FROM need_vec WHERE need_hash = ? AND dims = ? AND vec = ?");
        const positivesStmt = this.db.prepare(`SELECT need_hash, class FROM outcome
       WHERE capability = ? AND ts >= ? AND need_hash IS NOT NULL
         AND explored = 0 AND soft_fail = 0 AND class = 'success'
       ORDER BY ts DESC LIMIT 500`);
        const negativesStmt = this.db.prepare(`SELECT need_hash, class FROM outcome
       WHERE capability = ? AND ts >= ? AND need_hash IS NOT NULL
         AND explored = 0 AND soft_fail = 0 AND class != 'success'
       ORDER BY ts DESC LIMIT 500`);
        let adjusted = 0;
        let skipped = 0;
        const writeAdj = this.db.prepare("UPDATE vec SET adj = ?, updated_at = ? WHERE capability = ? AND dims = ? AND base = ? AND adj IS ? AND updated_at = ?");
        for (const cap of caps) {
          const rows = [
            ...positivesStmt.all(cap.capability, since),
            ...negativesStmt.all(cap.capability, since)
          ];
          const positives = [];
          const negatives = [];
          for (const row of rows) {
            const nv = needVecStmt.get(row.need_hash);
            if (!nv)
              continue;
            let vec;
            try {
              vec = blobToVec(nv.vec, nv.dims);
            } catch {
              deleteNeedVecStmt.run(row.need_hash, nv.dims, nv.vec);
              continue;
            }
            if (nv.dims !== cap.dims)
              continue;
            if (row.class === "success")
              positives.push(vec);
            else if (isAttributable(row.class))
              negatives.push(vec);
          }
          const base = blobToVec(cap.base, cap.dims);
          const result = oatsAdjust(base, positives, negatives);
          const written = writeAdj.run(result.applied ? vecToBlob(result.vec) : null, now, cap.capability, cap.dims, cap.base, cap.adj, cap.updated_at);
          if (result.applied && written.changes === 1)
            adjusted += 1;
          else
            skipped += 1;
        }
        return { adjusted, skipped };
      }
    };
  }
});

// ../coach/dist/embeddings.js
import { createRequire } from "node:module";
import os2 from "node:os";
import path2 from "node:path";
import { pathToFileURL } from "node:url";
function setDenseRuntimeDir(dir) {
  denseRuntimeDir = dir;
}
async function loadTransformers() {
  try {
    return await import("@huggingface/transformers");
  } catch (error) {
    if (denseRuntimeDir === null)
      throw error;
    const require_ = createRequire(path2.join(denseRuntimeDir, "resolve-from.js"));
    const entry = require_.resolve("@huggingface/transformers");
    return await import(pathToFileURL(entry).href);
  }
}
function selectModelId(totalMemBytes = os2.totalmem()) {
  return totalMemBytes >= EIGHT_GIB ? GEMMA_MODEL : MINILM_MODEL;
}
function truncateAndNormalize(vec, dims = MATRYOSHKA_DIMS) {
  const sliced = vec.length > dims ? vec.slice(0, dims) : vec;
  let norm = 0;
  for (const x of sliced)
    norm += x * x;
  norm = Math.sqrt(norm);
  if (norm === 0)
    return new Float32Array(sliced.length);
  const out = new Float32Array(sliced.length);
  for (let i = 0; i < sliced.length; i++)
    out[i] = sliced[i] / norm;
  return out;
}
function gemmaPrefix(kind, text) {
  return kind === "query" ? `task: search result | query: ${text}` : `title: none | text: ${text}`;
}
var denseRuntimeDir, GEMMA_MODEL, MINILM_MODEL, MATRYOSHKA_DIMS, MINILM_NATIVE_DIMS, EIGHT_GIB, IDLE_UNLOAD_MS, TransformersEmbeddings;
var init_embeddings = __esm({
  "../coach/dist/embeddings.js"() {
    "use strict";
    denseRuntimeDir = null;
    GEMMA_MODEL = "onnx-community/embeddinggemma-300m-ONNX";
    MINILM_MODEL = "Xenova/all-MiniLM-L6-v2";
    MATRYOSHKA_DIMS = 256;
    MINILM_NATIVE_DIMS = 384;
    EIGHT_GIB = 8 * 1024 * 1024 * 1024;
    IDLE_UNLOAD_MS = 10 * 60 * 1e3;
    TransformersEmbeddings = class {
      modelId;
      /** Matryoshka truncation applies ONLY to models trained for it (Gemma). */
      dims;
      pipe = null;
      queue = Promise.resolve();
      idleTimer = null;
      disposed = false;
      constructor(modelId = selectModelId()) {
        this.modelId = modelId;
        this.dims = modelId === GEMMA_MODEL ? MATRYOSHKA_DIMS : MINILM_NATIVE_DIMS;
      }
      static async isAvailable() {
        try {
          await loadTransformers();
          return true;
        } catch {
          return false;
        }
      }
      async embed(texts, kind = "document") {
        if (this.disposed)
          throw new Error("embeddings provider disposed");
        const isGemma = this.modelId === GEMMA_MODEL;
        const prepared = isGemma ? texts.map((t) => gemmaPrefix(kind, t)) : [...texts];
        const run = this.queue.then(async () => {
          const pipe = await this.loadPipeline();
          const output = await pipe(prepared, { pooling: "mean", normalize: true });
          this.touchIdleTimer();
          return output.tolist().map((row) => isGemma ? truncateAndNormalize(new Float32Array(row)) : new Float32Array(row));
        });
        this.queue = run.catch(() => void 0);
        return run;
      }
      async dispose() {
        this.disposed = true;
        if (this.idleTimer)
          clearTimeout(this.idleTimer);
        this.idleTimer = null;
        await this.unloadThroughQueue();
      }
      async loadPipeline() {
        if (this.pipe)
          return this.pipe;
        if (this.disposed)
          throw new Error("embeddings provider disposed");
        const { pipeline } = await loadTransformers();
        this.pipe = await pipeline("feature-extraction", this.modelId, {
          dtype: "q8"
        });
        this.touchIdleTimer();
        return this.pipe;
      }
      touchIdleTimer() {
        if (this.idleTimer)
          clearTimeout(this.idleTimer);
        this.idleTimer = setTimeout(() => {
          void this.unloadThroughQueue();
        }, IDLE_UNLOAD_MS);
        this.idleTimer.unref?.();
      }
      /** Unload serialized behind in-flight embeds so a session is never freed mid-call. */
      async unloadThroughQueue() {
        const run = this.queue.then(async () => {
          const pipe = this.pipe;
          this.pipe = null;
          if (pipe?.dispose) {
            await pipe.dispose().catch(() => void 0);
          }
        });
        this.queue = run.catch(() => void 0);
        await run;
      }
    };
  }
});

// ../coach/dist/index.js
var dist_exports = {};
__export(dist_exports, {
  CoachStore: () => CoachStore,
  GEMMA_MODEL: () => GEMMA_MODEL,
  MATRYOSHKA_DIMS: () => MATRYOSHKA_DIMS,
  MINILM_MODEL: () => MINILM_MODEL,
  TransformersEmbeddings: () => TransformersEmbeddings,
  classifyOutcome: () => classifyOutcome,
  classifyToolFailKind: () => classifyToolFailKind,
  cosine: () => cosine,
  defHash: () => defHash,
  hashArgs: () => hashArgs,
  hashNeed: () => hashNeed,
  isAttributable: () => isAttributable,
  meanVec: () => meanVec,
  normalize: () => normalize,
  oatsAdjust: () => oatsAdjust,
  openCoachDb: () => openCoachDb,
  selectModelId: () => selectModelId,
  setDenseRuntimeDir: () => setDenseRuntimeDir,
  sha256Hex: () => sha256Hex,
  stableStringify: () => stableStringify,
  truncateAndNormalize: () => truncateAndNormalize
});
var init_dist2 = __esm({
  "../coach/dist/index.js"() {
    "use strict";
    init_db();
    init_classifier();
    init_oats();
    init_store();
    init_embeddings();
    init_util();
  }
});

// ../combine/dist/task.js
import { parse as parseYaml3 } from "yaml";
function parseSuite(yamlContent) {
  const raw = parseYaml3(yamlContent);
  if (!isRecord4(raw))
    throw new Error("suite: not an object");
  const suite = requireString(raw, "suite");
  const version = requireString(raw, "version");
  const category = requireString(raw, "category");
  if (!Array.isArray(raw.tasks) || raw.tasks.length === 0)
    throw new Error("suite: tasks[] required");
  const tasks = raw.tasks.map((t, i) => parseTask(t, category, i));
  const ids = new Set(tasks.map((t) => t.id));
  if (ids.size !== tasks.length)
    throw new Error("suite: duplicate task ids");
  return { suite, version, category, tasks };
}
function parseTask(raw, category, index) {
  const where = `tasks[${index}]`;
  if (!isRecord4(raw))
    throw new Error(`${where}: task must be an object`);
  const id = requireString(raw, "id", where);
  const invoke = raw.invoke;
  if (!isRecord4(invoke))
    throw new Error(`${where}: invoke required`);
  const tool = requireString(invoke, "tool", `${where}.invoke`);
  const args = invoke.args;
  if (args !== void 0 && !isRecord4(args)) {
    throw new Error(`${where}.invoke: args must be an object`);
  }
  const setup = parseSetup(raw.setup, where);
  const verifyRaw = raw.verify;
  if (!Array.isArray(verifyRaw) || verifyRaw.length === 0) {
    throw new Error(`${where}: verify[] required \u2014 unverifiable tasks are not tasks`);
  }
  const verify = verifyRaw.map((entry, j) => parseVerifier(entry, `${where}.verify[${j}]`));
  const description = raw.description;
  if (description !== void 0 && typeof description !== "string") {
    throw new Error(`${where}: description must be a string`);
  }
  const timeoutMs = raw.timeoutMs;
  if (timeoutMs !== void 0 && (typeof timeoutMs !== "number" || !Number.isFinite(timeoutMs) || timeoutMs <= 0)) {
    throw new Error(`${where}: timeoutMs must be a finite positive number`);
  }
  return {
    id,
    category,
    mode: raw.mode === "readonly-live" ? "readonly-live" : "sandboxed",
    signed: raw.signed === true,
    description,
    setup,
    invoke: { tool, args: args ?? {} },
    verify,
    timeoutMs: timeoutMs ?? 3e4
  };
}
function parseSetup(raw, taskWhere) {
  if (raw === void 0)
    return void 0;
  if (!isRecord4(raw))
    throw new Error(`${taskWhere}.setup: must be an object`);
  const files = raw.files;
  if (files === void 0)
    return {};
  if (!isRecord4(files))
    throw new Error(`${taskWhere}.setup.files: must be an object`);
  const parsedFiles = [];
  for (const [path17, contents] of Object.entries(files)) {
    if (typeof contents !== "string") {
      throw new Error(`${taskWhere}.setup.files: ${path17} must have string contents`);
    }
    parsedFiles.push([path17, contents]);
  }
  return { files: Object.fromEntries(parsedFiles) };
}
function parseVerifier(raw, where) {
  if (!isRecord4(raw))
    throw new Error(`${where}: verifier must be an object`);
  const kind = raw.kind;
  if (!isVerifierKind(kind)) {
    throw new Error(`${where}: unknown kind`);
  }
  if (kind === "fileEquals") {
    return { kind, path: requireString(raw, "path", where), equals: requireString(raw, "equals", where) };
  }
  if (kind === "fileContains") {
    return { kind, path: requireString(raw, "path", where), contains: requireString(raw, "contains", where) };
  }
  if (kind === "fileExists" || kind === "dirExists" || kind === "fileAbsent") {
    return { kind, path: requireString(raw, "path", where) };
  }
  return { kind, contains: requireString(raw, "contains", where) };
}
function requireString(obj, key, where = "suite") {
  const value = obj[key];
  if (typeof value !== "string" || value === "")
    throw new Error(`${where}: ${key} required`);
  return value;
}
function isRecord4(value) {
  if (value === null || typeof value !== "object" || Array.isArray(value))
    return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}
function isVerifierKind(value) {
  return value === "fileEquals" || value === "fileContains" || value === "fileExists" || value === "dirExists" || value === "fileAbsent" || value === "resultContains";
}
function template(value, vars) {
  if (typeof value === "string") {
    return value.replaceAll("{{sandbox}}", vars.sandbox).replaceAll("{{run_id}}", vars.runId);
  }
  if (Array.isArray(value))
    return value.map((v) => template(v, vars));
  if (value !== null && typeof value === "object") {
    return Object.fromEntries(Object.entries(value).map(([k, v]) => [k, template(v, vars)]));
  }
  return value;
}
var init_task = __esm({
  "../combine/dist/task.js"() {
    "use strict";
  }
});

// ../combine/dist/failProbes.js
function assertFailProbeArtifact(suite, artifact) {
  if (suite.tasks.some((task) => task.signed)) {
    throw new Error("fail-probe suite tasks must be unsigned");
  }
  if (!isRecord5(artifact) || !Array.isArray(artifact.runs) || artifact.runs.length !== 1) {
    throw new Error("fail-probe artifact must contain exactly one run");
  }
  const run = artifact.runs[0];
  if (!isRecord5(run) || run.suite !== suite.suite || run.suiteVersion !== suite.version || run.category !== suite.category) {
    throw new Error("fail-probe artifact does not match the authoritative suite");
  }
  if (!Array.isArray(run.results) || run.results.length !== suite.tasks.length) {
    throw new Error("fail-probe artifact lacks complete authoritative task coverage");
  }
  for (const [index, task] of suite.tasks.entries()) {
    const result = run.results[index];
    if (!isRecord5(result) || result.taskId !== task.id) {
      throw new Error(`fail-probe result order does not match the expected task at index ${index}`);
    }
    if (result.signed !== false) {
      throw new Error(`fail-probe ${task.id} must remain unsigned`);
    }
    if (result.pass !== false) {
      throw new Error(`fail-probe ${task.id} unexpectedly passed`);
    }
    if (result.stage !== "verify") {
      throw new Error(`fail-probe ${task.id} must fail at verify, not ${safeStage(result.stage)}`);
    }
  }
  if (!isRecord5(run.summary) || run.summary.n !== suite.tasks.length || run.summary.passes !== 0 || run.summary.signedN !== 0) {
    throw new Error("fail-probe summary does not match its verified unsigned task rows");
  }
  return { taskCount: suite.tasks.length };
}
function safeStage(value) {
  if (value === "transport" || value === "invoke" || value === "verify") {
    return value;
  }
  return value === null ? "no stage" : "an invalid stage";
}
function isRecord5(value) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    return false;
  }
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}
var init_failProbes = __esm({
  "../combine/dist/failProbes.js"() {
    "use strict";
  }
});

// ../combine/dist/safeVerifierRead.js
import fs14 from "node:fs";
import path15 from "node:path";
function readVerifierFile(file, options) {
  const maxBytes = options.maxBytes ?? MAX_VERIFIER_FILE_BYTES;
  if (!Number.isSafeInteger(maxBytes) || maxBytes < 1) {
    throw new Error("verifier read limit must be a positive safe integer");
  }
  const before = snapshotContainedPath(options.sandboxRoot, file);
  const fd = fs14.openSync(file, fs14.constants.O_RDONLY | NON_BLOCK2 | NO_FOLLOW3);
  try {
    const openedBefore = fs14.fstatSync(fd, { bigint: true });
    const afterOpen = snapshotContainedPath(options.sandboxRoot, file);
    if (!openedBefore.isFile() || !sameIdentity3(openedBefore, afterOpen.file) || !sameSnapshot2(before, afterOpen)) {
      throw new Error("verifier path changed while being opened");
    }
    const buf = Buffer.allocUnsafe(maxBytes + 1);
    let n = 0;
    while (n < buf.length) {
      const read = fs14.readSync(fd, buf, n, buf.length - n, n);
      if (read === 0)
        break;
      n += read;
    }
    const openedAfter = fs14.fstatSync(fd, { bigint: true });
    const afterRead = snapshotContainedPath(options.sandboxRoot, file);
    if (!sameStableFile3(openedBefore, openedAfter) || !sameIdentity3(openedAfter, afterRead.file) || !sameSnapshot2(before, afterRead)) {
      throw new Error("verifier path changed while being read");
    }
    const truncated = n > maxBytes;
    return { text: buf.subarray(0, truncated ? maxBytes : n).toString("utf8"), truncated };
  } finally {
    fs14.closeSync(fd);
  }
}
function snapshotContainedPath(sandboxRoot, file) {
  const root = path15.resolve(sandboxRoot);
  const target = path15.resolve(file);
  const rel = path15.relative(root, target);
  if (rel === "" || rel === "." || rel === ".." || rel.startsWith(`..${path15.sep}`) || path15.isAbsolute(rel)) {
    throw new Error("verifier path escapes sandbox");
  }
  const parts = rel.split(path15.sep);
  const directories = [];
  let current = root;
  const rootStat = fs14.lstatSync(current, { bigint: true });
  if (!rootStat.isDirectory() || rootStat.isSymbolicLink()) {
    throw new Error("verifier sandbox is not a regular directory");
  }
  directories.push(rootStat);
  for (const part of parts.slice(0, -1)) {
    current = path15.join(current, part);
    const stat = fs14.lstatSync(current, { bigint: true });
    if (!stat.isDirectory() || stat.isSymbolicLink()) {
      throw new Error("verifier path contains a non-directory or symlink");
    }
    directories.push(stat);
  }
  const named = fs14.lstatSync(target, { bigint: true });
  if (!named.isFile() || named.isSymbolicLink()) {
    throw new Error("refusing to read a non-regular file");
  }
  return { directories, file: named };
}
function sameSnapshot2(left, right) {
  return left.directories.length === right.directories.length && left.directories.every((stat, index) => sameIdentity3(stat, right.directories[index])) && sameIdentity3(left.file, right.file);
}
function sameIdentity3(left, right) {
  return left.dev === right.dev && left.ino === right.ino;
}
function sameStableFile3(left, right) {
  return right.isFile() && sameIdentity3(left, right) && left.size === right.size && left.mtimeNs === right.mtimeNs && left.ctimeNs === right.ctimeNs;
}
var NON_BLOCK2, NO_FOLLOW3, MAX_VERIFIER_FILE_BYTES;
var init_safeVerifierRead = __esm({
  "../combine/dist/safeVerifierRead.js"() {
    "use strict";
    NON_BLOCK2 = fs14.constants.O_NONBLOCK ?? 0;
    NO_FOLLOW3 = fs14.constants.O_NOFOLLOW ?? 0;
    MAX_VERIFIER_FILE_BYTES = 8 * 1024 * 1024;
  }
});

// ../combine/dist/runner.js
import { randomUUID as randomUUID2 } from "node:crypto";
import fs15 from "node:fs";
import os4 from "node:os";
import path16 from "node:path";
import { Client as Client2 } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport as StdioClientTransport2 } from "@modelcontextprotocol/sdk/client/stdio.js";
function failureCode(err) {
  if (err instanceof Error && err.message === CONNECT_TIMEOUT_LABEL)
    return "connect-timeout";
  const code = err?.code;
  if (typeof code === "number" && Number.isInteger(code))
    return `mcp-error:${code}`;
  if (typeof code === "string" && /^[A-Z][A-Z0-9_]*$/.test(code))
    return `system-error:${code}`;
  return "unknown-error";
}
async function withTimeout2(promise, ms, label) {
  let timer;
  try {
    return await Promise.race([
      promise,
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error(label)), ms);
        timer.unref?.();
      })
    ]);
  } finally {
    if (timer)
      clearTimeout(timer);
  }
}
function containedPath(sandbox, rel) {
  const resolved = path16.resolve(sandbox, rel);
  if (resolved !== sandbox && !resolved.startsWith(sandbox + path16.sep)) {
    throw new Error(`path escapes sandbox: ${rel}`);
  }
  return resolved;
}
async function runSuite(suite, server) {
  const results = [];
  for (const task of suite.tasks) {
    results.push(await runTask(task, server));
  }
  return {
    server: server.name,
    suite: suite.suite,
    suiteVersion: suite.version,
    category: suite.category,
    results
  };
}
async function runTask(task, server) {
  const sandbox = fs15.realpathSync(fs15.mkdtempSync(path16.join(os4.tmpdir(), "roster-combine-")));
  const vars = { sandbox, runId: randomUUID2().slice(0, 8) };
  const started = Date.now();
  let client = null;
  try {
    for (const [rel, content] of Object.entries(task.setup?.files ?? {})) {
      const abs = containedPath(sandbox, template(rel, vars));
      fs15.mkdirSync(path16.dirname(abs), { recursive: true });
      fs15.writeFileSync(abs, template(content, vars));
    }
    client = new Client2({ name: "roster-combine", version: "0.0.1" });
    const transport = new StdioClientTransport2({
      command: server.command,
      args: (server.args ?? []).map((a) => template(a, vars)),
      env: server.env,
      stderr: "ignore"
    });
    await withTimeout2(client.connect(transport), CONNECT_TIMEOUT_MS, CONNECT_TIMEOUT_LABEL);
    const args = template(task.invoke.args, vars);
    let result;
    try {
      result = await client.callTool({ name: task.invoke.tool, arguments: args }, void 0, {
        timeout: task.timeoutMs
      });
    } catch (err) {
      return finish(task, started, false, "invoke", failureCode(err));
    }
    if (result.isError === true) {
      return finish(task, started, false, "invoke", "tool-returned-isError");
    }
    for (const verifier of task.verify) {
      const failure = checkVerifier(verifier, sandbox, result, vars);
      if (failure)
        return finish(task, started, false, "verify", failure);
    }
    return finish(task, started, true, null, null);
  } catch (err) {
    return finish(task, started, false, "transport", failureCode(err));
  } finally {
    await client?.close().catch(() => void 0);
    fs15.rmSync(sandbox, { recursive: true, force: true });
  }
}
function checkVerifier(verifier, sandbox, result, vars) {
  const resolvePath = (rel) => containedPath(sandbox, template(rel, vars));
  switch (verifier.kind) {
    case "fileExists": {
      const p = resolvePath(verifier.path);
      if (!entryIsSafeExact(sandbox, p))
        return `expected ${verifier.path} to exist`;
      return fs15.lstatSync(p).isFile() ? null : `expected ${verifier.path} to be a regular file`;
    }
    case "dirExists": {
      const p = resolvePath(verifier.path);
      if (!entryIsSafeExact(sandbox, p))
        return `expected directory ${verifier.path} to exist`;
      return fs15.lstatSync(p).isDirectory() ? null : `expected ${verifier.path} to be a directory`;
    }
    case "fileAbsent":
      return entryIsAbsentExact(sandbox, resolvePath(verifier.path)) ? null : `expected ${verifier.path} to be absent`;
    case "fileEquals": {
      const p = resolvePath(verifier.path);
      if (!entryIsSafeExact(sandbox, p))
        return `expected ${verifier.path} to exist`;
      let read;
      try {
        read = readVerifierFile(p, { sandboxRoot: sandbox });
      } catch {
        return `expected ${verifier.path} to be a readable regular file`;
      }
      if (read.truncated)
        return `content mismatch in ${verifier.path}`;
      const expected = template(verifier.equals, vars);
      return read.text === expected ? null : `content mismatch in ${verifier.path}`;
    }
    case "fileContains": {
      const p = resolvePath(verifier.path);
      if (!entryIsSafeExact(sandbox, p))
        return `expected ${verifier.path} to exist`;
      let read;
      try {
        read = readVerifierFile(p, { sandboxRoot: sandbox });
      } catch {
        return `expected ${verifier.path} to be a readable regular file`;
      }
      return read.text.includes(template(verifier.contains, vars)) ? null : `missing expected content in ${verifier.path}`;
    }
    case "resultContains": {
      const expected = template(verifier.contains, vars);
      return extractText(result).includes(expected) ? null : `result text missing expected content`;
    }
  }
}
function entryIsSafeExact(sandbox, abs) {
  const sandboxRoot = fs15.realpathSync(sandbox);
  const rel = path16.relative(sandboxRoot, abs);
  if (leavesSandbox(rel))
    return false;
  if (rel === "" || rel === ".")
    return true;
  const parts = rel.split(path16.sep);
  let candidate = sandboxRoot;
  for (const part of parts) {
    let entries;
    try {
      entries = fs15.readdirSync(candidate);
    } catch {
      return false;
    }
    if (!entries.includes(part))
      return false;
    candidate = path16.join(candidate, part);
    try {
      if (fs15.lstatSync(candidate).isSymbolicLink())
        return false;
    } catch {
      return false;
    }
  }
  try {
    const realCandidate = fs15.realpathSync(candidate);
    return realCandidate === sandboxRoot || realCandidate.startsWith(sandboxRoot + path16.sep);
  } catch {
    return false;
  }
}
function entryIsAbsentExact(sandbox, abs) {
  const sandboxRoot = fs15.realpathSync(sandbox);
  const rel = path16.relative(sandboxRoot, abs);
  if (rel === "" || rel === "." || leavesSandbox(rel))
    return false;
  const parts = rel.split(path16.sep);
  let directory = sandboxRoot;
  for (const [index, part] of parts.entries()) {
    let entries;
    try {
      entries = fs15.readdirSync(directory);
    } catch {
      return false;
    }
    if (!entries.includes(part))
      return true;
    const candidate = path16.join(directory, part);
    try {
      const stat = fs15.lstatSync(candidate);
      if (stat.isSymbolicLink())
        return false;
      if (!stat.isDirectory() && index !== parts.length - 1)
        return true;
    } catch {
      return false;
    }
    directory = candidate;
  }
  return false;
}
function leavesSandbox(relativePath) {
  return path16.isAbsolute(relativePath) || relativePath === ".." || relativePath.startsWith(`..${path16.sep}`);
}
function extractText(result) {
  const content = result.content;
  if (!Array.isArray(content))
    return "";
  return content.map((c) => c && typeof c === "object" && "text" in c ? String(c.text) : "").join("\n");
}
function finish(task, started, pass, stage, detail) {
  return { taskId: task.id, signed: task.signed, pass, stage, detail, latencyMs: Date.now() - started };
}
var CONNECT_TIMEOUT_MS, CONNECT_TIMEOUT_LABEL;
var init_runner = __esm({
  "../combine/dist/runner.js"() {
    "use strict";
    init_safeVerifierRead();
    init_task();
    CONNECT_TIMEOUT_MS = 15e3;
    CONNECT_TIMEOUT_LABEL = "connect timeout";
  }
});

// ../combine/dist/results.js
import { createHash as createHash3 } from "node:crypto";
import os5 from "node:os";
function summarizeResults(results) {
  const n = results.length;
  const passes = results.filter((r) => r.pass).length;
  const signed = results.filter((r) => r.signed);
  const signedPasses = signed.filter((r) => r.pass).length;
  return {
    n,
    passes,
    passRate: n > 0 ? passes / n : 0,
    wilsonLb: wilsonLowerBound(passes, n),
    signedN: signed.length,
    signedPasses,
    signedWilsonLb: wilsonLowerBound(signedPasses, signed.length)
  };
}
function buildLabResults(runs, now = /* @__PURE__ */ new Date()) {
  const environment = { node: process.version, platform: os5.platform(), arch: os5.arch() };
  const environmentDigest = createHash3("sha256").update(JSON.stringify({ environment, suites: runs.map((r) => `${r.suite}@${r.suiteVersion}`) })).digest("hex");
  return {
    generatedAt: now.toISOString(),
    environment,
    environmentDigest,
    runs: runs.map((run) => ({ ...run, summary: summarizeResults(run.results) }))
  };
}
var init_results = __esm({
  "../combine/dist/results.js"() {
    "use strict";
    init_dist();
  }
});

// ../combine/dist/index.js
var dist_exports2 = {};
__export(dist_exports2, {
  MAX_VERIFIER_FILE_BYTES: () => MAX_VERIFIER_FILE_BYTES,
  assertFailProbeArtifact: () => assertFailProbeArtifact,
  buildLabResults: () => buildLabResults,
  parseSuite: () => parseSuite,
  readVerifierFile: () => readVerifierFile,
  runSuite: () => runSuite,
  summarizeResults: () => summarizeResults,
  template: () => template
});
var init_dist3 = __esm({
  "../combine/dist/index.js"() {
    "use strict";
    init_task();
    init_failProbes();
    init_runner();
    init_results();
    init_safeVerifierRead();
  }
});

// src/dense.ts
init_paths();
import { spawnSync } from "node:child_process";
import fs7 from "node:fs";
import { createRequire as createRequire2 } from "node:module";
import path7 from "node:path";

// src/rosterfile.ts
init_dist2();
import crypto2 from "node:crypto";
import fs5 from "node:fs";
import path5 from "node:path";

// src/entry.ts
import fs3 from "node:fs";
import path3 from "node:path";
import { fileURLToPath } from "node:url";
function firstPathEntryMatches(binPath) {
  const names = process.platform === "win32" ? ["roster.cmd", "roster.exe", "roster"] : ["roster"];
  let expected;
  try {
    expected = fs3.realpathSync(binPath);
  } catch {
    return false;
  }
  for (const dir of (process.env.PATH ?? "").split(path3.delimiter)) {
    if (dir === "") continue;
    for (const n of names) {
      const p = path3.join(dir, n);
      try {
        if (!fs3.statSync(p).isFile()) continue;
        fs3.accessSync(p, fs3.constants.X_OK);
        return fs3.realpathSync(p) === expected;
      } catch {
      }
    }
  }
  return false;
}
function ourBinPath() {
  return path3.join(path3.dirname(fileURLToPath(import.meta.url)), "bin.js");
}
function verifiedRosterAliases() {
  const dir = path3.dirname(fileURLToPath(import.meta.url));
  const binaries = [ourBinPath(), path3.resolve(dir, "../bundle/bin.js"), path3.resolve(dir, "../dist/bin.js")];
  return binaries.some(firstPathEntryMatches) ? [{ command: "roster", args: ["serve"] }] : [];
}
var PACKAGE_NAME = "@roster/cli";
function runningFromNpxCache(binPath = ourBinPath()) {
  return binPath.split(path3.sep).includes("_npx");
}
function rosterEntry(binPath = ourBinPath()) {
  if (runningFromNpxCache(binPath)) return { command: "npx", args: ["-y", PACKAGE_NAME, "serve"] };
  return { command: process.execPath, args: [path3.resolve(binPath), "serve"] };
}
var INERT_CLIENT_KEYS = {
  type: (value) => value === "stdio"
  // a non-stdio transport is a CONFLICTING entry, not ours
};
var normalizeSpawnEntry = (v) => {
  if (v === null || typeof v !== "object" || Array.isArray(v)) return null;
  const e = v;
  if (typeof e.command !== "string") return null;
  if (e.args !== void 0 && (!Array.isArray(e.args) || e.args.some((arg) => typeof arg !== "string"))) {
    return null;
  }
  for (const key of Object.keys(e)) {
    if (key === "command" || key === "args") continue;
    const inert = INERT_CLIENT_KEYS[key];
    if (!inert?.(e[key])) return null;
  }
  return { command: e.command, args: e.args === void 0 ? [] : [...e.args] };
};
function sameEntry(candidate, injected) {
  const e = normalizeSpawnEntry(candidate);
  if (!e || !injected) return false;
  return e.command === injected.command && e.args.length === injected.args.length && e.args.every((a, i) => a === injected.args[i]);
}
function isOwnedRosterEntry(candidate, ownedEntries) {
  return ownedEntries.some((owned) => sameEntry(candidate, owned));
}

// src/lock.ts
init_paths();
import crypto from "node:crypto";
import fs4 from "node:fs";
import path4 from "node:path";
var LOCK_TIMEOUT_MS = 5e3;
var LOCK_POLL_MS = 20;
var CLAIM_BASENAME = ".reclaim";
var CLAIM_GRACE_MS = 1e3;
var OWNER_REMOVE_RETRIES = 10;
var TRANSIENT_REMOVE_CODES = /* @__PURE__ */ new Set(["EBUSY", "EACCES", "EPERM", "EMFILE", "ENFILE"]);
var RM_OPTS = { recursive: true, force: true, maxRetries: 10, retryDelay: 50 };
function sleepSync(ms) {
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
}
function removeOwnerFile(file, allowMissing) {
  for (let attempt = 0; ; attempt++) {
    try {
      fs4.unlinkSync(file);
      return true;
    } catch (error) {
      const code = error.code;
      if (code === "ENOENT" && allowMissing) return false;
      if (!TRANSIENT_REMOVE_CODES.has(code ?? "") || attempt >= OWNER_REMOVE_RETRIES) {
        throw error;
      }
      sleepSync(50);
    }
  }
}
function lockPath(key) {
  const digest = crypto.createHash("sha256").update(key).digest("hex");
  return path4.join(rosterHome(), "locks", `${digest}.lock`);
}
function ownerPath(dir) {
  return path4.join(dir, "owner.json");
}
function claimPath(dir) {
  return path4.join(dir, CLAIM_BASENAME);
}
function sameOwner(a, b) {
  return a !== null && a.pid === b.pid && a.token === b.token;
}
function mkdirWasContended(error, dir) {
  const code = error.code;
  if (code === "EEXIST") return true;
  if (code !== "EPERM" && code !== "EACCES" && code !== "EBUSY") return false;
  try {
    fs4.lstatSync(dir);
    return true;
  } catch {
    return false;
  }
}
function readOwnerState(dir) {
  let raw;
  try {
    raw = fs4.readFileSync(ownerPath(dir), "utf8");
  } catch (error) {
    return error.code === "ENOENT" ? { kind: "absent" } : { kind: "invalid" };
  }
  try {
    const parsed = JSON.parse(raw);
    if (typeof parsed.pid !== "number" || !Number.isSafeInteger(parsed.pid) || parsed.pid <= 0 || typeof parsed.token !== "string" || parsed.token === "") {
      return { kind: "invalid" };
    }
    return { kind: "owned", owner: { pid: parsed.pid, token: parsed.token } };
  } catch {
    return { kind: "invalid" };
  }
}
function readOwner(dir) {
  const state = readOwnerState(dir);
  return state.kind === "owned" ? state.owner : null;
}
function processIsAlive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch (error) {
    return error.code !== "ESRCH";
  }
}
function ensureLockSlot(dir) {
  try {
    fs4.mkdirSync(dir, { mode: PRIVATE_DIR });
  } catch (error) {
    if (!mkdirWasContended(error, dir)) throw error;
  }
  try {
    const stat = fs4.lstatSync(dir);
    if (stat.isSymbolicLink() || !stat.isDirectory()) return false;
    try {
      fs4.chmodSync(dir, PRIVATE_DIR);
    } catch {
    }
    return true;
  } catch {
    return false;
  }
}
function claimOwned(dir, claim) {
  return sameOwner(readOwner(claimPath(dir)), claim);
}
function retireClaim(dir, observed, observedCtime) {
  const claimDir = claimPath(dir);
  let currentStat;
  try {
    currentStat = fs4.lstatSync(claimDir);
    if (currentStat.isSymbolicLink() || !currentStat.isDirectory()) return false;
  } catch {
    return true;
  }
  const current = readOwnerState(claimDir);
  if (observed.kind === "owned") {
    if (current.kind !== "owned" || !sameOwner(current.owner, observed.owner)) return false;
    if (processIsAlive(current.owner.pid)) return false;
  } else {
    if (current.kind !== observed.kind || currentStat.ctimeMs !== observedCtime) return false;
    if (Math.max(0, Date.now() - currentStat.ctimeMs) < CLAIM_GRACE_MS) return false;
  }
  const retired = path4.join(
    dir,
    `${CLAIM_BASENAME}.stale-${process.pid}-${crypto.randomBytes(8).toString("hex")}`
  );
  try {
    fs4.renameSync(claimDir, retired);
  } catch {
    return false;
  }
  const moved = readOwnerState(retired);
  const safeToRemove = observed.kind === "owned" ? moved.kind === "owned" && sameOwner(moved.owner, observed.owner) && !processIsAlive(moved.owner.pid) : moved.kind === observed.kind;
  if (!safeToRemove) {
    try {
      fs4.renameSync(retired, claimDir);
    } catch {
    }
    return false;
  }
  fs4.rmSync(retired, RM_OPTS);
  return true;
}
function claimBlocks(dir) {
  const claimDir = claimPath(dir);
  let stat;
  try {
    stat = fs4.lstatSync(claimDir);
    if (stat.isSymbolicLink() || !stat.isDirectory()) return true;
  } catch {
    return false;
  }
  const state = readOwnerState(claimDir);
  if (state.kind === "owned" && processIsAlive(state.owner.pid)) return true;
  retireClaim(dir, state, stat.ctimeMs);
  try {
    fs4.lstatSync(claimDir);
    return true;
  } catch {
    return false;
  }
}
function tryAcquireClaim(dir) {
  const claimDir = claimPath(dir);
  try {
    fs4.mkdirSync(claimDir, { mode: PRIVATE_DIR });
  } catch (error) {
    if (mkdirWasContended(error, claimDir)) {
      claimBlocks(dir);
      return null;
    }
    if (dirVanished(error)) return null;
    throw error;
  }
  const claim = { pid: process.pid, token: crypto.randomBytes(16).toString("hex") };
  try {
    fs4.writeFileSync(ownerPath(claimDir), `${JSON.stringify(claim)}
`, {
      mode: PRIVATE_FILE,
      flag: "wx"
    });
  } catch (error) {
    const contended = dirVanished(error) || mkdirWasContended(error, claimDir);
    try {
      fs4.rmSync(claimDir, RM_OPTS);
    } catch {
    }
    if (contended) return null;
    throw error;
  }
  return claimOwned(dir, claim) ? claim : null;
}
function releaseClaim(dir, claim) {
  if (!claimOwned(dir, claim)) return;
  try {
    fs4.rmSync(claimPath(dir), RM_OPTS);
  } catch {
  }
}
function reclaimStaleLock(dir, observed) {
  if (!ensureLockSlot(dir) || claimBlocks(dir)) return "occupied";
  const stateBeforeClaim = readOwnerState(dir);
  if (stateBeforeClaim.kind === "absent") return "reclaimed";
  if (stateBeforeClaim.kind !== "owned" || !sameOwner(stateBeforeClaim.owner, observed)) {
    return "occupied";
  }
  const claim = tryAcquireClaim(dir);
  if (!claim) return "occupied";
  try {
    if (!claimOwned(dir, claim)) return "occupied";
    const current = readOwner(dir);
    if (!sameOwner(current, observed) || processIsAlive(observed.pid)) return "occupied";
    if (!claimOwned(dir, claim) || !sameOwner(readOwner(dir), observed)) return "occupied";
    try {
      removeOwnerFile(ownerPath(dir), true);
    } catch {
      return "occupied";
    }
    return "reclaimed";
  } finally {
    releaseClaim(dir, claim);
  }
}
function dirVanished(error) {
  const code = error.code;
  return code === "ENOENT" || code === "EINVAL" || code === "ENOTDIR";
}
function createOwner(dir) {
  const owner = { pid: process.pid, token: crypto.randomBytes(16).toString("hex") };
  try {
    fs4.writeFileSync(ownerPath(dir), `${JSON.stringify(owner)}
`, {
      mode: PRIVATE_FILE,
      flag: "wx"
    });
    return owner;
  } catch (error) {
    if (error.code === "EEXIST" || dirVanished(error) || mkdirWasContended(error, dir)) {
      return null;
    }
    throw error;
  }
}
function acquire(key) {
  ensureRosterHome();
  ensurePrivateDir(path4.join(rosterHome(), "locks"));
  const dir = lockPath(key);
  const deadline = Date.now() + LOCK_TIMEOUT_MS;
  while (true) {
    if (ensureLockSlot(dir) && !claimBlocks(dir)) {
      const owner = createOwner(dir);
      if (owner) return { dir, token: owner.token };
      const state = readOwnerState(dir);
      if (state.kind === "owned" && !processIsAlive(state.owner.pid)) {
        if (reclaimStaleLock(dir, state.owner) === "reclaimed") continue;
      } else if (state.kind === "absent") {
        continue;
      }
    }
    if (Date.now() >= deadline) {
      const state = readOwnerState(dir);
      throw new Error(
        `timed out waiting for Roster lock "${key}"${state.kind === "owned" ? ` held by pid ${state.owner.pid}` : " with unreadable ownership"}`
      );
    }
    sleepSync(LOCK_POLL_MS);
  }
}
function releaseMovedLock(dir, token) {
  const root = path4.dirname(dir);
  const prefix = `${path4.basename(dir)}.`;
  let entries;
  try {
    entries = fs4.readdirSync(root);
  } catch {
    return false;
  }
  for (const entry of entries) {
    if (!entry.startsWith(prefix)) continue;
    const candidate = path4.join(root, entry);
    const owner = readOwner(candidate);
    if (owner?.pid === process.pid && owner.token === token) {
      fs4.rmSync(candidate, RM_OPTS);
      return true;
    }
  }
  return false;
}
function release(dir, token) {
  const deadline = Date.now() + 250;
  for (; ; ) {
    const owner = readOwner(dir);
    if (owner && owner.pid === process.pid && owner.token === token) {
      try {
        removeOwnerFile(ownerPath(dir), false);
        return;
      } catch (error) {
        if (!dirVanished(error)) throw error;
      }
    }
    if (releaseMovedLock(dir, token)) return;
    if (Date.now() >= deadline) {
      throw new Error("Roster lock ownership changed before release");
    }
    sleepSync(LOCK_POLL_MS);
  }
}
function withFileLockSync(key, fn) {
  const held = acquire(key);
  let result;
  let failure;
  let didThrow = false;
  try {
    result = fn();
  } catch (error) {
    didThrow = true;
    failure = error;
  }
  try {
    release(held.dir, held.token);
  } catch (releaseError) {
    if (!didThrow) throw releaseError;
  }
  if (didThrow) throw failure;
  return result;
}

// src/rosterfile.ts
init_paths();
init_paths();
function resolveWriteTopology(sourcePath) {
  const source = path5.resolve(sourcePath);
  const stat = fs5.lstatSync(source);
  const writePath = fs5.realpathSync(source);
  if (stat.isSymbolicLink()) {
    const symlinkTarget = fs5.readlinkSync(source);
    if (!fs5.lstatSync(writePath).isFile()) {
      throw new Error(`client config symlink target is not a regular file: ${sourcePath}`);
    }
    return { sourcePath: source, writePath, symlinkTarget };
  }
  if (!stat.isFile()) {
    throw new Error(`client config is not a regular file: ${sourcePath}`);
  }
  return { sourcePath: source, writePath };
}
function projectedRealPath(target) {
  const suffix = [];
  let cursor = target;
  for (; ; ) {
    try {
      return path5.join(fs5.realpathSync(cursor), ...suffix.reverse());
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
      const parent = path5.dirname(cursor);
      if (parent === cursor) throw error;
      suffix.push(path5.basename(cursor));
      cursor = parent;
    }
  }
}
function validateWriteTopology(sourcePath, recordedWritePath, recordedSymlinkTarget) {
  const source = path5.resolve(sourcePath);
  if (recordedWritePath === void 0 && recordedSymlinkTarget === void 0) return source;
  if (recordedWritePath === void 0) {
    throw new Error("recorded symlink topology is missing its write path");
  }
  const writePath = path5.resolve(recordedWritePath);
  if (recordedSymlinkTarget !== void 0) {
    let sourceStat;
    try {
      sourceStat = fs5.lstatSync(source);
    } catch {
      throw new Error("recorded config symlink is missing");
    }
    if (!sourceStat.isSymbolicLink()) {
      throw new Error("recorded config symlink was replaced");
    }
    if (fs5.readlinkSync(source) !== recordedSymlinkTarget) {
      throw new Error("recorded config symlink target changed");
    }
    if (fs5.realpathSync(source) !== writePath) {
      throw new Error("recorded config symlink now resolves to a different target");
    }
    if (!fs5.lstatSync(writePath).isFile()) {
      throw new Error("recorded config write target is not a regular file");
    }
    return writePath;
  }
  try {
    const stat = fs5.lstatSync(source);
    if (stat.isSymbolicLink() || !stat.isFile()) {
      throw new Error("recorded regular config changed filesystem type");
    }
    if (fs5.realpathSync(source) !== writePath) {
      throw new Error("recorded config parent symlink now resolves to a different target");
    }
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
    if (projectedRealPath(source) !== writePath) {
      throw new Error("recorded config parent symlink now resolves to a different target");
    }
  }
  return writePath;
}
function existingMode(target) {
  try {
    return fs5.statSync(target).mode & 511;
  } catch {
    return void 0;
  }
}
function atomicWriteFileSync(target, data, mode, beforeReplace) {
  const tmp = `${target}.${process.pid}.${crypto2.randomBytes(6).toString("hex")}.tmp`;
  const finalMode = mode ?? existingMode(target) ?? PRIVATE_FILE;
  let fd;
  try {
    fd = fs5.openSync(tmp, "wx", PRIVATE_FILE);
    fs5.writeFileSync(fd, data);
    fs5.fchmodSync(fd, finalMode);
    fs5.fsyncSync(fd);
    fs5.closeSync(fd);
    fd = void 0;
    beforeReplace?.();
    fs5.renameSync(tmp, target);
    try {
      const parent = fs5.openSync(path5.dirname(target), "r");
      try {
        fs5.fsyncSync(parent);
      } finally {
        fs5.closeSync(parent);
      }
    } catch {
    }
  } catch (err) {
    if (fd !== void 0) {
      try {
        fs5.closeSync(fd);
      } catch {
      }
    }
    try {
      fs5.rmSync(tmp, { force: true });
    } catch {
    }
    throw err;
  }
}
function defaultConfig() {
  return {
    version: 1,
    mode: "transparent",
    servers: /* @__PURE__ */ Object.create(null),
    skillSources: [],
    telemetry: { enabled: false },
    embeddings: "auto"
  };
}
function loadConfig() {
  const p = rosterConfigPath();
  if (!fs5.existsSync(p)) return defaultConfig();
  let parsed;
  try {
    parsed = JSON.parse(fs5.readFileSync(p, "utf8"));
  } catch (err) {
    throw new Error(`~/.roster/roster.json is malformed JSON: ${err instanceof Error ? err.message : err}`);
  }
  return normalizeConfig(parsed);
}
function saveConfig(config) {
  ensureRosterHome();
  const normalized = normalizeConfig(config);
  atomicWriteFileSync(
    rosterConfigPath(),
    `${JSON.stringify(normalized, null, 2)}
`,
    PRIVATE_FILE
  );
}
function updateConfig(mutator) {
  return withFileLockSync("config", () => {
    const config = loadConfig();
    const result = mutator(config);
    saveConfig(config);
    return result;
  });
}
function isRecord(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function stringArray(value, field, fallback = []) {
  if (value === void 0) return [...fallback];
  if (!Array.isArray(value) || value.some((item) => typeof item !== "string")) {
    throw new Error(`~/.roster/roster.json ${field} must be an array of strings`);
  }
  return [...value];
}
function normalizeServer(value, field) {
  if (!isRecord(value)) {
    throw new Error(`~/.roster/roster.json ${field} must be an object`);
  }
  const unsupported = Object.keys(value).filter((key) => !["command", "args", "env", "url", "importedFrom"].includes(key));
  if (unsupported.length > 0) {
    throw new Error(`~/.roster/roster.json ${field} has unsupported settings: ${unsupported.join(", ")}`);
  }
  const command = value.command;
  const url = value.url;
  if (command !== void 0 && typeof command !== "string") {
    throw new Error(`~/.roster/roster.json ${field}.command must be a string`);
  }
  if (url !== void 0 && typeof url !== "string") {
    throw new Error(`~/.roster/roster.json ${field}.url must be a string`);
  }
  if (command === void 0 && url === void 0) {
    throw new Error(`~/.roster/roster.json ${field} must define command or url`);
  }
  let env;
  if (value.env !== void 0) {
    if (!isRecord(value.env) || Object.values(value.env).some((item) => typeof item !== "string")) {
      throw new Error(`~/.roster/roster.json ${field}.env must be an object of strings`);
    }
    env = Object.fromEntries(Object.entries(value.env));
  }
  return {
    ...command !== void 0 ? { command } : {},
    ...value.args !== void 0 ? { args: stringArray(value.args, `${field}.args`) } : {},
    ...env !== void 0 ? { env } : {},
    ...url !== void 0 ? { url } : {},
    importedFrom: stringArray(value.importedFrom, `${field}.importedFrom`)
  };
}
function normalizeConfig(value) {
  if (!isRecord(value)) {
    throw new Error("~/.roster/roster.json must be a JSON object");
  }
  if (value.version !== void 0 && value.version !== 1) {
    throw new Error("~/.roster/roster.json version must be 1");
  }
  if (value.mode !== void 0 && value.mode !== "transparent" && value.mode !== "five") {
    throw new Error('~/.roster/roster.json mode must be "transparent" or "five"');
  }
  if (value.embeddings !== void 0 && value.embeddings !== "auto" && value.embeddings !== "off") {
    throw new Error('~/.roster/roster.json embeddings must be "auto" or "off"');
  }
  if (value.servers !== void 0 && !isRecord(value.servers)) {
    throw new Error("~/.roster/roster.json servers must be an object");
  }
  const servers = /* @__PURE__ */ Object.create(null);
  for (const [name, server] of Object.entries(value.servers ?? {})) {
    servers[name] = normalizeServer(server, `servers.${name}`);
  }
  let telemetryEnabled = false;
  if (value.telemetry !== void 0) {
    if (!isRecord(value.telemetry)) {
      throw new Error("~/.roster/roster.json telemetry must be an object");
    }
    if (value.telemetry.enabled !== void 0 && typeof value.telemetry.enabled !== "boolean") {
      throw new Error("~/.roster/roster.json telemetry.enabled must be a boolean");
    }
    telemetryEnabled = value.telemetry.enabled === true;
  }
  return {
    version: 1,
    mode: value.mode === "five" ? "five" : "transparent",
    servers,
    skillSources: stringArray(value.skillSources, "skillSources"),
    telemetry: { enabled: telemetryEnabled },
    embeddings: value.embeddings === "off" ? "off" : "auto"
  };
}
function serverIdentity(server) {
  return sha256Hex(
    JSON.stringify({
      command: server.command ?? null,
      args: server.args ?? [],
      url: server.url ?? null,
      env: Object.fromEntries(Object.entries(server.env ?? {}).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0))
    })
  );
}
function mergeServers(config, imported, ownedEntries = [rosterEntry(), ...verifiedRosterAliases()]) {
  const byIdentity = /* @__PURE__ */ new Map();
  for (const [name, entry] of Object.entries(config.servers)) {
    byIdentity.set(serverIdentity(entry), name);
  }
  const added = [];
  const merged = [];
  let changed = false;
  for (const server of imported) {
    const candidate = {
      command: server.command,
      args: server.args ?? [],
      ...server.env !== void 0 ? { env: server.env } : {},
      ...server.url !== void 0 ? { url: server.url } : {}
    };
    if (isOwnedRosterEntry(candidate, ownedEntries)) continue;
    const identity = serverIdentity(server);
    const existingName = byIdentity.get(identity);
    if (existingName) {
      const entry = config.servers[existingName];
      if (!entry.importedFrom.includes(server.client)) {
        entry.importedFrom.push(server.client);
        changed = true;
      }
      merged.push(existingName);
      continue;
    }
    let name = server.name;
    let suffix = 2;
    while (Object.hasOwn(config.servers, name)) name = `${server.name}-${suffix++}`;
    config.servers[name] = {
      command: server.command,
      args: server.args,
      env: server.env,
      url: server.url,
      importedFrom: [server.client]
    };
    byIdentity.set(identity, name);
    added.push(name);
    changed = true;
  }
  return { config, added, merged, changed };
}
function backupDirFor(clientId, timestamp) {
  return path5.join(rosterHome(), "backups", clientId, timestamp);
}

// src/safeFile.ts
import fs6 from "node:fs";
import path6 from "node:path";
var NO_FOLLOW = fs6.constants.O_NOFOLLOW ?? 0;
function readRegularFileNoFollow(target, options = {}) {
  const attempts = options.attempts ?? 1;
  if (!Number.isInteger(attempts) || attempts < 1 || attempts > 16) {
    throw new Error("integrity read attempts must be an integer from 1 through 16");
  }
  for (let attempt = 1; attempt <= attempts; attempt++) {
    try {
      return readRegularFileOnce(target);
    } catch (error) {
      if (error.code !== "ROSTER_FILE_CHANGED" || attempt === attempts) {
        throw error;
      }
    }
  }
  throw new Error("integrity read exhausted without a result");
}
function readRegularFileOnce(target) {
  const parent = path6.dirname(target);
  const parentBefore = fs6.lstatSync(parent, { bigint: true });
  if (!parentBefore.isDirectory() || parentBefore.isSymbolicLink()) {
    throw new Error("integrity file parent is not a regular directory");
  }
  const fd = fs6.openSync(target, fs6.constants.O_RDONLY | NO_FOLLOW);
  try {
    const openedBefore = fs6.fstatSync(fd, { bigint: true });
    const namedAfterOpen = fs6.lstatSync(target, { bigint: true });
    const parentAfterOpen = fs6.lstatSync(parent, { bigint: true });
    if (!openedBefore.isFile() || !namedAfterOpen.isFile() || namedAfterOpen.isSymbolicLink() || !sameIdentity(openedBefore, namedAfterOpen) || !sameDirectory(parentBefore, parentAfterOpen)) {
      throw fileChanged("integrity file changed while being opened");
    }
    const bytes = fs6.readFileSync(fd);
    const openedAfter = fs6.fstatSync(fd, { bigint: true });
    const parentAfterRead = fs6.lstatSync(parent, { bigint: true });
    if (!sameStableFile(openedBefore, openedAfter) || !sameDirectory(parentBefore, parentAfterRead)) {
      throw fileChanged("integrity file changed while being read");
    }
    return bytes;
  } finally {
    fs6.closeSync(fd);
  }
}
function fileChanged(message) {
  return Object.assign(new Error(message), { code: "ROSTER_FILE_CHANGED" });
}
function sameIdentity(left, right) {
  return left.dev === right.dev && left.ino === right.ino;
}
function sameDirectory(left, right) {
  return right.isDirectory() && !right.isSymbolicLink() && sameIdentity(left, right);
}
function sameStableFile(left, right) {
  return right.isFile() && sameIdentity(left, right) && left.size === right.size && left.mtimeNs === right.mtimeNs && left.ctimeNs === right.ctimeNs;
}

// src/dense.ts
var DENSE_PACKAGE = "@huggingface/transformers";
var DENSE_RANGE = "^4.2.0";
var DENSE_ADM_ZIP_TARBALL = "https://codeload.github.com/cthackers/adm-zip/tar.gz/7d90dea2bfd35bc4761d6c8cf822f26b59aeef77";
var DENSE_APPROX_MB = 385;
function denseRuntimeDir2() {
  return path7.join(rosterHome(), "runtime");
}
function denseModulesDir() {
  return path7.join(denseRuntimeDir2(), "node_modules");
}
function isDenseInstalledIn(modulesDir) {
  return fs7.existsSync(path7.join(modulesDir, ...DENSE_PACKAGE.split("/"), "package.json"));
}
function isDenseAvailable() {
  if (isDenseInstalledIn(denseModulesDir())) return true;
  try {
    createRequire2(import.meta.filename).resolve(DENSE_PACKAGE);
    return true;
  } catch {
    return false;
  }
}
function isRecord2(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function prepareDenseManifest(dir) {
  const manifest = path7.join(dir, "package.json");
  const initial = {
    name: "roster-dense-runtime",
    version: "0.0.0",
    private: true,
    overrides: { "adm-zip": DENSE_ADM_ZIP_TARBALL }
  };
  try {
    fs7.writeFileSync(manifest, `${JSON.stringify(initial, null, 2)}
`, {
      mode: PRIVATE_FILE,
      flag: "wx"
    });
    return;
  } catch (error) {
    if (error.code !== "EEXIST") throw error;
  }
  const current = JSON.parse(readRegularFileNoFollow(manifest).toString("utf8"));
  if (!isRecord2(current) || current.overrides !== void 0 && !isRecord2(current.overrides)) {
    throw new Error("runtime package.json and its overrides must be JSON objects");
  }
  const overrides = current.overrides ?? {};
  if (overrides["adm-zip"] === DENSE_ADM_ZIP_TARBALL) return;
  atomicWriteFileSync(
    manifest,
    `${JSON.stringify({ ...current, overrides: { ...overrides, "adm-zip": DENSE_ADM_ZIP_TARBALL } }, null, 2)}
`,
    PRIVATE_FILE
  );
}
function installDenseRuntime(spawn = (cmd, args) => spawnSync(cmd, args, { encoding: "utf8", stdio: ["ignore", "inherit", "pipe"] })) {
  const dir = fs7.realpathSync(ensurePrivateDir(denseRuntimeDir2()));
  try {
    prepareDenseManifest(dir);
  } catch (error) {
    return {
      ok: false,
      detail: `Cannot prepare semantic runtime: ${error instanceof Error ? error.message : String(error)}`
    };
  }
  const result = spawn("npm", [
    "install",
    `${DENSE_PACKAGE}@${DENSE_RANGE}`,
    "--prefix",
    dir,
    "--no-audit",
    "--no-fund",
    "--loglevel",
    "error"
  ]);
  if (result.error) return { ok: false, detail: result.error.message };
  if (result.status !== 0) {
    const stderr = (result.stderr ?? "").toString().trim().split("\n").slice(-3).join(" ");
    return { ok: false, detail: stderr || `npm exited ${result.status}` };
  }
  return isDenseInstalledIn(denseModulesDir()) ? { ok: true, detail: dir } : { ok: false, detail: "npm reported success but the runtime is still not resolvable" };
}
function denseStatusLine() {
  return isDenseAvailable() ? "semantic search: ON (embedding runtime installed)" : `semantic search: OFF (lexical only) \u2014 enable with \`roster dense enable\` (~${DENSE_APPROX_MB} MB, local only)`;
}
function denseOffer() {
  return [
    "",
    "Semantic search (optional)",
    "  Roster already works: it matches your tools lexically from second zero.",
    `  The optional embedding runtime adds meaning-based matching. It is ~${DENSE_APPROX_MB} MB,`,
    "  runs entirely on your machine, and sends nothing anywhere.",
    ""
  ].join("\n");
}

// src/eject.ts
init_dist2();
import fs11 from "node:fs";
import path11 from "node:path";

// src/clients.ts
import fs8 from "node:fs";
import path8 from "node:path";
import { parse as parseToml } from "smol-toml";
import { parse as parseYaml } from "yaml";

// src/jsonc.ts
function parseJsonc(input) {
  const cleaned = input.charCodeAt(0) === 65279 ? input.slice(1) : input;
  return JSON.parse(stripTrailingCommas(stripComments(cleaned)));
}
function stripComments(input) {
  let out = "";
  let inString = false;
  let inLine = false;
  let inBlock = false;
  for (let i = 0; i < input.length; i++) {
    const ch = input[i];
    const next = input[i + 1];
    if (inLine) {
      if (ch === "\n") {
        inLine = false;
        out += ch;
      }
      continue;
    }
    if (inBlock) {
      if (ch === "*" && next === "/") {
        inBlock = false;
        i++;
      }
      continue;
    }
    if (inString) {
      out += ch;
      if (ch === "\\") {
        if (next !== void 0) {
          out += next;
          i++;
        }
      } else if (ch === '"') {
        inString = false;
      }
      continue;
    }
    if (ch === '"') {
      inString = true;
      out += ch;
      continue;
    }
    if (ch === "/" && next === "/") {
      inLine = true;
      i++;
      continue;
    }
    if (ch === "/" && next === "*") {
      inBlock = true;
      i++;
      continue;
    }
    out += ch;
  }
  return out;
}
function stripTrailingCommas(input) {
  let out = "";
  let inString = false;
  for (let i = 0; i < input.length; i++) {
    const ch = input[i];
    if (inString) {
      out += ch;
      if (ch === "\\") {
        const next = input[i + 1];
        if (next !== void 0) {
          out += next;
          i++;
        }
      } else if (ch === '"') {
        inString = false;
      }
      continue;
    }
    if (ch === '"') {
      inString = true;
      out += ch;
      continue;
    }
    if (ch === ",") {
      let j = i + 1;
      while (j < input.length && /\s/.test(input[j])) j++;
      if (input[j] === "}" || input[j] === "]") continue;
    }
    out += ch;
  }
  return out;
}

// src/clients.ts
init_paths();
function isRecord3(value) {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
function fromMcpServersObject(obj, client, sourcePath, opts = {}) {
  if (obj === void 0) return [];
  if (!isRecord3(obj)) throw new Error("MCP servers must be an object");
  const out = [];
  const urlKeys = opts.urlKeys ?? ["url", "httpUrl", "serverUrl"];
  const supported = /* @__PURE__ */ new Set(["command", "args", "env", "type", ...urlKeys]);
  for (const [name, raw] of Object.entries(obj)) {
    if (!isRecord3(raw)) throw new Error(`MCP server "${name}" must be an object`);
    const unsupported = Object.keys(raw).filter((key) => !supported.has(key));
    if (unsupported.length > 0 || raw.type !== void 0 && raw.type !== "stdio") {
      throw new Error(`Unsupported MCP server settings for "${name}": ${unsupported.join(", ") || "type"}; configuration left unchanged`);
    }
    for (const key of ["command", ...urlKeys]) {
      if (raw[key] !== void 0 && (typeof raw[key] !== "string" || raw[key].trim() === "")) {
        throw new Error(`MCP server "${name}" ${key} must be a non-empty string`);
      }
    }
    if (raw.args !== void 0 && (!Array.isArray(raw.args) || raw.args.some((arg) => typeof arg !== "string"))) {
      throw new Error(`MCP server "${name}" args must be an array of strings`);
    }
    if (raw.env !== void 0 && (!isRecord3(raw.env) || Object.values(raw.env).some((value) => typeof value !== "string"))) {
      throw new Error(`MCP server "${name}" env must be an object of strings`);
    }
    const url = urlKeys.map((k) => raw[k]).find((v) => typeof v === "string");
    const command = typeof raw.command === "string" ? raw.command : void 0;
    if (!url && !command) throw new Error(`MCP server "${name}" must define command or url`);
    if (command && url) throw new Error(`Unsupported mixed MCP transports for "${name}"`);
    out.push({
      name,
      command,
      args: Array.isArray(raw.args) ? raw.args.map(String) : void 0,
      env: raw.env && typeof raw.env === "object" ? Object.fromEntries(
        Object.entries(raw.env).map(([k, v]) => [k, String(v)])
      ) : void 0,
      url,
      client,
      sourcePath
    });
  }
  return out;
}
var home = homeDir;
function appDataDir() {
  if (process.env.ROSTER_TEST_HOME) return path8.join(home(), "AppData", "Roaming");
  return process.env.APPDATA ?? path8.join(home(), "AppData", "Roaming");
}
var CLIENTS = [
  {
    id: "claude-code",
    displayName: "Claude Code",
    nativeToolSearch: true,
    stateFileBasename: ".claude.json",
    // Claude Code's live state file (cwd .mcp.json stays byte-restore)
    // Verified 2026-07-04 on a live machine: user-scope MCP servers live in
    // ~/.claude.json (NOT ~/.claude/settings.json — handoff §8 amended).
    configPaths: () => [
      path8.join(home(), ".claude.json"),
      path8.join(process.cwd(), ".mcp.json")
    ],
    parse: (content, sourcePath) => {
      const data = parseJsonc(content);
      return fromMcpServersObject(data.mcpServers, "claude-code", sourcePath);
    }
  },
  {
    id: "claude-desktop",
    displayName: "Claude Desktop",
    nativeToolSearch: false,
    configPaths: () => {
      if (process.platform === "win32") {
        return [path8.join(appDataDir(), "Claude", "claude_desktop_config.json")];
      }
      return [path8.join(home(), "Library", "Application Support", "Claude", "claude_desktop_config.json")];
    },
    parse: (content, sourcePath) => {
      const data = parseJsonc(content);
      return fromMcpServersObject(data.mcpServers, "claude-desktop", sourcePath);
    }
  },
  {
    id: "cursor",
    displayName: "Cursor",
    nativeToolSearch: false,
    configPaths: () => [
      path8.join(home(), ".cursor", "mcp.json"),
      path8.join(process.cwd(), ".cursor", "mcp.json")
    ],
    parse: (content, sourcePath) => {
      const data = parseJsonc(content);
      return fromMcpServersObject(data.mcpServers, "cursor", sourcePath);
    }
  },
  {
    id: "codex",
    displayName: "Codex",
    nativeToolSearch: false,
    configPaths: () => [path8.join(home(), ".codex", "config.toml")],
    parse: (content, sourcePath) => {
      const data = parseToml(content);
      return fromMcpServersObject(data.mcp_servers, "codex", sourcePath);
    }
  },
  {
    id: "gemini-cli",
    displayName: "Gemini CLI",
    nativeToolSearch: false,
    configPaths: () => [path8.join(home(), ".gemini", "settings.json")],
    parse: (content, sourcePath) => {
      const data = parseJsonc(content);
      return fromMcpServersObject(data.mcpServers, "gemini-cli", sourcePath);
    }
  },
  {
    id: "hermes",
    displayName: "Hermes",
    nativeToolSearch: false,
    configPaths: () => [path8.join(home(), ".hermes", "config.yaml")],
    parse: (content, sourcePath) => {
      const data = parseYaml(content);
      return fromMcpServersObject(data?.mcp_servers, "hermes", sourcePath);
    }
  },
  {
    id: "openclaw",
    displayName: "OpenClaw",
    nativeToolSearch: false,
    stateFileBasename: "openclaw.json",
    // holds broader client config beyond mcpServers
    configPaths: () => [
      path8.join(home(), ".openclaw", "openclaw.json"),
      path8.join(home(), "openclaw.json")
    ],
    parse: (content, sourcePath) => {
      const data = parseJsonc(content);
      return fromMcpServersObject(data.mcpServers, "openclaw", sourcePath);
    }
  },
  {
    id: "vscode",
    displayName: "VS Code",
    nativeToolSearch: false,
    configPaths: () => {
      const base = process.platform === "win32" ? path8.join(appDataDir(), "Code", "User") : process.platform === "darwin" ? path8.join(home(), "Library", "Application Support", "Code", "User") : path8.join(home(), ".config", "Code", "User");
      return [path8.join(base, "mcp.json"), path8.join(process.cwd(), ".vscode", "mcp.json")];
    },
    parse: (content, sourcePath) => {
      const data = parseJsonc(content);
      return fromMcpServersObject(data.servers ?? data.mcpServers, "vscode", sourcePath);
    }
  },
  {
    id: "windsurf",
    displayName: "Windsurf",
    nativeToolSearch: false,
    configPaths: () => [path8.join(home(), ".codeium", "windsurf", "mcp_config.json")],
    parse: (content, sourcePath) => {
      const data = parseJsonc(content);
      return fromMcpServersObject(data.mcpServers, "windsurf", sourcePath);
    }
  },
  {
    id: "zed",
    displayName: "Zed",
    nativeToolSearch: false,
    configPaths: () => [path8.join(home(), ".config", "zed", "settings.json")],
    parse: (content, sourcePath) => {
      const data = parseJsonc(content);
      return fromMcpServersObject(data.context_servers, "zed", sourcePath);
    }
  }
];
function discoverClients() {
  const discoveries = [];
  for (const client of CLIENTS) {
    for (const configPath of client.configPaths()) {
      if (!fs8.existsSync(configPath)) continue;
      try {
        const content = fs8.readFileSync(configPath, "utf8");
        discoveries.push({ client, configPath, servers: client.parse(content, configPath) });
      } catch (err) {
        discoveries.push({
          client,
          configPath,
          servers: [],
          parseError: err instanceof Error ? err.message : String(err)
        });
      }
    }
  }
  return discoveries;
}

// src/ejectJournal.ts
init_dist2();
import crypto3 from "node:crypto";
import fs9 from "node:fs";
import path9 from "node:path";
init_paths();
function journalRoot() {
  return path9.join(rosterHome(), "eject-journals");
}
function journalDir(clientId) {
  return path9.join(journalRoot(), clientId);
}
function isHash(value) {
  return typeof value === "string" && /^[a-f0-9]{64}$/.test(value);
}
function isSpawnEntryArray(value) {
  return Array.isArray(value) && value.every(
    (e) => e !== null && typeof e === "object" && typeof e.command === "string" && Array.isArray(e.args) && e.args.every((a) => typeof a === "string")
  );
}
function parsePlan(value, clientId) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    throw new Error("pending eject plan is not an object");
  }
  const raw = value;
  if (raw.version !== 1 || raw.client !== clientId || typeof raw.boundary !== "string" || raw.boundary === "") {
    throw new Error("pending eject plan identity is invalid");
  }
  if (!Array.isArray(raw.targets) || raw.targets.length === 0) {
    throw new Error("pending eject plan has no targets");
  }
  const seenSources = /* @__PURE__ */ new Set();
  const seenFiles = /* @__PURE__ */ new Set();
  const targets = raw.targets.map((value2, index) => {
    if (value2 === null || typeof value2 !== "object" || Array.isArray(value2)) {
      throw new Error(`pending eject target ${index} is invalid`);
    }
    const target = value2;
    if (typeof target.sourcePath !== "string" || !path9.isAbsolute(target.sourcePath) || target.writePath !== void 0 && (typeof target.writePath !== "string" || !path9.isAbsolute(target.writePath)) || target.symlinkTarget !== void 0 && typeof target.symlinkTarget !== "string" || target.beforeSha256 !== null && !isHash(target.beforeSha256) || !isHash(target.desiredSha256) || typeof target.desiredFile !== "string" || !/^target-[0-9]+\.bin$/.test(target.desiredFile)) {
      throw new Error(`pending eject target ${index} has invalid fields`);
    }
    const keyLevel = target.keyLevel === true;
    if (keyLevel) {
      if (typeof target.originalFile !== "string" || !/^original-[0-9]+\.bin$/.test(target.originalFile) || !isHash(target.originalSha256) || !isSpawnEntryArray(target.injectedEntries)) {
        throw new Error(`pending eject target ${index} has invalid key-level recovery fields`);
      }
    }
    if (seenSources.has(target.sourcePath) || seenFiles.has(target.desiredFile)) {
      throw new Error("pending eject plan contains duplicate targets");
    }
    seenSources.add(target.sourcePath);
    seenFiles.add(target.desiredFile);
    return {
      sourcePath: target.sourcePath,
      ...target.writePath !== void 0 ? { writePath: target.writePath } : {},
      ...target.symlinkTarget !== void 0 ? { symlinkTarget: target.symlinkTarget } : {},
      beforeSha256: target.beforeSha256,
      desiredSha256: target.desiredSha256,
      desiredFile: target.desiredFile,
      ...keyLevel ? {
        keyLevel: true,
        originalFile: target.originalFile,
        originalSha256: target.originalSha256,
        injectedEntries: target.injectedEntries.map((e) => ({
          command: e.command,
          args: [...e.args]
        }))
      } : {}
    };
  });
  return { version: 1, client: clientId, boundary: raw.boundary, targets };
}
function ensurePrivateDirectory(dir) {
  fs9.mkdirSync(dir, { recursive: true, mode: PRIVATE_DIR });
  const stat = fs9.lstatSync(dir);
  if (stat.isSymbolicLink() || !stat.isDirectory()) {
    throw new Error(`eject journal path is not a regular directory: ${dir}`);
  }
  fs9.chmodSync(dir, PRIVATE_DIR);
}
function fsyncDirectory(dir) {
  try {
    const fd = fs9.openSync(dir, "r");
    try {
      fs9.fsyncSync(fd);
    } finally {
      fs9.closeSync(fd);
    }
  } catch {
  }
}
function hasEjectJournal(clientId) {
  return fs9.existsSync(journalDir(clientId));
}
function loadEjectJournal(clientId) {
  const dir = journalDir(clientId);
  if (!fs9.existsSync(dir)) return null;
  const stat = fs9.lstatSync(dir);
  if (stat.isSymbolicLink() || !stat.isDirectory()) {
    throw new Error("pending eject journal is not a regular directory");
  }
  let parsed;
  try {
    parsed = JSON.parse(
      readRegularFileNoFollow(path9.join(dir, "plan.json")).toString("utf8")
    );
  } catch (error) {
    throw new Error(
      `pending eject plan is missing or corrupt: ${error instanceof Error ? error.message : String(error)}`
    );
  }
  return { dir, plan: parsePlan(parsed, clientId) };
}
function createEjectJournal(clientId, boundary, targets) {
  if (targets.length === 0) throw new Error("cannot journal an eject with no targets");
  const root = journalRoot();
  ensurePrivateDirectory(root);
  const destination = journalDir(clientId);
  if (fs9.existsSync(destination)) {
    throw new Error("a pending eject journal already exists");
  }
  const staging = path9.join(
    root,
    `.staging-${clientId}-${process.pid}-${crypto3.randomBytes(6).toString("hex")}`
  );
  fs9.mkdirSync(staging, { mode: PRIVATE_DIR });
  try {
    const journalTargets = targets.map((target, index) => {
      const desiredFile = `target-${index}.bin`;
      const desiredSha256 = sha256Hex(target.desiredBytes);
      atomicWriteFileSync(
        path9.join(staging, desiredFile),
        target.desiredBytes,
        PRIVATE_FILE
      );
      const keyLevel = target.keyLevel === true && target.originalBytes !== void 0;
      let originalFields = {};
      if (keyLevel) {
        const originalFile = `original-${index}.bin`;
        atomicWriteFileSync(path9.join(staging, originalFile), target.originalBytes, PRIVATE_FILE);
        originalFields = {
          keyLevel: true,
          originalFile,
          originalSha256: sha256Hex(target.originalBytes),
          injectedEntries: (target.injectedEntries ?? []).map((e) => ({
            command: e.command,
            args: [...e.args]
          }))
        };
      }
      return {
        sourcePath: target.sourcePath,
        ...target.writePath !== void 0 ? { writePath: target.writePath } : {},
        ...target.symlinkTarget !== void 0 ? { symlinkTarget: target.symlinkTarget } : {},
        beforeSha256: target.beforeSha256,
        desiredSha256,
        desiredFile,
        ...originalFields
      };
    });
    const plan = {
      version: 1,
      client: clientId,
      boundary,
      targets: journalTargets
    };
    atomicWriteFileSync(
      path9.join(staging, "plan.json"),
      `${JSON.stringify(plan, null, 2)}
`,
      PRIVATE_FILE
    );
    fsyncDirectory(staging);
    fs9.renameSync(staging, destination);
    fsyncDirectory(root);
    return { dir: destination, plan };
  } catch (error) {
    fs9.rmSync(staging, { recursive: true, force: true });
    throw error;
  }
}
function rebaseEjectJournal(journal, beforeHashes) {
  const targets = journal.plan.targets.map((target) => {
    const desired = readDesiredBytes(journal, target);
    const bytes = target.keyLevel ? readOriginalBytes(journal, target) : desired;
    const beforeSha256 = beforeHashes.get(target.sourcePath);
    if (beforeSha256 === void 0) throw new Error("missing forced-eject preflight snapshot");
    const nonce = BigInt(`0x${crypto3.randomBytes(16).toString("hex")}`);
    const desiredFile = `target-${nonce}.bin`;
    atomicWriteFileSync(path9.join(journal.dir, desiredFile), bytes, PRIVATE_FILE);
    return {
      sourcePath: target.sourcePath,
      ...target.writePath !== void 0 ? { writePath: target.writePath } : {},
      ...target.symlinkTarget !== void 0 ? { symlinkTarget: target.symlinkTarget } : {},
      beforeSha256,
      desiredSha256: sha256Hex(bytes),
      desiredFile
    };
  });
  const plan = { ...journal.plan, targets };
  atomicWriteFileSync(path9.join(journal.dir, "plan.json"), `${JSON.stringify(plan, null, 2)}
`, PRIVATE_FILE);
  return { dir: journal.dir, plan };
}
function readDesiredBytes(journal, target) {
  return readJournalFile(journal, target.desiredFile, target.desiredSha256);
}
function readOriginalBytes(journal, target) {
  if (!target.originalFile || !target.originalSha256) {
    throw new Error("pending eject target has no original bytes to re-derive from");
  }
  return readJournalFile(journal, target.originalFile, target.originalSha256);
}
function readJournalFile(journal, file, expectedSha) {
  const resolved = path9.resolve(path9.join(journal.dir, file));
  if (path9.dirname(resolved) !== path9.resolve(journal.dir)) {
    throw new Error("pending eject journal file path escapes its journal");
  }
  const bytes = readRegularFileNoFollow(resolved);
  if (sha256Hex(bytes) !== expectedSha) {
    throw new Error("pending eject journal bytes do not match their recorded hash");
  }
  return bytes;
}
function clearEjectJournal(journal) {
  fs9.rmSync(journal.dir, { recursive: true });
  fsyncDirectory(path9.dirname(journal.dir));
}

// src/sync.ts
init_dist2();
import crypto4 from "node:crypto";
import fs10 from "node:fs";
import path10 from "node:path";
import { parse as parseToml2, stringify as stringifyToml } from "smol-toml";
var WRITE_CLIENTS = ["claude-code", "cursor", "codex", "openclaw"];
function syncClient(clientId, now = /* @__PURE__ */ new Date()) {
  return withFileLockSync(`client:${clientId}`, () => syncClientUnlocked(clientId, now));
}
function syncClientUnlocked(clientId, now) {
  const spec = CLIENTS.find((c) => c.id === clientId);
  if (!spec) throw new Error(`unknown client: ${clientId}`);
  if (hasEjectJournal(clientId)) {
    throw new Error(
      `a previous ${clientId} eject is pending recovery; run \`roster eject --client ${clientId}\` before syncing again`
    );
  }
  const configPath = spec.configPaths().find((p) => fs10.existsSync(p));
  if (!configPath) return { client: clientId, configPath: "", action: "not-found" };
  const topology = resolveWriteTopology(configPath);
  const originalBytes = readRegularFileNoFollow(topology.writePath, {
    attempts: 4
  });
  let imported = 0;
  const servers = spec.parse(originalBytes.toString("utf8"), configPath);
  if (servers.some((server) => server.url && !server.command)) {
    throw new Error(
      "URL-only MCP servers cannot be synced yet: Roster routing is stdio-only; the client was left untouched"
    );
  }
  const injectedEntry = rosterEntry();
  const ownedEntries = ownedRosterEntries(clientId, injectedEntry);
  if (servers.length > 0) {
    const { added } = updateConfig((config) => mergeServers(config, servers, ownedEntries));
    imported = added.length;
  }
  sweepOrphanStaging(clientId);
  const rewritten = rewriteConfig(
    clientId,
    originalBytes.toString("utf8"),
    injectedEntry
  );
  if (rewritten === null) {
    return { client: clientId, configPath, action: "already-synced", imported };
  }
  const timestamp = now.toISOString().replace(/[:.]/g, "-");
  const backupDir = backupDirFor(clientId, timestamp);
  const latestPath = path10.join(path10.dirname(backupDir), "latest");
  const previousLatest = fs10.existsSync(latestPath) ? readRegularFileNoFollow(latestPath) : null;
  const stagingDir = `${backupDir}.staging-${crypto4.randomBytes(4).toString("hex")}`;
  fs10.mkdirSync(stagingDir, { recursive: true, mode: PRIVATE_DIR });
  fs10.writeFileSync(path10.join(stagingDir, "original"), originalBytes, { mode: PRIVATE_FILE });
  const manifest = {
    client: clientId,
    sourcePath: configPath,
    originalSha256: sha256Hex(originalBytes),
    writtenSha256: sha256Hex(rewritten),
    timestamp,
    injectedEntry,
    // exact identity for eject — never the key name (R5-01)
    writePath: topology.writePath,
    ...topology.symlinkTarget !== void 0 ? { symlinkTarget: topology.symlinkTarget } : {}
  };
  fs10.writeFileSync(path10.join(stagingDir, "manifest.json"), `${JSON.stringify(manifest, null, 2)}
`, {
    mode: PRIVATE_FILE
  });
  fs10.renameSync(stagingDir, backupDir);
  atomicWriteFileSync(latestPath, timestamp, PRIVATE_FILE);
  let replaceApproved = false;
  try {
    const writePath = validateWriteTopology(configPath, manifest.writePath, manifest.symlinkTarget);
    atomicWriteFileSync(writePath, rewritten, void 0, () => {
      validateWriteTopology(configPath, manifest.writePath, manifest.symlinkTarget);
      const current = readRegularFileNoFollow(writePath, { attempts: 4 });
      if (sha256Hex(current) !== manifest.originalSha256) {
        throw new Error("client config changed during sync; left untouched \u2014 retry when the client is idle");
      }
      replaceApproved = true;
    });
  } catch (error) {
    if (!replaceApproved) {
      fs10.renameSync(backupDir, stagingDir);
      if (previousLatest === null) fs10.rmSync(latestPath, { force: true });
      else atomicWriteFileSync(latestPath, previousLatest, PRIVATE_FILE);
    }
    throw error;
  }
  return { client: clientId, configPath, action: "synced", backupDir, imported };
}
function rewriteConfig(clientId, content, entry) {
  if (clientId === "codex") {
    const data2 = parseToml2(content);
    if (isAlreadySynced(data2.mcp_servers, [entry])) return null;
    data2.mcp_servers = { roster: entry };
    return `${stringifyToml(data2)}
`;
  }
  const data = parseJsonc(content);
  if (data === null || typeof data !== "object" || Array.isArray(data)) {
    throw new Error(`config is not a JSON object (got ${Array.isArray(data) ? "array" : typeof data})`);
  }
  const obj = data;
  if (isAlreadySynced(obj.mcpServers, [entry])) return null;
  obj.mcpServers = { roster: entry };
  return `${JSON.stringify(obj, null, 2)}
`;
}
function isAlreadySynced(servers, ownedEntries) {
  if (servers === null || typeof servers !== "object" || Array.isArray(servers)) return false;
  const entries = Object.entries(servers);
  return entries.length === 1 && isOwnedRosterEntry(entries[0][1], ownedEntries);
}
function ownedRosterEntries(clientId, current = rosterEntry()) {
  const entries = [current, ...verifiedRosterAliases()];
  const clients = clientId ? [clientId] : WRITE_CLIENTS;
  for (const id of clients) {
    for (const backup of rawBackups(id)) {
      const injected = normalizeSpawnEntry(backup.manifest?.injectedEntry);
      if (!injected || !backup.manifest) continue;
      try {
        const original = readRegularFileNoFollow(
          path10.join(backup.dir, "original")
        );
        if (sha256Hex(original) !== backup.manifest.originalSha256) continue;
      } catch {
        continue;
      }
      if (!entries.some((entry) => isOwnedRosterEntry(injected, [entry]))) {
        entries.push(injected);
      }
    }
  }
  return entries;
}
function clientBackupDir(clientId) {
  return path10.dirname(backupDirFor(clientId, "x"));
}
var ORPHAN_STAGING_NAME = /^\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}-\d{3}Z\.staging-[0-9a-f]{8}$/;
function sweepOrphanStaging(clientId) {
  const dir = clientBackupDir(clientId);
  let entries;
  try {
    entries = fs10.readdirSync(dir);
  } catch {
    return;
  }
  for (const name of entries) {
    if (!ORPHAN_STAGING_NAME.test(name)) continue;
    try {
      fs10.rmSync(path10.join(dir, name), { recursive: true, force: true, maxRetries: 10, retryDelay: 50 });
    } catch {
    }
  }
}
function closedThroughPath(clientId) {
  return path10.join(clientBackupDir(clientId), ".closed-through");
}
function readClosedThrough(clientId) {
  try {
    const value = readRegularFileNoFollow(closedThroughPath(clientId)).toString("utf8").trim();
    if (!/^\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}-\d{3}Z$/.test(value)) {
      throw new Error(`backup era marker for ${clientId} is corrupt`);
    }
    return value;
  } catch (error) {
    if (error.code === "ENOENT") return null;
    throw error;
  }
}
function closeEraThrough(clientId, backupName) {
  const current = readClosedThrough(clientId);
  if (current !== null && current >= backupName) return true;
  try {
    atomicWriteFileSync(closedThroughPath(clientId), `${backupName}
`);
    return true;
  } catch {
    return false;
  }
}
function rawBackups(clientId) {
  const clientDir = clientBackupDir(clientId);
  if (!fs10.existsSync(clientDir)) return [];
  const closedThrough = readClosedThrough(clientId);
  const out = [];
  for (const name of fs10.readdirSync(clientDir).sort()) {
    if (name.includes(".staging-")) continue;
    if (closedThrough !== null && name <= closedThrough) continue;
    const dir = path10.join(clientDir, name);
    try {
      const stat = fs10.lstatSync(dir);
      if (stat.isSymbolicLink()) {
        out.push({ dir, name, manifest: null });
        continue;
      }
      if (!stat.isDirectory()) continue;
    } catch {
      continue;
    }
    let manifest = null;
    try {
      manifest = JSON.parse(
        readRegularFileNoFollow(path10.join(dir, "manifest.json")).toString(
          "utf8"
        )
      );
    } catch {
      manifest = null;
    }
    out.push({ dir, name, manifest });
  }
  return out;
}

// src/eject.ts
function ejectClient(clientId, opts = {}) {
  return withFileLockSync(
    `client:${clientId}`,
    () => ejectClientUnlocked(clientId, opts)
  );
}
function ejectClientUnlocked(clientId, opts) {
  let pending;
  try {
    pending = loadEjectJournal(clientId);
  } catch (error) {
    return integrityFailure(
      clientId,
      `pending eject recovery data is corrupt \u2014 refusing: ${errorMessage(error)}`
    );
  }
  if (pending) return applyJournal(clientId, pending, opts.force === true);
  let slots;
  try {
    slots = rawBackups(clientId);
  } catch (error) {
    return integrityFailure(
      clientId,
      `the backup era boundary is unreadable or corrupt: ${errorMessage(error)}`
    );
  }
  if (slots.length === 0) return { client: clientId, action: "no-backup" };
  if (slots.some((slot) => slot.manifest === null)) {
    return integrityFailure(
      clientId,
      "the active backup set has a missing, corrupt, or non-directory slot \u2014 refusing every restore"
    );
  }
  const backups = slots;
  try {
    for (const backup of backups) validateManifest(clientId, backup);
  } catch (error) {
    return integrityFailure(clientId, errorMessage(error));
  }
  const groups = /* @__PURE__ */ new Map();
  for (const backup of backups) {
    const group = groups.get(backup.manifest.sourcePath) ?? [];
    group.push(backup);
    groups.set(backup.manifest.sourcePath, group);
  }
  const planned = [];
  for (const [sourcePath, group] of [...groups.entries()].sort(
    ([a], [b]) => a.localeCompare(b)
  )) {
    const result = planRestore(clientId, sourcePath, group, opts.force === true);
    if ("action" in result) return result;
    planned.push(result);
  }
  const stable = stabilizeStateTargets(clientId, planned);
  if (stable) return stable;
  const boundary = backups.at(-1).name;
  let journal;
  try {
    journal = createEjectJournal(clientId, boundary, planned);
  } catch (error) {
    return integrityFailure(
      clientId,
      `could not persist the eject recovery journal before writing configs: ${errorMessage(error)}`
    );
  }
  return applyJournal(clientId, journal);
}
function planRestore(clientId, sourcePath, backups, force) {
  const pristine = backups[0];
  const latest = backups.at(-1);
  let topology;
  try {
    topology = newestTopology(backups);
  } catch (error) {
    return integrityFailure(clientId, `${sourcePath}: ${errorMessage(error)}`, sourcePath);
  }
  let writePath;
  try {
    writePath = validateWriteTopology(
      sourcePath,
      topology.writePath,
      topology.symlinkTarget
    );
  } catch (error) {
    return {
      client: clientId,
      action: "refused-modified",
      configPath: sourcePath,
      detail: `config symlink/topology changed after sync \u2014 refusing restore: ${errorMessage(error)}`
    };
  }
  let originalBytes;
  try {
    const originalPath = path11.join(pristine.dir, "original");
    originalBytes = readRegularFileNoFollow(originalPath);
    if (sha256Hex(originalBytes) !== pristine.manifest.originalSha256) {
      throw new Error("stored pristine bytes do not match their recorded hash");
    }
  } catch (error) {
    return integrityFailure(
      clientId,
      `${sourcePath}: ${errorMessage(error)} \u2014 not restoring`,
      sourcePath
    );
  }
  const currentBytes = readRegularFileIfPresent(writePath, 4);
  const stateFile = CLIENTS.find((client) => client.id === clientId)?.stateFileBasename === path11.basename(sourcePath);
  const injectedEntries = backups.map((backup) => normalizeSpawnEntry(backup.manifest.injectedEntry)).filter((entry) => entry !== null);
  if (stateFile && currentBytes && !force) {
    if (!normalizeSpawnEntry(latest.manifest.injectedEntry)) {
      return {
        client: clientId,
        action: "refused-modified",
        configPath: sourcePath,
        detail: "legacy backup has no exact injected-entry identity; refusing key-level deletion \u2014 use --force for an explicit pristine byte restore"
      };
    }
    try {
      const desired = restoreServersKeyLevel(
        currentBytes.toString("utf8"),
        originalBytes.toString("utf8"),
        injectedEntries
      );
      if (ownedProxyRemains(desired, injectedEntries)) {
        return {
          client: clientId,
          action: "refused-modified",
          configPath: sourcePath,
          detail: "an owned Roster proxy entry is still present after key-level restore; refusing to close the era so `roster eject` can be re-run (recovery retained)"
        };
      }
      return {
        sourcePath,
        ...topology.writePath !== void 0 ? { writePath: topology.writePath } : {},
        ...topology.symlinkTarget !== void 0 ? { symlinkTarget: topology.symlinkTarget } : {},
        beforeSha256: sha256Hex(currentBytes),
        desiredBytes: Buffer.from(desired),
        // Persisted so a resume can re-derive this merge from a third-state file
        // instead of deadlocking eject and sync (NEW-3).
        keyLevel: true,
        originalBytes,
        injectedEntries
      };
    } catch {
    }
  }
  if (!currentBytes && !force) {
    return {
      client: clientId,
      action: "missing-file",
      configPath: sourcePath,
      detail: "config file no longer exists; use --force to recreate it from backup"
    };
  }
  if (currentBytes && sha256Hex(currentBytes) !== latest.manifest.writtenSha256 && !force) {
    return {
      client: clientId,
      action: "refused-modified",
      configPath: sourcePath,
      detail: "config was modified after sync \u2014 refusing to overwrite those edits; re-run with --force to restore the pristine backup anyway"
    };
  }
  return {
    sourcePath,
    ...topology.writePath !== void 0 ? { writePath: topology.writePath } : {},
    ...topology.symlinkTarget !== void 0 ? { symlinkTarget: topology.symlinkTarget } : {},
    beforeSha256: currentBytes ? sha256Hex(currentBytes) : null,
    desiredBytes: originalBytes
  };
}
function validateManifest(clientId, backup) {
  const { manifest } = backup;
  if (manifest.client !== clientId || typeof manifest.sourcePath !== "string" || !path11.isAbsolute(manifest.sourcePath) || manifest.timestamp !== backup.name || !/^[a-f0-9]{64}$/.test(manifest.originalSha256) || !/^[a-f0-9]{64}$/.test(manifest.writtenSha256) || manifest.writePath !== void 0 && (typeof manifest.writePath !== "string" || !path11.isAbsolute(manifest.writePath)) || manifest.symlinkTarget !== void 0 && typeof manifest.symlinkTarget !== "string" || manifest.symlinkTarget !== void 0 && manifest.writePath === void 0) {
    throw new Error(
      `backup ${backup.name} has invalid or mismatched manifest fields`
    );
  }
  const originalPath = path11.join(backup.dir, "original");
  if (sha256Hex(readRegularFileNoFollow(originalPath)) !== manifest.originalSha256) {
    throw new Error(`backup ${backup.name} original bytes failed their hash check`);
  }
}
function newestTopology(backups) {
  const recorded = backups.filter(
    (backup) => backup.manifest.writePath !== void 0 || backup.manifest.symlinkTarget !== void 0
  );
  if (recorded.length === 0) return {};
  const newest = recorded.at(-1).manifest;
  for (const backup of recorded) {
    if (backup.manifest.writePath !== newest.writePath || backup.manifest.symlinkTarget !== newest.symlinkTarget) {
      throw new Error(
        "write topology changed between backups; refusing to guess which target owns the pristine bytes"
      );
    }
  }
  return {
    ...newest.writePath !== void 0 ? { writePath: newest.writePath } : {},
    ...newest.symlinkTarget !== void 0 ? { symlinkTarget: newest.symlinkTarget } : {}
  };
}
function applyJournal(clientId, journal, force = false) {
  const restoredPaths = journal.plan.targets.map((target) => target.sourcePath);
  let alreadyClosed;
  try {
    alreadyClosed = readClosedThrough(clientId);
  } catch (error) {
    return integrityFailure(
      clientId,
      `the backup era boundary is unreadable or corrupt: ${errorMessage(error)}`
    );
  }
  if (alreadyClosed !== null && alreadyClosed >= journal.plan.boundary) {
    try {
      clearEjectJournal(journal);
    } catch (error) {
      return integrityFailure(
        clientId,
        `the eject era is closed but its recovery journal could not be cleared: ${errorMessage(error)}`
      );
    }
    archiveEraThrough(clientId, journal.plan.boundary);
    return restoredResult(clientId, restoredPaths, "completed interrupted eject cleanup");
  }
  if (force) {
    try {
      const beforeHashes = /* @__PURE__ */ new Map();
      for (const target of journal.plan.targets) {
        const writePath = validateWriteTopology(target.sourcePath, target.writePath, target.symlinkTarget);
        beforeHashes.set(target.sourcePath, hashIfPresent(writePath));
      }
      journal = rebaseEjectJournal(journal, beforeHashes);
    } catch (error) {
      return integrityFailure(clientId, `forced eject recovery failed validation: ${errorMessage(error)}`);
    }
  }
  const prepared = [];
  for (const target of journal.plan.targets) {
    let desiredBytes;
    let writePath;
    try {
      desiredBytes = readDesiredBytes(journal, target);
      writePath = validateWriteTopology(
        target.sourcePath,
        target.writePath,
        target.symlinkTarget
      );
    } catch (error) {
      return integrityFailure(
        clientId,
        `${target.sourcePath}: pending eject recovery failed validation: ${errorMessage(error)}`,
        target.sourcePath
      );
    }
    const currentSha256 = hashIfPresent(writePath);
    if (currentSha256 === target.desiredSha256) {
      prepared.push({
        target,
        desiredBytes,
        writePath,
        pending: false,
        desiredSha256: target.desiredSha256,
        beforeSha256: target.beforeSha256
      });
      continue;
    }
    if (currentSha256 !== target.beforeSha256) {
      const rederived = rederiveKeyLevel(journal, target, writePath);
      if (rederived) {
        if (ownedProxyRemains(rederived.toString("utf8"), target.injectedEntries ?? [])) {
          return integrityFailure(
            clientId,
            `${target.sourcePath}: an owned proxy would remain after key-level recovery; refusing (recovery retained)`,
            target.sourcePath
          );
        }
        prepared.push({
          target,
          desiredBytes: rederived,
          writePath,
          pending: true,
          desiredSha256: sha256Hex(rederived),
          beforeSha256: currentSha256
        });
        continue;
      }
      return integrityFailure(
        clientId,
        `${target.sourcePath}: config changed to a third state during interrupted eject; refusing to overwrite it \u2014 re-run \`roster eject --force\` to restore the pristine backup`,
        target.sourcePath
      );
    }
    prepared.push({
      target,
      desiredBytes,
      writePath,
      pending: true,
      desiredSha256: target.desiredSha256,
      beforeSha256: target.beforeSha256
    });
  }
  for (const item of prepared) {
    if (!item.pending) continue;
    try {
      const checkedWritePath = validateWriteTopology(
        item.target.sourcePath,
        item.target.writePath,
        item.target.symlinkTarget
      );
      const currentSha256 = hashIfPresent(checkedWritePath);
      if (currentSha256 === item.desiredSha256) continue;
      if (currentSha256 !== item.beforeSha256) {
        throw new Error("config changed after eject preflight");
      }
      fs11.mkdirSync(path11.dirname(item.target.sourcePath), {
        recursive: true,
        mode: PRIVATE_DIR
      });
      const finalWritePath = validateWriteTopology(
        item.target.sourcePath,
        item.target.writePath,
        item.target.symlinkTarget
      );
      atomicWriteFileSync(finalWritePath, item.desiredBytes);
      if (hashIfPresent(finalWritePath) !== item.desiredSha256) {
        throw new Error("restored bytes failed their post-write hash check");
      }
    } catch (error) {
      return integrityFailure(
        clientId,
        `${item.target.sourcePath}: eject write stopped safely and remains recoverable: ${errorMessage(error)}`,
        item.target.sourcePath
      );
    }
  }
  let marked;
  try {
    marked = closeEraThrough(clientId, journal.plan.boundary);
  } catch (error) {
    return integrityFailure(
      clientId,
      `the backup era boundary is unreadable or corrupt: ${errorMessage(error)}`
    );
  }
  if (!marked && !archiveEraThrough(clientId, journal.plan.boundary)) {
    return integrityFailure(
      clientId,
      "configs were restored, but the exact backup era could not be closed; recovery data was retained",
      restoredPaths[0]
    );
  }
  try {
    clearEjectJournal(journal);
  } catch (error) {
    return integrityFailure(
      clientId,
      `configs were restored and the era is closed, but recovery cleanup failed: ${errorMessage(error)}`,
      restoredPaths[0]
    );
  }
  if (marked) archiveEraThrough(clientId, journal.plan.boundary);
  return restoredResult(clientId, restoredPaths);
}
function restoredResult(clientId, restoredPaths, detail) {
  return {
    client: clientId,
    action: "restored",
    configPath: restoredPaths[0],
    restoredPaths,
    ...detail ? { detail } : {}
  };
}
function hashIfPresent(target) {
  const bytes = readRegularFileIfPresent(target, 4);
  return bytes === null ? null : sha256Hex(bytes);
}
function readRegularFileIfPresent(target, attempts = 1) {
  try {
    return readRegularFileNoFollow(target, { attempts });
  } catch (error) {
    if (error.code === "ENOENT") return null;
    throw error;
  }
}
function integrityFailure(clientId, detail, configPath) {
  return {
    client: clientId,
    action: "integrity-error",
    ...configPath ? { configPath } : {},
    detail: `BACKUP INTEGRITY FAILURE: ${detail}`
  };
}
function errorMessage(error) {
  return error instanceof Error ? error.message : String(error);
}
function stabilizeStateTargets(clientId, targets) {
  for (let pass = 0; pass < 4; pass++) {
    let changed = false;
    for (const target of targets) {
      if (!target.keyLevel || !target.originalBytes || !target.injectedEntries) continue;
      let writePath;
      try {
        writePath = validateWriteTopology(
          target.sourcePath,
          target.writePath,
          target.symlinkTarget
        );
      } catch (error) {
        return {
          client: clientId,
          action: "refused-modified",
          configPath: target.sourcePath,
          detail: `config topology changed while planning eject: ${errorMessage(error)}`
        };
      }
      const currentBytes = readRegularFileIfPresent(writePath, 4);
      if (currentBytes === null) {
        return {
          client: clientId,
          action: "refused-modified",
          configPath: target.sourcePath,
          detail: "state file disappeared while planning eject"
        };
      }
      const currentSha256 = sha256Hex(currentBytes);
      if (currentSha256 === target.beforeSha256) continue;
      try {
        target.desiredBytes = Buffer.from(
          restoreServersKeyLevel(
            currentBytes.toString("utf8"),
            target.originalBytes.toString("utf8"),
            target.injectedEntries
          )
        );
      } catch {
        return {
          client: clientId,
          action: "refused-modified",
          configPath: target.sourcePath,
          detail: "state file became unparseable while planning eject"
        };
      }
      target.beforeSha256 = currentSha256;
      changed = true;
    }
    if (!changed) return null;
  }
  return {
    client: clientId,
    action: "refused-modified",
    detail: "state files kept changing while eject was planning; retry when the client is idle"
  };
}
function rederiveKeyLevel(journal, target, writePath) {
  if (!target.keyLevel || !target.injectedEntries) return null;
  try {
    const currentBytes = readRegularFileIfPresent(writePath, 4);
    if (currentBytes === null) return null;
    const originalBytes = readOriginalBytes(journal, target);
    return Buffer.from(
      restoreServersKeyLevel(
        currentBytes.toString("utf8"),
        originalBytes.toString("utf8"),
        target.injectedEntries
      )
    );
  } catch {
    return null;
  }
}
function ownedProxyRemains(content, injectedEntries) {
  const parsed = parseJsonc(content);
  if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) return false;
  const servers = parsed.mcpServers;
  if (servers === null || typeof servers !== "object" || Array.isArray(servers)) return false;
  return Object.values(servers).some(
    (entry) => injectedEntries.some((injected) => sameEntry(entry, injected))
  );
}
function restoreServersKeyLevel(currentContent, originalContent, injectedEntries) {
  const current = parseJsonc(currentContent);
  if (current === null || typeof current !== "object" || Array.isArray(current)) {
    throw new Error("current config is not a JSON object");
  }
  const cur = current;
  const original = parseJsonc(originalContent);
  const origServers = original && typeof original === "object" && !Array.isArray(original) ? original.mcpServers : void 0;
  const currentServers = cur.mcpServers && typeof cur.mcpServers === "object" && !Array.isArray(cur.mcpServers) ? { ...cur.mcpServers } : {};
  for (const [name, entry] of Object.entries(currentServers)) {
    if (injectedEntries.some((injected) => sameEntry(entry, injected))) {
      delete currentServers[name];
    }
  }
  const merged = { ...origServers ?? {}, ...currentServers };
  if (Object.keys(merged).length === 0 && origServers === void 0) {
    delete cur.mcpServers;
  } else {
    cur.mcpServers = merged;
  }
  return `${JSON.stringify(cur, null, 2)}
`;
}
function archiveEraThrough(clientId, boundary) {
  const clientDir = path11.dirname(backupDirFor(clientId, "x"));
  if (!fs11.existsSync(clientDir)) return true;
  const archived = `${clientDir}-ejected-${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-")}`;
  try {
    const backupNames = fs11.readdirSync(clientDir).filter((name) => !name.startsWith(".") && name !== "latest").sort();
    if (backupNames.every((name) => name <= boundary)) {
      fs11.renameSync(clientDir, archived);
      return true;
    }
    fs11.mkdirSync(archived, { mode: PRIVATE_DIR });
    for (const name of backupNames.filter((name2) => name2 <= boundary)) {
      fs11.renameSync(path11.join(clientDir, name), path11.join(archived, name));
    }
    return true;
  } catch {
    return false;
  }
}

// ../playbook/dist/skill.js
import { parse as parseYaml2 } from "yaml";
var FRONTMATTER = /^---\r?\n([\s\S]*?)\r?\n---\r?\n?/;
var SCRIPT_EXT = /\.(sh|bash|zsh|py|js|mjs|cjs|ts|rb|pl)$/i;
function isScriptPath(rel) {
  return SCRIPT_EXT.test(rel);
}
function parseSkillMd(content, slug, dir) {
  if (content.charCodeAt(0) === 65279)
    content = content.slice(1);
  const match = FRONTMATTER.exec(content);
  let frontmatter = {};
  let body = content;
  if (match) {
    body = content.slice(match[0].length);
    try {
      const parsed = parseYaml2(match[1] ?? "");
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
        frontmatter = parsed;
      }
    } catch {
      return null;
    }
  }
  const name = typeof frontmatter.name === "string" && frontmatter.name.trim() !== "" ? frontmatter.name.trim() : slug;
  const description = typeof frontmatter.description === "string" ? frontmatter.description.trim() : "";
  return { slug, name, description, body: body.trim(), dir, frontmatter };
}

// ../playbook/dist/scan.js
import fs13 from "node:fs";
import path13 from "node:path";
import os3 from "node:os";

// ../playbook/dist/boundedRead.js
import fs12 from "node:fs";
import path12 from "node:path";
var NON_BLOCK = fs12.constants.O_NONBLOCK ?? 0;
var NO_FOLLOW2 = fs12.constants.O_NOFOLLOW ?? 0;
function readFileHead(file, maxBytes, options = {}) {
  if (!Number.isSafeInteger(maxBytes) || maxBytes < 1) {
    throw new Error("bounded read limit must be a positive safe integer");
  }
  const before = snapshot(file);
  if (before.symlinked && !options.allowSymlink) {
    throw new Error("refusing to follow a symlink");
  }
  const noFollow = before.symlinked ? 0 : NO_FOLLOW2;
  const fd = fs12.openSync(file, fs12.constants.O_RDONLY | NON_BLOCK | noFollow);
  try {
    const openedBefore = fs12.fstatSync(fd, { bigint: true });
    const afterOpen = snapshot(file);
    if (!openedBefore.isFile() || !sameSnapshot(before, afterOpen) || !sameIdentity2(openedBefore, afterOpen.target)) {
      throw new Error("bounded-read path changed while being opened");
    }
    const buf = Buffer.allocUnsafe(maxBytes + 1);
    let n = 0;
    while (n < buf.length) {
      const read = fs12.readSync(fd, buf, n, buf.length - n, n);
      if (read === 0)
        break;
      n += read;
    }
    const openedAfter = fs12.fstatSync(fd, { bigint: true });
    const afterRead = snapshot(file);
    if (!sameStableFile2(openedBefore, openedAfter) || !sameSnapshot(before, afterRead) || !sameIdentity2(openedAfter, afterRead.target)) {
      throw new Error("bounded-read path changed while being read");
    }
    const truncated = n > maxBytes;
    return {
      text: buf.subarray(0, truncated ? maxBytes : n).toString("utf8"),
      truncated,
      symlinked: before.symlinked
    };
  } finally {
    fs12.closeSync(fd);
  }
}
function snapshot(file) {
  const parent = fs12.lstatSync(path12.dirname(file), { bigint: true });
  if (!parent.isDirectory() || parent.isSymbolicLink()) {
    throw new Error("bounded-read parent is not a regular directory");
  }
  const named = fs12.lstatSync(file, { bigint: true });
  const symlinked = named.isSymbolicLink();
  const target = symlinked ? fs12.statSync(file, { bigint: true }) : named;
  if (!target.isFile()) {
    throw new Error("refusing to read a non-regular file");
  }
  return { parent, named, target, symlinked };
}
function sameSnapshot(left, right) {
  return left.symlinked === right.symlinked && sameIdentity2(left.parent, right.parent) && sameIdentity2(left.named, right.named) && sameIdentity2(left.target, right.target);
}
function sameIdentity2(left, right) {
  return left.dev === right.dev && left.ino === right.ino;
}
function sameStableFile2(left, right) {
  return right.isFile() && sameIdentity2(left, right) && left.size === right.size && left.mtimeNs === right.mtimeNs && left.ctimeNs === right.ctimeNs;
}

// ../playbook/dist/scan.js
function defaultSkillSources(opts = {}) {
  const home2 = opts.home ?? process.env.ROSTER_TEST_HOME ?? os3.homedir();
  const cwd = opts.cwd ?? process.cwd();
  return [
    path13.join(home2, ".claude", "skills"),
    path13.join(home2, ".agents", "skills"),
    path13.join(home2, ".openclaw", "skills"),
    path13.join(cwd, ".claude", "skills")
  ];
}
var MAX_RESOURCES_LISTED = 200;
var MAX_SKILL_MD_BYTES = 1024 * 1024;
function scanSkillLibrary(libraryDir) {
  if (!fs13.existsSync(libraryDir))
    return [];
  let entries;
  try {
    entries = fs13.readdirSync(libraryDir, { withFileTypes: true });
  } catch {
    return [];
  }
  const skills = [];
  for (const entry of entries) {
    if (!entry.isDirectory())
      continue;
    const dir = path13.join(libraryDir, entry.name);
    const skillMd = path13.join(dir, "SKILL.md");
    if (!fs13.existsSync(skillMd))
      continue;
    let head;
    try {
      head = readFileHead(skillMd, MAX_SKILL_MD_BYTES, { allowSymlink: true });
    } catch {
      continue;
    }
    const parsed = parseSkillMd(head.text, entry.name, dir);
    if (!parsed)
      continue;
    const resources = listResources(dir);
    const securityWalk = listScripts(dir);
    const scanWarnings = [
      .../* @__PURE__ */ new Set([
        ...securityWalk.warnings,
        ...head.symlinked ? ["symlink:SKILL.md"] : [],
        ...head.truncated ? [`skill-md-truncated:${MAX_SKILL_MD_BYTES}`] : []
      ])
    ].sort();
    skills.push({
      ...parsed,
      resources,
      // Scripts are a SECURITY input, not a display list, so they get their own
      // COMPLETE bounded walk — never `resources.filter(isScriptPath)`. Deriving
      // them from the 200-capped display list let a skill hide a malicious script
      // behind 200 benign files: it was neither listed nor scanned, so the skill
      // scanned "ok" and (with the R5-09 gate) was served (R5-15).
      scripts: securityWalk.scripts,
      scanWarnings
    });
  }
  return skills;
}
function scanSkillSources(sources) {
  const seen = /* @__PURE__ */ new Map();
  for (const source of sources) {
    for (const skill of scanSkillLibrary(source)) {
      if (!seen.has(skill.slug))
        seen.set(skill.slug, skill);
    }
  }
  return [...seen.values()];
}
function listResources(dir) {
  const out = [];
  const walk = (rel) => {
    if (out.length >= MAX_RESOURCES_LISTED)
      return;
    const abs = path13.join(dir, rel);
    let entries;
    try {
      entries = fs13.readdirSync(abs, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      if (out.length >= MAX_RESOURCES_LISTED)
        return;
      if (entry.name.startsWith("."))
        continue;
      const childRel = rel === "" ? entry.name : `${rel}/${entry.name}`;
      if (entry.isDirectory())
        walk(childRel);
      else if (childRel !== "SKILL.md")
        out.push(childRel);
    }
  };
  walk("");
  return out.sort();
}
var MAX_SCRIPTS_SCANNED = 5e3;
function listScripts(dir) {
  const out = [];
  const warnings = /* @__PURE__ */ new Set();
  const walk = (rel) => {
    if (out.length >= MAX_SCRIPTS_SCANNED) {
      warnings.add(`script-scan-cap:${MAX_SCRIPTS_SCANNED}`);
      return;
    }
    let entries;
    try {
      entries = fs13.readdirSync(path13.join(dir, rel), { withFileTypes: true });
    } catch {
      warnings.add(`unreadable-directory:${rel || "."}`);
      return;
    }
    for (const entry of entries) {
      if (out.length >= MAX_SCRIPTS_SCANNED) {
        warnings.add(`script-scan-cap:${MAX_SCRIPTS_SCANNED}`);
        return;
      }
      const childRel = rel === "" ? entry.name : `${rel}/${entry.name}`;
      const childAbs = path13.join(dir, childRel);
      let stat;
      try {
        stat = fs13.lstatSync(childAbs);
      } catch {
        warnings.add(`unreadable-entry:${childRel}`);
        continue;
      }
      if (stat.isSymbolicLink()) {
        warnings.add(`symlink:${childRel}`);
        continue;
      }
      if (stat.isDirectory()) {
        walk(childRel);
        continue;
      }
      if (!stat.isFile()) {
        warnings.add(`unsupported-entry:${childRel}`);
        continue;
      }
      if (childRel === "SKILL.md")
        continue;
      const executable = (stat.mode & 73) !== 0;
      if (!isScriptPath(childRel) && !executable)
        continue;
      out.push(childRel);
      try {
        fs13.accessSync(childAbs, fs13.constants.R_OK);
      } catch {
        warnings.add(`unreadable-file:${childRel}`);
      }
    }
  };
  walk("");
  if (out.length >= MAX_SCRIPTS_SCANNED) {
    warnings.add(`script-scan-cap:${MAX_SCRIPTS_SCANNED}`);
  }
  return { scripts: out.sort(), warnings: [...warnings].sort() };
}

// ../playbook/dist/trust.js
import path14 from "node:path";
var RM_SEP = String.raw`[ \t]+(?:\\\r?\n[ \t]+)*`;
var RM_FLAG = "--?[A-Za-z0-9][-A-Za-z0-9=]*";
var RM_OPT = `(?:${RM_SEP}${RM_FLAG})`;
var RM_RECURSIVE = String.raw`-(?:[a-z]*r|-(?:recursive|recursiv|recursi|recurs|recur|recu|rec|re|r)(?![-\w]))`;
var RM_FORCE = String.raw`-(?:[a-z]*f|-(?:force|forc|for|fo|f)(?![-\w]))`;
var DESTRUCTIVE_RM = new RegExp(String.raw`(?<![-\w=])rm` + `(?=${RM_OPT}*${RM_SEP}${RM_RECURSIVE})(?=${RM_OPT}*${RM_SEP}${RM_FORCE})(?=(${RM_OPT}+))` + String.raw`\1` + `(?:${RM_SEP}--)?${RM_SEP}[~/]`, "i");
var TRUST_RULES = [
  {
    id: "injection-override",
    pattern: /ignore (all |any )?(previous|prior|above) (instructions|rules|guidance)/i,
    detail: "instruction-override phrasing in skill body"
  },
  {
    id: "concealment",
    pattern: /do(n't| not) (tell|inform|mention|reveal|show)( this)? (to )?(the )?user/i,
    detail: "asks the agent to hide behavior from the user"
  },
  {
    id: "exfil-language",
    pattern: /\b(exfiltrate|send (all |the )?(credentials|secrets|tokens|keys))\b/i,
    detail: "credential-exfiltration language"
  },
  {
    id: "curl-pipe-shell",
    pattern: /\b(curl|wget)\b[^\n]{0,200}\|\s*(ba)?sh\b/i,
    detail: "pipe-to-shell install pattern"
  },
  {
    id: "destructive-command",
    // Built above from named fragments: the flat literal is 433 chars. The
    // predecessor `/\brm\s+-(?=[a-z]*r)(?=[a-z]*f)[a-z]+\s+[~/]/i` was linear but
    // required ONE cluster to carry both letters, so it missed every split and
    // long form — `rm -r -f /`, `rm --recursive --force /`, `rm --r --f /` — i.e.
    // 0/25 of the split-form corpus and recall 0.0967 on a 500,000-case fuzz
    // against a getopt oracle (this form: recall 1.0000, precision 0.966).
    pattern: DESTRUCTIVE_RM,
    detail: "recursive force-delete against home or root paths"
  },
  {
    id: "base64-blob",
    pattern: /[A-Za-z0-9+/]{400,}={0,2}/,
    detail: "large base64 blob embedded in instructions"
  },
  {
    id: "env-harvest",
    pattern: /\b(printenv|process\.env|os\.environ)\b[^\n]{0,120}\b(curl|wget|fetch|post|http)/i,
    detail: "environment variables flowing toward network calls"
  }
];
var MAX_SCRIPT_BYTES = 256 * 1024;
function trustScan(skill) {
  const findings = [];
  const seen = /* @__PURE__ */ new Set();
  const scan = (text, where, rules) => {
    for (const rule of rules) {
      if (!rule.pattern.test(text))
        continue;
      const key = `${rule.id}:${where}`;
      if (seen.has(key))
        continue;
      seen.add(key);
      findings.push({ rule: rule.id, detail: `${rule.detail} (${where})` });
    }
  };
  scan(`${skill.name ?? ""}
${skill.description ?? ""}`, "metadata", TRUST_RULES);
  scan(skill.body, "body", TRUST_RULES);
  const scriptRules = TRUST_RULES.filter((r) => r.id !== "base64-blob");
  if (skill.dir) {
    for (const rel of skill.scripts) {
      try {
        scan(readFileHead(path14.join(skill.dir, rel), MAX_SCRIPT_BYTES).text, `script:${rel}`, scriptRules);
      } catch {
      }
    }
  }
  if (skill.scripts.length > 0) {
    findings.push({
      rule: "bundled-scripts",
      detail: `bundles ${skill.scripts.length} executable script(s) \u2014 review before allowing execution`
    });
  }
  for (const warning of skill.scanWarnings ?? []) {
    const rule = warning.startsWith("symlink:") ? "symlink" : "scan-incomplete";
    const key = `${rule}:${warning}`;
    if (seen.has(key))
      continue;
    seen.add(key);
    findings.push({
      rule,
      detail: `${warning} (filesystem discovery did not establish a fully trusted skill tree)`
    });
  }
  return { status: findings.length > 0 ? "review" : "ok", findings };
}

// ../playbook/dist/openclaw.js
var BASE_OVERHEAD_CHARS = 195;
var PER_SKILL_OVERHEAD_CHARS = 97;
function openclawInjectionChars(skills) {
  if (skills.length === 0)
    return 0;
  let total = BASE_OVERHEAD_CHARS;
  for (const skill of skills) {
    const filepath = `${skill.dir}/SKILL.md`;
    total += PER_SKILL_OVERHEAD_CHARS + skill.name.length + skill.description.length + filepath.length;
  }
  return total;
}

// ../playbook/dist/entry.js
init_dist();
var SKILL_SOURCE = "skill";
function skillToCapabilityEntry(skill, id) {
  return {
    id: id ?? stableNamespacedId(SKILL_SOURCE, skill.slug),
    kind: "skill",
    source: SKILL_SOURCE,
    name: skill.name,
    description: skill.description || `Skill: ${skill.name}`,
    body: skill.body,
    path: skill.dir
  };
}
function skillInvocationResult(skill) {
  return {
    name: skill.name,
    description: skill.description,
    instructions: skill.body,
    resources: skill.resources.map((rel) => `${skill.dir}/${rel}`),
    scriptsNote: skill.scripts.length > 0 ? `This skill bundles ${skill.scripts.length} script(s); run them via your own execution tool if appropriate: ${skill.scripts.join(", ")}` : null
  };
}

// src/receipt.ts
init_dist();
init_paths();
function routedByClient(routed) {
  const byClient = /* @__PURE__ */ new Map();
  for (const [name, server] of Object.entries(routed ?? {})) {
    for (const client of server.importedFrom) {
      const set = byClient.get(client) ?? /* @__PURE__ */ new Set();
      set.add(name);
      byClient.set(client, set);
    }
  }
  return byClient;
}
function buildReceipt(discoveries, skills, trustReview, routed, ownedEntries = []) {
  const identities = /* @__PURE__ */ new Set();
  const byClient = routedByClient(routed);
  const clients = discoveries.map((d) => {
    const theirs = d.servers.filter((s) => {
      const candidate = { command: s.command, args: s.args };
      if (s.env !== void 0) candidate.env = s.env;
      return !isOwnedRosterEntry(candidate, ownedEntries);
    });
    const synced = theirs.length < d.servers.length;
    const routedHere = byClient.get(d.client.id) ?? /* @__PURE__ */ new Set();
    const clientIdentities = new Set(theirs.map(serverIdentity));
    if (synced) {
      for (const name of routedHere) {
        const server = routed?.[name];
        clientIdentities.add(server && (server.command || server.url) ? serverIdentity(server) : `routed:${name}`);
      }
    }
    for (const identity of clientIdentities) identities.add(identity);
    return {
      id: d.client.id,
      displayName: d.client.displayName,
      configPath: d.configPath,
      serverCount: synced ? clientIdentities.size : theirs.length,
      note: d.parseError ? `could not parse (${d.parseError.slice(0, 80)})` : synced ? "routed through Roster \u2014 originals backed up; `roster eject` restores them" : d.client.nativeToolSearch ? "schemas natively deferred, not loaded \u2014 Roster adds learning, failover suggestions, and cross-client sync" : "schema weight measured at first serve"
    };
  });
  const hasOpenclaw = discoveries.some((d) => d.client.id === "openclaw");
  const chars = hasOpenclaw ? openclawInjectionChars(skills) : 0;
  return {
    generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
    clients,
    uniqueServers: identities.size,
    skills: {
      count: skills.length,
      trustReview,
      openclaw: hasOpenclaw ? { chars, estTokens: estimateTokensFromChars(chars) } : null
    },
    methodology: "Counts are read from your configs. Token figures are estimates (~4 chars/token); our own measurement puts the error at \u221237%\u2026+27% depending on tokenizer family and payload type (docs/lab/notes-token-economics.md), so read them as ballpark, never exact. OpenClaw skill-injection chars follow its deterministic <available_skills> formula."
  };
}
function saveReceipt(receipt) {
  ensureRosterHome();
  atomicWriteFileSync(receiptPath(), `${JSON.stringify(receipt, null, 2)}
`, PRIVATE_FILE);
}
function renderReceipt(receipt) {
  const lines = [];
  lines.push("\u2500".repeat(64));
  lines.push("  ROSTER \xB7 Day-0 receipt");
  lines.push("\u2500".repeat(64));
  if (receipt.clients.length === 0) {
    lines.push("  No MCP client configs found. Roster still works standalone \u2014");
    lines.push("  add servers to ~/.roster/roster.json and point any client at `roster serve`.");
  }
  for (const client of receipt.clients) {
    lines.push(`  ${client.displayName.padEnd(14)} ${String(client.serverCount).padStart(3)} server(s)  ${client.configPath}`);
    lines.push(`  ${"".padEnd(14)} ${client.note}`);
  }
  lines.push("");
  lines.push(`  Unique servers across clients: ${receipt.uniqueServers}`);
  lines.push(`  Skills discovered: ${receipt.skills.count}${receipt.skills.trustReview > 0 ? `  (${receipt.skills.trustReview} flagged for review)` : ""}`);
  if (receipt.skills.openclaw) {
    lines.push(
      `  OpenClaw skill injection: ${receipt.skills.openclaw.chars.toLocaleString()} chars into EVERY prompt (\u2248${receipt.skills.openclaw.estTokens.toLocaleString()} tokens, estimate)`
    );
  }
  lines.push("");
  lines.push(`  ${receipt.methodology}`);
  lines.push("\u2500".repeat(64));
  return lines.join("\n");
}

// src/init.ts
function init() {
  const discoveries = discoverClients();
  const imported = discoveries.flatMap((d) => d.servers);
  const { config, added, merged } = updateConfig((config2) => {
    const result = mergeServers(config2, imported, ownedRosterEntries());
    config2.skillSources = [.../* @__PURE__ */ new Set([...config2.skillSources, ...defaultSkillSources()])];
    return { config: config2, added: result.added, merged: result.merged };
  });
  const skillSources = config.skillSources;
  const skills = scanSkillSources(skillSources);
  const trustReview = skills.filter((s) => trustScan(s).status === "review").length;
  const receipt = buildReceipt(discoveries, skills, trustReview, config.servers, ownedRosterEntries());
  saveReceipt(receipt);
  process.stdout.write(`${renderReceipt(receipt)}

`);
  process.stdout.write(
    `Imported ${added.length} new server(s)${merged.length > 0 ? `, merged ${merged.length} duplicate definition(s)` : ""} into ~/.roster/roster.json
`
  );
  const syncable = discoveries.map((d) => d.client.id).filter((id) => WRITE_CLIENTS.includes(id));
  if (syncable.length > 0) {
    process.stdout.write(
      `
Next: \`roster sync\` swaps ${[...new Set(syncable)].join(", ")} to a single Roster entry (originals backed up; \`roster eject\` puts everything back exactly as found).
`
    );
  }
  process.stdout.write(`Then point any agent at: roster serve
`);
}

// src/serve.ts
init_dist2();
init_dist();
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";

// ../router/dist/backends.js
init_dist();
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";
import { ErrorCode, McpError } from "@modelcontextprotocol/sdk/types.js";
import { AjvJsonSchemaValidator } from "@modelcontextprotocol/sdk/validation/ajv";
var IsolatingSchemaValidator = class {
  inner = new AjvJsonSchemaValidator();
  validators = /* @__PURE__ */ new WeakMap();
  getValidator(schema) {
    const cached = this.validators.get(schema);
    if (cached)
      return cached;
    let validator;
    try {
      validator = this.inner.getValidator(schema);
    } catch {
      validator = () => ({
        valid: false,
        data: void 0,
        errorMessage: "the tool declares an invalid output schema"
      });
    }
    this.validators.set(schema, validator);
    return validator;
  }
};
var DEFAULT_CALL_TIMEOUT_MS = 3e4;
var DEFAULT_CONNECT_TIMEOUT_MS = 15e3;
var DEFAULT_MAX_TOOLS = 1e4;
var DEFAULT_CLOSE_TIMEOUT_MS = 2e3;
async function withTimeout(promise, ms, label) {
  let timer;
  try {
    return await Promise.race([
      promise,
      new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error(label)), ms);
        timer.unref?.();
      })
    ]);
  } finally {
    if (timer)
      clearTimeout(timer);
  }
}
var BackendManager = class {
  callTimeoutMs;
  connectTimeoutMs;
  backends = /* @__PURE__ */ new Map();
  connecting = /* @__PURE__ */ new Set();
  connections = /* @__PURE__ */ new Set();
  closed = false;
  closing;
  maxTools;
  closeTimeoutMs;
  constructor(callTimeoutMs = DEFAULT_CALL_TIMEOUT_MS, connectTimeoutMs = DEFAULT_CONNECT_TIMEOUT_MS, options = {}) {
    this.callTimeoutMs = callTimeoutMs;
    this.connectTimeoutMs = connectTimeoutMs;
    this.maxTools = options.maxTools ?? DEFAULT_MAX_TOOLS;
    this.closeTimeoutMs = options.closeTimeoutMs ?? DEFAULT_CLOSE_TIMEOUT_MS;
  }
  async connect(config) {
    const name = stableBackendName(config.name);
    if (this.closed)
      throw new Error("backend manager is closed");
    if (this.backends.has(name) || this.connecting.has(name)) {
      throw new Error(`duplicate backend identity: ${name}`);
    }
    this.connecting.add(name);
    let connection;
    try {
      const validator = new IsolatingSchemaValidator();
      const client = new Client({ name: "roster-router", version: "0.0.1" }, { jsonSchemaValidator: validator });
      const transport = "transport" in config ? config.transport : new StdioClientTransport({
        command: config.command,
        args: config.args ?? [],
        // Only explicitly-configured env vars flow through; nothing is persisted or logged.
        env: config.env,
        stderr: "ignore"
      });
      if (transport instanceof StdioClientTransport) {
        const closeTransport = transport.close.bind(transport);
        let transportClosing;
        transport.close = () => {
          transportClosing ??= Promise.resolve().then(closeTransport);
          return transportClosing;
        };
      }
      connection = { client, transport, abort: new AbortController() };
      this.connections.add(connection);
      await withTimeout(client.connect(transport, { signal: connection.abort.signal }), this.connectTimeoutMs, "connect timeout");
      const tools = await withTimeout(this.fetchTools(name, client, connection.abort.signal), this.connectTimeoutMs, "listTools timeout");
      if (this.closed)
        throw new Error("backend manager is closed");
      this.backends.set(name, { name, client, tools, validator });
      return tools;
    } catch (err) {
      if (connection)
        await this.closeConnection(connection).catch(() => void 0);
      throw err;
    } finally {
      this.connecting.delete(name);
    }
  }
  async fetchTools(source, client, signal) {
    const entries = [];
    const seenCursors = /* @__PURE__ */ new Set();
    let cursor;
    do {
      const page = await client.listTools({ cursor }, { signal });
      for (const tool of page.tools) {
        const id = stableNamespacedId(source, tool.name);
        entries.push({
          id,
          kind: "tool",
          source,
          name: tool.name,
          description: tool.description ?? "",
          // Preserve title + annotations (incl. readOnlyHint/destructiveHint):
          // transparent mode must be a faithful passthrough, and clients that
          // gate confirmations on destructiveHint need it (audit D1).
          title: typeof tool.title === "string" ? tool.title : void 0,
          annotations: tool.annotations ?? void 0,
          inputSchema: tool.inputSchema ?? {
            type: "object"
          },
          outputSchema: tool.outputSchema,
          // `execution` (task-support hints) is part of the tool's declared
          // contract; a client that reads it to decide sync-vs-async must see it
          // through the proxy exactly as it would direct (R5-08).
          execution: tool.execution ?? void 0
        });
        if (entries.length > this.maxTools) {
          throw new Error(`backend exposes more than ${this.maxTools} tools`);
        }
      }
      cursor = page.nextCursor;
      if (cursor) {
        if (seenCursors.has(cursor))
          throw new Error("tools pagination cursor repeated");
        seenCursors.add(cursor);
        await new Promise((resolve) => setImmediate(resolve));
      }
    } while (cursor);
    return entries;
  }
  /** Static snapshot of all backend tools, namespaced (client-compat rule: list never changes mid-session). */
  allTools() {
    return [...this.backends.values()].flatMap((b) => b.tools);
  }
  lookup(namespaced) {
    for (const backend of this.backends.values()) {
      const entry = backend.tools.find((t) => t.id === namespaced);
      if (entry)
        return { backend: backend.name, toolName: entry.name, entry };
    }
    return null;
  }
  async call(backendName, toolName, args, outputSchema) {
    const backend = this.backends.get(backendName);
    const started = Date.now();
    if (!backend) {
      return {
        result: null,
        evidence: { transportError: true, errorText: "unknown backend" },
        latencyMs: 0
      };
    }
    try {
      const result = await backend.client.callTool({ name: toolName, arguments: args ?? {} }, void 0, { timeout: this.callTimeoutMs });
      const schema = backend.tools.find((tool) => tool.name === toolName)?.outputSchema ?? outputSchema;
      const isError = result.isError === true;
      if (schema && !result.structuredContent && !isError) {
        throw new McpError(ErrorCode.InvalidRequest, `Tool ${toolName} has an output schema but did not return structured content`);
      }
      if (schema && result.structuredContent) {
        const validation = backend.validator.getValidator(schema)(result.structuredContent);
        if (!validation.valid) {
          throw new McpError(ErrorCode.InvalidParams, `Structured content does not match the tool's output schema: ${validation.errorMessage}`);
        }
      }
      const latencyMs = Date.now() - started;
      const evidence = isError ? { isError: true, errorText: extractErrorText(result) } : { outputSchemaViolation: violatesOutputSchema(result, schema) };
      return { result, evidence, latencyMs };
    } catch (err) {
      let error;
      if (err instanceof McpError) {
        const prefix = `MCP error ${err.code}: `;
        error = {
          code: err.code,
          message: err.message.startsWith(prefix) ? err.message.slice(prefix.length) : err.message,
          data: err.data
        };
      }
      return { result: null, evidence: errorToEvidence(err), latencyMs: Date.now() - started, error };
    }
  }
  closeConnection(connection) {
    connection.closing ??= (async () => {
      connection.abort.abort();
      try {
        const closing = connection.client.close();
        if (connection.transport instanceof StdioClientTransport)
          await closing;
        else
          await withTimeout(closing, this.closeTimeoutMs, "close timeout");
      } finally {
        this.connections.delete(connection);
      }
    })();
    return connection.closing;
  }
  close() {
    this.closed = true;
    this.closing ??= Promise.allSettled([...this.connections].map((connection) => this.closeConnection(connection))).then(() => {
      this.backends.clear();
    });
    return this.closing;
  }
};
function errorToEvidence(err) {
  if (err instanceof McpError) {
    if (isSdkOutputValidationError(err)) {
      return {
        outputSchemaViolation: true,
        errorText: err.message,
        errorCode: err.code
      };
    }
    if (err.code === ErrorCode.RequestTimeout)
      return { timedOut: true, errorCode: err.code };
    if (err.code === ErrorCode.ConnectionClosed) {
      return { transportError: true, errorText: err.message, errorCode: err.code };
    }
    if (err.code === ErrorCode.InvalidParams) {
      return { inputValidationError: true, errorText: err.message, errorCode: err.code };
    }
    return { protocolError: true, errorText: err.message, errorCode: err.code };
  }
  return { transportError: true, errorText: err instanceof Error ? err.message : "" };
}
function isSdkOutputValidationError(err) {
  const detail = err.message.replace(/^MCP error -?\d+: /, "");
  return detail.startsWith("Structured content does not match the tool's output schema") || detail.startsWith("Failed to validate structured content") || detail.includes(" has an output schema but did not return structured content");
}
function extractErrorText(result) {
  const content = result.content;
  if (!Array.isArray(content))
    return "";
  return content.map((c) => c && typeof c === "object" && "text" in c ? String(c.text) : "").join(" ").slice(0, 500);
}
function violatesOutputSchema(result, outputSchema) {
  if (!outputSchema)
    return false;
  const required = outputSchema.required;
  if (!Array.isArray(required) || required.length === 0)
    return false;
  const structured = result.structuredContent;
  if (structured === void 0 || structured === null || typeof structured !== "object")
    return true;
  return required.some((key) => !(String(key) in structured));
}

// ../router/dist/cards.js
var DESCRIPTION_LIMIT = 240;
var MAX_ENUM_VALUES = 16;
var MAX_PROPS = 50;
function toCard(entry) {
  const card = {
    id: entry.id,
    kind: entry.kind,
    description: truncate(entry.description, DESCRIPTION_LIMIT)
  };
  if (entry.kind === "tool" && entry.inputSchema) {
    card.input = trimSchema(entry.inputSchema);
  }
  if (entry.kind === "skill") {
    card.note = "skill \u2014 call it to receive its full instructions and resources";
  }
  return card;
}
function trimSchema(schema) {
  const out = { type: schema.type ?? "object" };
  const props = schema.properties;
  if (props && typeof props === "object") {
    const required = Array.isArray(schema.required) ? schema.required.map(String) : [];
    const entries = Object.entries(props);
    const ordered = [
      ...entries.filter(([k]) => required.includes(k)),
      ...entries.filter(([k]) => !required.includes(k))
    ];
    const trimmed = {};
    for (const [key, value] of ordered.slice(0, MAX_PROPS)) {
      if (value && typeof value === "object") {
        const v = value;
        trimmed[key] = { type: v.type ?? "any", ...trimEnum(v.enum) };
      } else {
        trimmed[key] = { type: "any" };
      }
    }
    out.properties = trimmed;
    if (ordered.length > MAX_PROPS)
      out["x-trimmed-properties"] = ordered.length - MAX_PROPS;
  }
  if (Array.isArray(schema.required) && schema.required.length > 0) {
    out.required = schema.required;
  }
  return out;
}
function trimEnum(enumValue) {
  if (!Array.isArray(enumValue))
    return {};
  if (enumValue.length <= MAX_ENUM_VALUES)
    return { enum: enumValue };
  return { enum: enumValue.slice(0, MAX_ENUM_VALUES), "x-enum-truncated": enumValue.length - MAX_ENUM_VALUES };
}
function truncate(text, limit) {
  return text.length <= limit ? text : `${text.slice(0, limit - 1)}\u2026`;
}

// ../router/dist/rosterServer.js
init_dist2();
import { randomUUID } from "node:crypto";
import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { CallToolRequestSchema, ErrorCode as ErrorCode2, ListToolsRequestSchema, McpError as McpError2 } from "@modelcontextprotocol/sdk/types.js";
import { Ajv2020 } from "ajv/dist/2020.js";
init_dist();
var SUGGESTION_CLASSES = /* @__PURE__ */ new Set([
  "hard_fail:transport",
  "tool_fail:timeout",
  "tool_fail:internal"
]);
var DRAFT_TOOL = {
  name: "draft",
  description: "Describe the next thing you need to do. Returns the best \u2264K capabilities (the starting five) for it \u2014 tools and skills. Call again whenever your need changes.",
  inputSchema: {
    type: "object",
    properties: {
      need: { type: "string", description: "plain-language description of the immediate task" },
      k: { type: "integer", minimum: 1, maximum: 10, default: 5 }
    },
    required: ["need"]
  }
};
var CALL_TOOL = {
  name: "call",
  description: "Invoke a drafted capability by its full id. Tools execute; skills return their instructions.",
  inputSchema: {
    type: "object",
    properties: {
      tool: { type: "string", description: "namespaced id, e.g. github__create_issue" },
      args: { type: "object" },
      draft_id: { type: "string", description: "the draft this call belongs to (from draft's response)" }
    },
    required: ["tool"]
  }
};
var RosterServer = class {
  server;
  mode;
  manager;
  store;
  skills;
  embedNeed;
  defaultK;
  sessionId;
  /** Recent drafts by id — parallel draft/call pairs must not cross-attribute. */
  drafts = /* @__PURE__ */ new Map();
  draftCounter = 0;
  constructor(opts) {
    this.mode = opts.mode;
    this.manager = opts.manager;
    this.store = opts.store;
    this.embedNeed = opts.embedNeed;
    this.defaultK = opts.defaultK ?? 5;
    this.sessionId = opts.sessionId ?? randomUUID();
    const servableSkills = (opts.skills ?? []).filter((s) => opts.allowReviewSkills || trustScan(s).status === "ok");
    this.skills = new Map(servableSkills.map((s) => [skillToCapabilityEntry(s).id, s]));
    this.server = new Server({ name: "roster", version: "0.0.1" }, { capabilities: { tools: {} } });
    this.server.setRequestHandler(ListToolsRequestSchema, async () => {
      await opts.ready;
      return { tools: this.listTools() };
    });
    this.server.setRequestHandler(CallToolRequestSchema, async (request) => {
      await opts.ready;
      if (this.mode === "transparent") {
        return this.handleTransparentCall(request.params.name, request.params.arguments);
      }
      if (request.params.name === "draft") {
        return this.handleDraft(request.params.arguments);
      }
      if (request.params.name === "call") {
        return this.handleFiveCall(request.params.arguments);
      }
      throw new McpError2(ErrorCode2.MethodNotFound, `Unknown tool: ${request.params.name}`);
    });
  }
  /**
   * Index everything the router fronts (drift detection) and prune ghosts.
   * Pass the sources that are configured but unreachable this boot — their
   * capabilities are preserved, not pruned (transient outage ≠ removal).
   */
  syncCapabilities(unavailableSources = /* @__PURE__ */ new Set(), keepSeenSince) {
    const entries = [...this.sessionCapabilities().values()];
    this.store.upsertCapabilities(entries);
    this.store.pruneMissing(new Set(entries.map((e) => e.id)), unavailableSources, {
      keepSeenSince
    });
  }
  /** Skills that survived trust filtering and identity de-duplication. */
  servedSkillCount() {
    return this.skills.size;
  }
  sessionCapabilities() {
    return new Map([
      ...this.manager.allTools(),
      ...[...this.skills.entries()].map(([id, skill]) => skillToCapabilityEntry(skill, id))
    ].map((entry) => [entry.id, entry]));
  }
  listTools() {
    if (this.mode === "five") {
      return [DRAFT_TOOL, CALL_TOOL];
    }
    return this.manager.allTools().map((entry) => ({
      name: entry.id,
      description: entry.description,
      // Faithful passthrough: title + annotations (incl. destructiveHint, D1) and
      // execution hints (R5-08) all survive — a proxied tool must be
      // indistinguishable from the direct one.
      ...entry.title ? { title: entry.title } : {},
      ...entry.annotations ? { annotations: entry.annotations } : {},
      inputSchema: entry.inputSchema ?? { type: "object" },
      ...entry.outputSchema ? { outputSchema: entry.outputSchema } : {},
      ...entry.execution ? { execution: entry.execution } : {}
    }));
  }
  // ── transparent mode ─────────────────────────────────────────────────────
  async handleTransparentCall(namespacedName, args) {
    const target = this.manager.lookup(namespacedName);
    if (!target) {
      throw new McpError2(ErrorCode2.InvalidParams, `Unknown tool: ${namespacedName}`);
    }
    const outcome = await this.manager.call(target.backend, target.toolName, args, target.entry.outputSchema);
    this.record(namespacedName, target.backend, outcome.evidence, outcome.latencyMs, args, null);
    if (outcome.result)
      return outcome.result;
    if (outcome.error) {
      const { code, message, data } = outcome.error;
      const error = new McpError2(code, message, data);
      error.message = message;
      throw error;
    }
    if (outcome.evidence.inputValidationError) {
      throw new McpError2(ErrorCode2.InvalidParams, outcome.evidence.errorText ?? "invalid params");
    }
    if (outcome.evidence.protocolError) {
      throw new McpError2(outcome.evidence.errorCode ?? ErrorCode2.InternalError, outcome.evidence.errorText ?? "backend protocol error");
    }
    throw new McpError2(outcome.evidence.errorCode ?? ErrorCode2.InternalError, describeFailure(outcome.evidence));
  }
  // ── five mode ────────────────────────────────────────────────────────────
  async handleDraft(args) {
    const need = typeof args?.need === "string" ? args.need.trim() : "";
    if (need === "") {
      throw new McpError2(ErrorCode2.InvalidParams, "draft requires a non-empty `need`");
    }
    const k = clampK(args?.k ?? this.defaultK);
    const needHash = hashNeed(need);
    let needVec = null;
    if (this.embedNeed) {
      try {
        needVec = await this.embedNeed(need);
        if (needVec)
          this.store.storeNeedVec(needHash, needVec);
      } catch {
        needVec = null;
      }
    }
    const sessionEntries = this.sessionCapabilities();
    const candidates = this.store.draftCandidates(need, k, needVec, new Set(sessionEntries.keys()));
    const draftId = `d${++this.draftCounter}`;
    this.drafts.set(draftId, { need, needHash, rankedIds: candidates.map((c) => c.entry.id) });
    if (this.drafts.size > 16) {
      const oldest = this.drafts.keys().next().value;
      if (oldest)
        this.drafts.delete(oldest);
    }
    const starters = candidates.map((c) => toCard(sessionEntries.get(c.entry.id)));
    return {
      content: [
        {
          type: "text",
          // Compact, not pretty-printed: indentation added +46–53% marginal token
          // cost on BPE tokenizers (lab-measured) — an own-goal against the very
          // token-savings pitch this draft exists to deliver (audit D9a).
          text: JSON.stringify({
            need,
            draft_id: draftId,
            starters,
            usage: "Invoke with call({tool: <id>, args: {\u2026}, draft_id}). Re-draft when your need changes."
          })
        }
      ]
    };
  }
  async handleFiveCall(args) {
    const id = typeof args?.tool === "string" ? args.tool : "";
    const callArgs = args?.args;
    if (id === "")
      throw new McpError2(ErrorCode2.InvalidParams, "call requires `tool`");
    if (callArgs !== void 0 && (callArgs === null || typeof callArgs !== "object" || Array.isArray(callArgs))) {
      throw new McpError2(ErrorCode2.InvalidParams, "call `args` must be an object");
    }
    const draft = args?.draft_id ? this.drafts.get(args.draft_id) ?? null : null;
    const skill = id.startsWith("skill__") ? this.skills.get(id) : void 0;
    if (skill) {
      this.record(id, "skill", {}, 0, callArgs, draft?.needHash ?? null, true);
      return {
        content: [
          { type: "text", text: JSON.stringify(skillInvocationResult(skill), null, 2) }
        ]
      };
    }
    const target = this.manager.lookup(id);
    if (!target)
      throw new McpError2(ErrorCode2.InvalidParams, `Unknown capability: ${id}`);
    const outcome = await this.manager.call(target.backend, target.toolName, callArgs, target.entry.outputSchema);
    const cls = this.record(id, target.backend, outcome.evidence, outcome.latencyMs, callArgs, draft?.needHash ?? null);
    const base = outcome.result ?? errorResult(describeFailure(outcome.evidence));
    if (base.isError === true && SUGGESTION_CLASSES.has(cls)) {
      const suggestion = this.sixthManSuggestion(draft, id, callArgs);
      if (suggestion) {
        try {
          this.store.recordSuggestion(this.sessionId, id, suggestion.tool);
        } catch {
        }
        const content = Array.isArray(base.content) ? [...base.content] : [];
        content.push({
          type: "text",
          text: JSON.stringify({ _roster: { suggested_alternate: suggestion } })
        });
        return { ...base, content };
      }
    }
    return base;
  }
  /**
   * Sixth Man — SUGGEST-ONLY (owner decision 2026-07-04). Roster never
   * auto-fires a second tool; the agent decides. args_compatible tells it
   * whether its args validate against the alternate's schema as-is.
   */
  sixthManSuggestion(draft, failedId, args) {
    if (!draft)
      return null;
    const failedSource = parseNamespacedId(failedId)?.source;
    for (const candidateId of draft.rankedIds) {
      if (candidateId === failedId)
        continue;
      if (parseNamespacedId(candidateId)?.source === failedSource)
        continue;
      if (this.skills.has(candidateId))
        continue;
      const found = this.manager.lookup(candidateId);
      if (!found)
        continue;
      const entry = found.entry;
      let compatible = false;
      try {
        if (entry.inputSchema) {
          compatible = argsMatchSchema(entry.inputSchema, args ?? {});
        }
      } catch {
        compatible = false;
      }
      return {
        tool: candidateId,
        reason: `the bench suggests ${candidateId} for the same need ("${draft.need}")`,
        args_compatible: compatible
      };
    }
    return null;
  }
  // ── shared ───────────────────────────────────────────────────────────────
  record(capability, source, evidence, latencyMs, args, needHash, explored = false) {
    const outcomeClass = classifyOutcome(evidence);
    const argsHash = hashArgs(args);
    try {
      this.store.recordOutcome({
        session: this.sessionId,
        source,
        capability,
        outcomeClass,
        latencyMs,
        argsHash,
        needHash,
        explored
      });
    } catch {
    }
    return outcomeClass;
  }
};
function argsMatchSchema(schema, args) {
  const ajv = new Ajv2020({ strict: false });
  return ajv.validate(stripDialect(schema), args);
}
function stripDialect(value) {
  if (Array.isArray(value))
    return value.map(stripDialect);
  if (value && typeof value === "object") {
    const out = {};
    for (const [k, v] of Object.entries(value)) {
      if (k === "$schema")
        continue;
      out[k] = stripDialect(v);
    }
    return out;
  }
  return value;
}
function clampK(k) {
  const n = typeof k === "number" && Number.isFinite(k) ? Math.round(k) : 5;
  return Math.max(1, Math.min(10, n));
}
function errorResult(message) {
  return { isError: true, content: [{ type: "text", text: message }] };
}
function describeFailure(evidence) {
  if (evidence.timedOut)
    return "call timed out";
  if (evidence.transportError)
    return `backend unreachable${evidence.errorText ? `: ${evidence.errorText}` : ""}`;
  return evidence.errorText || "call failed";
}

// src/serve.ts
init_paths();

// src/shutdown.ts
function installGracefulShutdown(targets, options = {}) {
  const controller = new AbortController();
  const exit = options.exit ?? ((code) => process.exit(code));
  const emit = options.onMessage ?? ((message) => void process.stderr.write(message));
  const { manager, store, server } = targets;
  let started = false;
  const signals = ["SIGINT", "SIGTERM"];
  const handlers = /* @__PURE__ */ new Map();
  const onEof = () => {
    void shutdown("client disconnected (stdin EOF)", 0);
  };
  const shutdown = async (reason, exitCode) => {
    if (started) return;
    started = true;
    controller.abort();
    process.stdin.removeListener("end", onEof);
    process.stdin.removeListener("close", onEof);
    emit(`roster: shutting down (${reason})
`);
    try {
      await manager.close();
    } catch {
    }
    try {
      store.close();
    } catch {
    }
    for (const [sig, handler] of handlers) process.removeListener(sig, handler);
    exit(exitCode);
  };
  for (const sig of signals) {
    const handler = () => void shutdown(sig, sig === "SIGINT" ? 130 : 143);
    handlers.set(sig, handler);
    process.on(sig, handler);
  }
  process.stdin.on("end", onEof);
  process.stdin.on("close", onEof);
  server.onclose = () => {
    void shutdown("transport closed", 0);
  };
  return controller.signal;
}

// src/serve.ts
async function serve(modeOverride) {
  const bootStarted = Date.now();
  setDenseRuntimeDir(denseModulesDir());
  const config = loadConfig();
  const mode = modeOverride ?? config.mode;
  const store = new CoachStore(openCoachDb(coachDbPath()));
  const manager = new BackendManager();
  const unavailable = /* @__PURE__ */ new Set();
  const scannedSkills = scanSkillSources([
    ...config.skillSources,
    ...defaultSkillSources({ home: homeDir() })
  ]);
  const allowReview = process.env.ROSTER_ALLOW_REVIEW_SKILLS === "1";
  const skills = scannedSkills;
  for (const skill of scannedSkills) {
    const trust = trustScan(skill);
    if (trust.status !== "review") continue;
    const rules = [...new Set(trust.findings.map((x) => x.rule))].join(", ");
    process.stderr.write(
      `roster: ${allowReview ? "SERVING review-flagged" : "WITHHELD review-flagged"} skill "${skill.slug}" [${rules}]${allowReview ? " (ROSTER_ALLOW_REVIEW_SKILLS=1)" : " \u2014 set ROSTER_ALLOW_REVIEW_SKILLS=1 to serve it after reviewing"}
`
    );
  }
  let embedNeed;
  if (config.embeddings === "auto" && !process.env.ROSTER_NO_FETCH) {
    embedNeed = makeLazyEmbedder(store);
  }
  let markReady;
  const ready = new Promise((resolve) => {
    markReady = resolve;
  });
  const roster = new RosterServer({ mode, manager, store, skills, embedNeed, allowReviewSkills: allowReview, ready });
  const transport = new StdioServerTransport();
  const shutdown = installGracefulShutdown({ manager, store, server: roster.server });
  await roster.server.connect(transport);
  for (const [name, entry] of Object.entries(config.servers)) {
    if (shutdown.aborted) return;
    if (!entry.command) {
      process.stderr.write(`roster: skipping "${name}" (url backends land post-launch; stdio only for now)
`);
      unavailable.add(stableBackendName(name));
      continue;
    }
    try {
      await manager.connect({ name, command: entry.command, args: entry.args, env: entry.env });
    } catch (err) {
      if (shutdown.aborted) return;
      unavailable.add(stableBackendName(name));
      process.stderr.write(
        `roster: backend "${name}" failed to connect (its learned state is preserved): ${err instanceof Error ? err.message : err}
`
      );
    }
  }
  if (shutdown.aborted) return;
  try {
    roster.syncCapabilities(unavailable, bootStarted);
  } catch (err) {
    process.stderr.write(
      `roster: capability sync failed (serving with existing index): ${err instanceof Error ? err.message : err}
`
    );
  }
  try {
    const maint = store.runMaintenanceIfDue();
    if (maint.ran && maint.oats) {
      process.stderr.write(`roster: refreshed routing (${maint.oats.adjusted} tools tuned from your outcomes)
`);
    }
  } catch (err) {
    process.stderr.write(`roster: maintenance skipped: ${err instanceof Error ? err.message : err}
`);
  }
  markReady();
  process.stderr.write(
    `roster: serving ${manager.allTools().length} tool(s) + ${roster.servedSkillCount()} skill(s) in ${mode} mode
`
  );
}
var WARMUP_MAX_ATTEMPTS = 3;
var WARMUP_RETRY_BACKOFF_MS = 6e4;
function makeLazyEmbedder(store) {
  let provider = null;
  let warm = false;
  let warming = null;
  let attempts = 0;
  let nextRetryAt = 0;
  const warmup = async () => {
    if (!await TransformersEmbeddings.isAvailable()) {
      attempts = WARMUP_MAX_ATTEMPTS;
      return;
    }
    provider ??= new TransformersEmbeddings();
    await provider.embed(["roster warmup"]);
    const modelId = provider.modelId;
    store.ensureEmbeddingModel(modelId);
    const alreadyEmbedded = store.vecCapabilityIds();
    const entries = store.listCapabilities({ includeQuarantined: true }).filter((e) => !alreadyEmbedded.has(e.id));
    const BATCH = 16;
    for (let i = 0; i < entries.length; i += BATCH) {
      const batch = entries.slice(i, i + BATCH);
      const texts = batch.map((e) => `${e.name}
${e.description}
${e.body ?? ""}`.slice(0, 2e3));
      const vecs = await provider.embed(texts, "document");
      batch.forEach((entry, j) => {
        const vec = vecs[j];
        if (vec) {
          store.storeBaseVec(entry.id, vec, Date.now(), {
            defHash: defHash(entry),
            modelId
          });
        }
      });
    }
    warm = true;
  };
  return async (need) => {
    if (!warm) {
      if (warming === null && attempts < WARMUP_MAX_ATTEMPTS && Date.now() >= nextRetryAt) {
        attempts += 1;
        warming = warmup().catch(() => {
          nextRetryAt = Date.now() + WARMUP_RETRY_BACKOFF_MS;
        }).finally(() => {
          if (!warm) warming = null;
        });
      }
      return null;
    }
    if (!provider) return null;
    const [vec] = await provider.embed([need], "query");
    return vec ?? null;
  };
}

// src/telemetry.ts
function telemetry(action) {
  if (action === "on") {
    updateConfig((config2) => {
      config2.telemetry.enabled = true;
    });
    process.stdout.write(
      "Telemetry consent recorded locally. NOTE: no upload endpoint exists yet \u2014 nothing is transmitted.\nWhat would ever be sent (and what never will be) is documented in docs/telemetry-schema.md.\n"
    );
    return;
  }
  if (action === "off") {
    updateConfig((config2) => {
      config2.telemetry.enabled = false;
    });
    process.stdout.write("Telemetry off (the default).\n");
    return;
  }
  const config = loadConfig();
  process.stdout.write(
    `Telemetry: ${config.telemetry.enabled ? "opted in (no endpoint exists yet \u2014 nothing transmitted)" : "OFF (default)"}
Schema: docs/telemetry-schema.md \xB7 Hard exclusions: prompts, needs, args, results, embeddings, hostnames, paths.
`
  );
}

// src/bin.ts
var HELP = `roster \u2014 the tool router for AI agents

  roster init                 discover client configs, import servers, print the Day-0 receipt
  roster receipt              re-print the receipt from current configs
  roster sync [--client id]   swap write-clients (${WRITE_CLIENTS.join(", ")}) to a single Roster entry (backs up originals)
  roster eject [--client id] [--force]
                              restore configs as found (byte-for-byte for dedicated files;
                              key-level for live state files \u2014 post-sync changes preserved)
  roster serve [--five|--transparent]
                              run the router over stdio (default mode: transparent)
  roster unquarantine <id>    clear a drift-quarantined capability so it can be drafted again
  roster combine run <suite.yaml> --name <server> -- <command> [args\u2026]
                              probe a server against a Combine suite \u2192 lab-results.json
  roster dense [status|enable]
                              optional semantic search (~385 MB, local only); lexical works without it
  roster telemetry [status|on|off]
                              local-first, OFF by default; no endpoint exists yet

  init flags: --dense installs the embedding runtime without asking, --no-dense skips the question
`;
async function offerDenseRuntime(flags) {
  if (flags.has("--no-dense") || isDenseAvailable()) return;
  const wanted = flags.has("--dense") || process.stdin.isTTY === true && process.stdout.isTTY === true && await askYesNo();
  if (!wanted) {
    if (!flags.has("--dense")) {
      process.stdout.write(
        `
Semantic search is off (lexical only). Enable anytime: \`roster dense enable\` (~${DENSE_APPROX_MB} MB, local only).
`
      );
    }
    return;
  }
  process.stdout.write(`
installing the embedding runtime (~${DENSE_APPROX_MB} MB)\u2026
`);
  const result = installDenseRuntime();
  process.stdout.write(
    result.ok ? "semantic search enabled \u2014 it warms up in the background on first use.\n" : `could not install the embedding runtime: ${result.detail}
  Roster keeps working in lexical mode; retry with \`roster dense enable\`.
`
  );
}
async function askYesNo() {
  process.stdout.write(denseOffer());
  const { createInterface } = await import("node:readline/promises");
  const rl = createInterface({ input: process.stdin, output: process.stdout });
  try {
    const answer = await rl.question("Install it now? [y/N] ");
    return /^y(es)?$/i.test(answer.trim());
  } catch {
    process.stdout.write("\n");
    return false;
  } finally {
    rl.close();
  }
}
function assertWriteClient(id) {
  if (id === void 0) return void 0;
  if (!WRITE_CLIENTS.includes(id)) {
    throw new Error(`unknown --client "${id}" (write clients: ${WRITE_CLIENTS.join(", ")})`);
  }
  return id;
}
function parseWriteClient(args, allowForce = false) {
  let client;
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (allowForce && arg === "--force") continue;
    let value;
    if (arg === "--client") value = args[++i];
    else if (arg.startsWith("--client=")) value = arg.slice("--client=".length);
    else throw new Error("unexpected argument; use --client <id> to select a client");
    if (!value || value.startsWith("-")) throw new Error("--client requires a client id");
    if (client !== void 0) throw new Error("--client may only be specified once");
    client = assertWriteClient(value);
  }
  return client;
}
async function main() {
  const [, , command, ...rest] = process.argv;
  const flags = new Set(rest.filter((a) => a.startsWith("--")));
  switch (command) {
    case "init":
      init();
      await offerDenseRuntime(flags);
      return 0;
    case "dense": {
      const sub = rest.find((a) => !a.startsWith("--")) ?? "status";
      if (sub === "status") {
        process.stdout.write(`${denseStatusLine()}
`);
        return 0;
      }
      if (sub !== "enable") {
        process.stdout.write("usage: roster dense [status|enable]\n");
        return 1;
      }
      const ownedRuntime = isDenseInstalledIn(denseModulesDir());
      if (isDenseAvailable() && !ownedRuntime) {
        process.stdout.write("semantic search is already enabled\n");
        return 0;
      }
      process.stdout.write(ownedRuntime ? "updating the embedding runtime\u2026\n" : `installing the embedding runtime (~${DENSE_APPROX_MB} MB)\u2026
`);
      const result = installDenseRuntime();
      process.stdout.write(
        result.ok ? `semantic search enabled \u2192 ${result.detail}
` : `could not install the embedding runtime: ${result.detail}
`
      );
      return result.ok ? 0 : 1;
    }
    case "receipt": {
      const discoveries = discoverClients();
      const config = loadConfig();
      const skills = scanSkillSources(config.skillSources);
      const review = skills.filter((s) => trustScan(s).status === "review").length;
      const receipt = buildReceipt(discoveries, skills, review, config.servers, ownedRosterEntries());
      saveReceipt(receipt);
      process.stdout.write(`${renderReceipt(receipt)}
`);
      return 0;
    }
    case "sync": {
      const only = parseWriteClient(rest);
      const targets = only ? [only] : WRITE_CLIENTS;
      let syncFailures = 0;
      for (const client of targets) {
        try {
          const result = syncClient(client);
          if (result.action === "synced") {
            process.stdout.write(`synced   ${client}  (${result.configPath}; backup: ${result.backupDir})
`);
          } else if (result.action === "already-synced") {
            process.stdout.write(`ok       ${client}  already points at Roster
`);
          } else {
            process.stdout.write(`skipped  ${client}  no config found
`);
          }
        } catch (err) {
          syncFailures++;
          process.stderr.write(`error    ${client}  ${err instanceof Error ? err.message : String(err)}
`);
        }
      }
      return syncFailures > 0 ? 1 : 0;
    }
    case "eject": {
      const only = parseWriteClient(rest, true);
      const targets = only ? [only] : WRITE_CLIENTS;
      let failures = 0;
      let restored = 0;
      for (const client of targets) {
        try {
          const result = ejectClient(client, { force: flags.has("--force") });
          if (result.action === "restored") {
            restored++;
            process.stdout.write(`restored ${client}  ${result.configPath}${result.detail ? `  ${result.detail}` : ""}
`);
          } else if (result.action === "no-backup") {
            process.stdout.write(`skipped  ${client}  ${result.detail ?? "no backup recorded"}
`);
          } else {
            failures++;
            process.stdout.write(`REFUSED  ${client}  ${result.detail}
`);
          }
        } catch (err) {
          failures++;
          process.stderr.write(`error    ${client}  ${err instanceof Error ? err.message : String(err)}
`);
        }
      }
      if (targets.length > 1) process.stdout.write(`
${restored} restored, ${failures} refused
`);
      return failures > 0 ? 1 : 0;
    }
    case "unquarantine": {
      const id = rest.find((a) => !a.startsWith("--"));
      if (!id) {
        process.stdout.write("usage: roster unquarantine <capability-id>\n");
        return 1;
      }
      const { CoachStore: CoachStore2, openCoachDb: openCoachDb2 } = await Promise.resolve().then(() => (init_dist2(), dist_exports));
      const { coachDbPath: coachDbPath2 } = await Promise.resolve().then(() => (init_paths(), paths_exports));
      const store = new CoachStore2(openCoachDb2(coachDbPath2()));
      store.clearQuarantine(id);
      process.stdout.write(`cleared quarantine for ${id} (it can be drafted again)
`);
      return 0;
    }
    case "serve":
      await serve(flags.has("--five") ? "five" : flags.has("--transparent") ? "transparent" : void 0);
      return -1;
    // long-running; keep the process alive on the transport
    case "combine": {
      const dashDash = process.argv.indexOf("--");
      const pre = dashDash >= 0 ? process.argv.slice(3, dashDash) : process.argv.slice(3);
      const serverCmd = dashDash >= 0 ? process.argv.slice(dashDash + 1) : [];
      const positionals = [];
      for (let i = 0; i < pre.length; i++) {
        const a = pre[i];
        if (a.startsWith("--")) {
          i++;
          continue;
        }
        positionals.push(a);
      }
      const [sub, suitePath] = positionals;
      const preFlag = (name2) => {
        const idx = pre.indexOf(name2);
        return idx >= 0 ? pre[idx + 1] : void 0;
      };
      if (sub !== "run" || !suitePath || serverCmd.length === 0) {
        process.stdout.write(
          "usage: roster combine run <suite.yaml> --name <server-name> -- <command> [args\u2026]\n       ({{sandbox}} in args is replaced with each task's sandbox dir)\n"
        );
        return 1;
      }
      const { parseSuite: parseSuite2, runSuite: runSuite2, buildLabResults: buildLabResults2 } = await Promise.resolve().then(() => (init_dist3(), dist_exports2));
      const fs16 = await import("node:fs");
      const suite = parseSuite2(fs16.readFileSync(suitePath, "utf8"));
      const name = preFlag("--name") ?? "server-under-test";
      const run = await runSuite2(suite, {
        name,
        command: serverCmd[0],
        args: serverCmd.slice(1)
      });
      const lab = buildLabResults2([run]);
      const outPath = preFlag("--out") ?? "lab-results.json";
      fs16.writeFileSync(outPath, `${JSON.stringify(lab, null, 2)}
`);
      const summary = lab.runs[0].summary;
      for (const r of run.results) {
        process.stdout.write(`${r.pass ? "PASS" : "FAIL"}  ${r.taskId}${r.detail ? `  (${r.stage}: ${r.detail})` : ""}
`);
      }
      process.stdout.write(
        `
${name}: ${summary.passes}/${summary.n} passed \xB7 Wilson LB ${summary.wilsonLb.toFixed(3)} \xB7 signed ${summary.signedN} (unsigned results never feed named scores)
\u2192 ${outPath}
`
      );
      return summary.passes === summary.n ? 0 : 1;
    }
    case "telemetry": {
      const action = rest[0] ?? "status";
      if (!["status", "on", "off"].includes(action)) {
        process.stderr.write(`roster: unknown telemetry action "${action}" (use status|on|off)
`);
        return 1;
      }
      telemetry(action);
      return 0;
    }
    default:
      if (command !== void 0 && command !== "help" && command !== "--help") {
        process.stderr.write(`roster: unknown command "${command}"

`);
        process.stdout.write(HELP);
        return 1;
      }
      process.stdout.write(HELP);
      return 0;
  }
}
main().then(
  (code) => {
    if (code >= 0) process.exit(code);
  },
  (err) => {
    process.stderr.write(`roster: ${err instanceof Error ? err.message : err}
`);
    process.exit(1);
  }
);
